# Universal Gas Flow Controller: developer handover

Version **1.0.0** (19 November 2026). 98 automated tests pass.

This file is for whoever continues the software. Read sections 1–4 first. They cover what the program is for, how to run and test it, and what must not be broken.

---

## 1. What the software is for

The program is part of a senior project on **optical hydrogen sensors**, which reproduces Luong *et al.*, *Nat. Commun.* 12, 2414 (2021): Pd/PdCo nano-patchy sensors read out by optical transmission. During sensor measurements it controls two Xinnovis mass flow controllers (MFCs) over RS-485 (Modbus RTU). They mix an **H2/N2 premix with N2**, so the sensor sees known **H2 concentrations at a constant total flow**, usually as baseline → exposure → purge pulses. Everything is recorded with timestamps so it can be aligned with spectrometer (and MQ-8 reference sensor) data.


---

## 2. Quick start (developer)

```bash
cd "MFC/Universal_Gas_Flow_Controller_1.0.0"
python3 launcher.py                       # creates .venv on first run (internet), then starts app.py
QT_QPA_PLATFORM=offscreen .venv/bin/python -m unittest discover -s tests   # 98 tests, ~5 s, no hardware
```

- Python ≥ 3.10. Dependencies (`requirements.txt`): PySide6 6.x, pyserial 3.5, numpy 2.x. Tested with Python 3.12.4, PySide6 6.12.0, numpy 2.5.3.
- A `.venv` is machine-specific: never copy it to another computer. If the project lives in an iCloud-synced folder on macOS, iCloud hides files inside `.venv` and Qt can't find its plugins. `launcher.unhide_tree()` repairs this at every start, but keeping the project out of iCloud avoids it.
- Use the **Simulator** port (the default) to work without hardware.

---

## 3. Folder map

```
Senior Project/
├─ MFC/
│  └─ Universal_Gas_Flow_Controller_1.0.0/   ← THE SOFTWARE (this folder)
├─ MQ8_Reference_Sensor/                     ← separate Arduino + PySide6 app; reads this program's recordings (§7)
├─ Related Docs/                             ← manufacturer manuals: MFC-E, S300, both Modbus protocols, SmartFlow
├─ Matlab/, Materials/                       ← FDTD/geometry work (not related to this software)
└─ s41467-021-22697-w.pdf (+ MOESM1)         ← reference paper
```

Inside the software folder:

| Path | Content |
|---|---|
| `app.py` | Entire GUI and orchestration (~1,340 lines): `SummaryBar`, `ChannelCard`, `MainWindow` |
| `core/modbus.py` | CRC16, `SerialBus` (timed transactions), `BusPool` (shared port per baud), `ModbusClient` (FC 03/06/16) |
| `core/devices.py` | `Profile` (per-model scale, accuracy, range), `Reading`, `SimulatorDevice`, `PhysicalDevice` (register map), `scan_port` |
| `core/channel.py` | `Channel`: one controller; Cmix, limits, start/stop, safety checks (overflow, no-flow, tracking), arrival timing |
| `core/gases.py` | Gas coefficient table (= manufacturer appendix), Cmix, ppm helpers, flammability check, concentration uncertainty |
| `core/solver.py` | Source flows for a target composition (exact, or "any balance" dilution mode) |
| `ui/chart.py` | Real-time chart (`ChartGroup` shared time axis, `TimeSeriesChart`, `ChartCard`) |
| `ui/widgets.py` | `wrap()` (word-wrapping label), `ElidedLabel`, `Pill`, `Tile` |
| `ui/composition.py` | Gas composition editor/dialog |
| `launcher.py` | Creates/repairs `.venv`, starts the app; `unhide_tree()` clears hidden-file flags set by iCloud sync |
| `tests/` | 98 tests (§8) |
| `scripts/package_release.py`, `scripts/build_windows_offline.py` | Packaging (§9) |
| `examples/lab_setup_{windows,macos}.gfc.json` | Ready lab configuration + 40-min pulse recipe |
| `docs/verification/hardware_2026-10-14/` | Raw data of the real-hardware test (**referenced by the MQ-8 tests, keep it**) |
| `docs/images/` | Screenshots used in the README |
| `README.md`, `START_HERE.txt`, `TEST_RESULTS_HARDWARE.md` | User docs, hardware test report |
| `build/`, `dist/`, `recordings/`, `.venv/` | Generated: not source, excluded from packages |

---

## 4. Lab hardware (tested 14 October 2026)

| Controller | Gas | macOS port* | Windows port** | Model profile | Baud | Address | Full scale | Calibrated for |
|---|---|---|---|---|---|---|---|---|
| Xinnovis **S300D** | 5.4 % H2 in N2 (Cmix 1.0418) | `/dev/cu.usbserial-1110` | COM5 | `S300-new` (×0.001) | 19200 | 1 | 500 SCCM | N2 |
| Xinnovis **MFC-E** | N2 | `/dev/cu.usbserial-1120` | COM7 | `MFC-E` (×0.01) | 9600 | 2 | 500 SCCM | N2 |

\* Depends on the USB socket. **Device Tools → Find devices** identifies ports in seconds.
\*\* As stated by the user. **Not yet verified on the Windows PC.**

Each controller has its own PSC converter (CH340 USB-serial, USB ID 1a86:7523; Windows may need the CH341SER driver).

**Measured behaviour** (details in `TEST_RESULTS_HARDWARE.md`):
- S300D: setpoint scale ×0.001 **confirmed by real flow**. It reports flow in **whole SCCM** (decimal code 2), and its setpoint registers read back 0, so read-back can't be used. It has **2.7–3.0 s dead time** when starting from 0 (the valve drive must reach ~36 % before gas passes), then reaches setpoint in 0.6 s. Stopping takes < 0.4 s.
- MFC-E: 100.00 ± 0.02 SCCM at a 100 SCCM setpoint. About 1.3 s dead time from 0. With **no gas supply** it opens its valve (43 → 76 % in 3 s); opening the cylinder then gives a surge.
- Communication: a full read takes 79 ms (S300D) and 117 ms (MFC-E).

**Reachable H2 with this hardware** (controller accuracy only, from `concentration_limits()`):

| Total flow | Max | Reliable (≥ 2 % FS) from | Within ±10 % from |
|---|---|---|---|
| 200 SCCM | 5.4 % | 2,867 ppm | 4,049 ppm |
| 400 SCCM (paper) | 5.4 % | 1,437 ppm | 2,150 ppm |
| 500 SCCM | 5.4 % | 1,141 ppm | 1,708 ppm |

**ppm-level work (LOD, < 1,000 ppm) is not possible with this premix and controller.** It needs a 100–1,000 ppm H2/N2 premix or a 10–20 SCCM premix controller.

**Rules for real-hardware work:**
1. Start with **read-only** checks (scan, `connect()`, `poll()`). Connecting and reading never move gas.
2. **Ask the person at the bench before any command that makes gas flow**, and confirm the cylinders and regulators are open (0.5–6 bar above outlet; the manual calibrates at 2.5 bar), the outlet is vented, and someone is present.
3. Every test script must command zero in a `finally:` block and read the registers back afterwards.
4. Never write configuration registers (address, baud, factory reset, zero calibration) unless that is the explicit task.

---

## 5. Architecture

### Runtime loop
```
QTimer 500 ms (PreciseTimer) → MainWindow.poll_all()
   for each connected Channel: Channel.poll() → PhysicalDevice.read()  (3 Modbus reads; comm error → fail_safe_stop)
   per channel: step_arrival() → event · check_overflow()/check_no_flow() → fail_safe_stop · check_tracking() → warning
   _finish_row(): outlet composition, total, target, expected ± uncertainty   → chart_data (≤ 50,000 rows)
   capture_recording(): in-memory recording + CSV row written and flushed      → recordings/
   update cards and summary tiles
QTimer 1 s → refresh_charts()
```

### Command path
```
ChannelCard.do_start / apply_mixture / run_recipe_step
   → MainWindow.apply_flows(pairs)          ← "hold carrier until premix flows" sequencing (§6)
   → Channel.configure(corrected) → Channel.start()  (validate ≤ full scale; records _step for arrival timing)
   → PhysicalDevice.set_flow(raw)  → write_multiple(0x0021, [0, hi, lo])   (raw = corrected / Cmix, × set_scale)
```

### Units and conventions (important)
- **Corrected flow** = flow of the actual gas = device reading × Cmix. **Raw** = what the device reports (N2-equivalent for an N2-calibrated device). Setpoints entered in the UI are corrected; the device receives raw.
- **Cmix** = `correction_factor(source) / coefficient(calibration gas)`. The calibration gas comes from register 0x0003. Coefficients are the manufacturer's (H2 = 3.900, MEMS sensors).
- Concentrations are **percent internally**; ppm is used only for display and input (`percent_to_ppm`, `concentration_text`).
- Balance `*` (or empty / `any`) in recipes means **dilution mode**: only the target gas and the total flow are constrained (`solve_source_flows(..., constrained_gases=[gas])`). Use it for premix + air.
- Model `Profile` (`core/devices.py`): `set_scale` (MFC-E 100, S300 1000), `read_mode`, accuracy (MFC-E ±max(0.8 % FS, 1 % SP); S300 ±0.3 % FS ≤ 30 % FS, else ±1 % SP), `min_fraction` (MFC-E 1 %, S300 2 %), baud list.
- Expected concentration ± uncertainty = setpoint rounding + root-sum-square of controller accuracies (`expected_concentration`, `outlet_concentration_uncertainty`). It does **not** include coefficient or premix-certificate uncertainty. Steps above ±10 % (`MAX_REL_UNCERTAINTY`) are flagged.

### Code style
`app.py` uses a dense, mostly one-line Qt style; `core/` and `ui/` use normal formatting. When editing, match the surrounding style. When adding big features, prefer new modules over growing `app.py`.

---

## 6. Safety design: do not break

| Mechanism | Where | Notes |
|---|---|---|
| **Safety stop (latched)** | `fail_safe_stop` | Any comm/command error, overflow or no-flow → all channels commanded 0, recipe aborted, mixture invalidated. Restart requires **Acknowledge** (`ask_ack_failsafe`), which does not restart flows |
| **STOP ALL** (also Esc) | `emergency_stop_all` | Unconfirmed stop → escalates to the safety stop |
| **Overflow stop** | `Channel.check_overflow` | > 1.5 × setpoint + tolerance after 5 s. Protects against a **wrong model choice** (S300 vs MFC-E = 10× flow, and the models can't be told apart over Modbus) and a stuck valve |
| **No-flow stop** | `Channel.check_no_flow` | < 20 % of a reliable setpoint after 6 s (allows for the S300D dead time). Prevents the valve wind-up surge and undiluted premix reaching the sensor |
| **Flammability** | `flammability_error` | Refuses H2 ≥ 4 % when O2/Air is present |
| **Sequenced switching** | `apply_flows`, `cancel_sequence` | Held carrier reductions are cancelled by every stop path (stop all, safety stop, recipe stop, shutdown) via a token. **Any new stop path must call `cancel_sequence()`** |
| **Setpoint limits** | `ChannelCard.max_setpoint`, `Channel.validate_setpoint` | The UI box is capped at full scale × Cmix; the core also refuses above full scale |
| **Shutdown** | `_shutdown_best_effort`, `closeEvent`, signal handlers | Commands 0 and disconnects. A user close asks first while gas flows (`event.spontaneous()`) |
| **Confirmations** | UI handlers only (`ui_load_project`, `ask_remove`, `request_close`, valve/zero/clear dialogs) | Kept out of core methods on purpose: tests call `load_project()` etc. directly and would hang on a dialog |
| Zero calibration | `tools_zero` | Refused while flowing; asks to close the stop valves first |

Remember that a zero setpoint doesn't shut the gas line: physical stop valves are required (manufacturer manual).

---

## 7. Interfaces other code depends on

1. **Recording CSV** (`_open_record_stream`, `_write_record_row`), written row by row to the autosave folder, plus a JSON metadata sidecar. The columns are:
   - `timestamp, unix_time_s, elapsed_s, event, recipe_step, recipe_cycle, step_note`
   - `target_<gas>_ppm, expected_<gas>_ppm, expected_<gas>_uncertainty_ppm, outlet_<gas>_ppm, total_corrected_flow`
   - then, per channel: `<name> setpoint (unit), corrected flow, raw flow, valve (%), temperature (C), working`

   **`MQ8_Reference_Sensor/mq8/recording.py` (`load_gasflow_recording`) reads `unix_time_s`, `target_*_ppm`, `expected_*_ppm`, `outlet_*_ppm`, `step_note`.** Its tests use the sample recording `docs/verification/hardware_2026-10-14/20261014_144849_pulse_test.csv`, referred to by path in `MQ8_Reference_Sensor/tests/test_core.py`; keep the two in step. Don't rename these columns without updating the MQ-8 app. Event rows (non-empty `event`) mark commands, steps, arrivals and safety stops.
2. **Project files** `.gfc.json`, `PROJECT_SCHEMA = 1`. Missing keys load with defaults. Projects always load **disconnected**.
3. **Recipe JSON** (`save_recipe` / `load_recipe`), plus a compact `steps` format with named fields (`examples/recipe_concentration_h2.json`).
4. **`ui/chart.py` and `ui/widgets.py` are copied unchanged into `MQ8_Reference_Sensor/ui/`**: keep them in sync when changing either.
5. Time alignment with other instruments works through the computer clock (`unix_time_s`), so record everything on the same computer.

---

## 8. Tests

| File | Tests | Covers |
|---|---|---|
| `test_core.py` | 14 | CRC, Cmix, solver, simulator start/stop |
| `test_application.py` | 21 | Composition editor, bus pool, failure cleanup, window fail-safe, recording, project load |
| `test_research_features.py` | 12 | ppm, dilution mode, pulse generator, low-range warnings, flammability, autosave, deadline timing |
| `test_manufacturer_protocol.py` | 27 | **Byte-exact request frames and decoded responses from the manufacturer PDFs**, accuracy rules, scan, tracking/overflow/no-flow, integer flow, valve read, device tools |
| `test_ui_design.py` | 18 | Window fits small screens, **no clipped text in any tab** at 1280×720 and 1000×600, setpoint limits, mixture limits, recipe validation and lock, close confirmation, chart navigation, Windows launcher path and CRLF, overflow stop, sequenced switching (incl. cancellation), precise timers |
| `test_launcher.py`, `test_failsafe_contract.py` | 6 | Launcher branches, fail-safe contract |

- All tests run offscreen with the simulator and mocked serial ports, and never touch hardware.
- The layout test fails if a UI change clips text or makes the window taller than 640 px. Fix the layout rather than loosening the test. Truncation is only acceptable via `ElidedLabel` (it shows "…" with the full text in the tooltip).
- Real-font layout check (macOS): open the window with `Qt.WA_DontShowOnScreen` and inspect labels with `heightForWidth`. Offscreen fonts differ from native ones, so the offscreen test alone can miss clipping that native fonts show.

---

## 9. Packaging and release

1. Edit `version.py` (`VERSION`, `PUBLIC_VERSION`, `RELEASE_DATE`; change `PROJECT_SCHEMA` only if existing project files can no longer load). Update `README.md` and the About text in `app.py` (`_build_menu`).
2. Run the tests.
3. `.venv/bin/python scripts/package_release.py` → `dist/Universal_Gas_Flow_Controller_<v>.zip` (source, Windows + macOS, ~1 MB; needs Python and internet on the first start). It keeps the `.command` executable and the `.bat` CRLF, and verifies both. New top-level files must be added to `TOP_FILES`.
4. `.venv/bin/python scripts/build_windows_offline.py` → `dist/GasFlowController_<v>_Windows_offline.zip` (~70 MB):
   - It bundles the embeddable **Python 3.12.10** (python.org) with Windows wheels of **PySide6-Essentials 6.12.0, shiboken6 6.12.0, numpy 2.5.3 and pyserial 3.5**, unpacked into `runtime/Lib/site-packages`. Unused QML/Quick parts are pruned. It builds on macOS (nothing is compiled), and downloads are cached in `build/win_cache`.
   - The embeddable Python has **no `venv`/`ensurepip`**, which is why `launcher.py` imports `venv` optionally.
   - The longest path inside is 145 characters, so extract to a short folder (`C:\GasFlow`).
   - Checked from macOS only: file presence, DLL import tables and standard-library coverage. **It hasn't yet been started on a real Windows PC.**
5. `build_windows.bat` / `build_macos.sh` (PyInstaller) exist but haven't been used recently.

---

## 10. Open work (suggested priority)

1. **Run the offline Windows package on the lab PC** and confirm COM5 = S300D and COM7 = MFC-E (Device Tools → Find devices). Report any startup error shown in the console window.
2. **Gas for low concentrations:** with the current hardware, ±10 % only from ≈ 2,150 ppm at 400 SCCM (§4). Decide on a lower premix or a smaller premix controller before LOD measurements.
3. **Move serial communication to a worker thread.** It runs on the GUI thread, which delays recipe steps by one polling cycle (~0.2 s, logged and non-accumulating) and freezes the UI during timeouts. Keep the safety checks and fail-safe semantics identical.
4. **Spectrometer integration:** log spectrometer data (or a trigger) in this program, or document the alignment procedure via `unix_time_s`. Use the arrival events (not step events) as the t = 0 for response times. The S300D adds ~3 s when starting from 0.
5. **User manual:** none yet; `README.md`, `START_HERE.txt` and *Help → Quick guide* cover operation.
6. S300D readings are whole SCCM, so the "measured" concentration is quantised (±0.5 SCCM on ~18 SCCM ≈ ±3 %). Consider showing a resolution band, or rely on the expected value.
7. Smaller items:
   - The solver enumerates subsets, which is fine below ~10 channels.
   - Mixed flow units (SCCM/SLM) aren't converted.
   - Project loading isn't transactional.
   - Chart history is in memory only (50,000 rows ≈ 7 h); recordings are autosaved.
   - Premix-certificate and coefficient uncertainty aren't in the ± figure.
   - `app.py` would benefit from being split into modules (tabs, recording, recipes).
8. MQ-8 finding (other app): a SnO2 sensor needs O2, so it's nearly blind in an N2 balance. Air-carrier tests would use dilution mode `*` here but need an air source (none in the lab yet). Mixtures with air are capped below 4 % H2 by the flammability check.

---

## 11. Further reading

- `TEST_RESULTS_HARDWARE.md`: the hardware test.
- `Related Docs/`: manufacturer documents. Note where they contradict each other: the S300 default baud is 9600, 19200 or 115200 depending on the document, and the S300 setpoint scale is 0.01 in the register table but 0.001 in the examples and on the real device.
