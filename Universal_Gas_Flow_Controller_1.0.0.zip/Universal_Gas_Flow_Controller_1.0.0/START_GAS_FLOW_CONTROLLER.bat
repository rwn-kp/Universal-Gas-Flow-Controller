@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 launcher.py
  goto :result
)
where python >nul 2>nul
if not errorlevel 1 (
  python launcher.py
  goto :result
)
echo Python 3.10 or newer was not found. Install Python and enable Add Python to PATH.
pause
exit /b 1
:result
if errorlevel 1 (
  echo.
  echo The application could not start or exited with an error. See the details above.
  pause
  exit /b 1
)
endlocal
