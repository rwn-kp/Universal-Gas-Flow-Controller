import unittest
from core.channel import Channel

class FailingDevice:
    def emergency_zero(self): raise RuntimeError('link down')
    def disconnect(self): pass

class TestFailSafeContract(unittest.TestCase):
    def test_unreachable_device_stop_is_unconfirmed(self):
        c=Channel(); c.connected=True; c.working=True; c.device=FailingDevice()
        self.assertFalse(c.emergency_stop()); self.assertFalse(c.working); self.assertFalse(c.stop_confirmed)

if __name__=='__main__': unittest.main()
