import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import launcher


class LauncherTests(unittest.TestCase):
    def exercise(self, exists=True, probe_code=0, app_code=0):
        with tempfile.TemporaryDirectory(prefix='gas flow ') as folder:
            root=Path(folder)
            if exists:
                python=launcher.environment_python(root); python.parent.mkdir(parents=True); python.touch()
            calls=[]
            def run(args, **kwargs):
                calls.append((args,kwargs))
                if len(calls)==1: return subprocess.CompletedProcess(args,probe_code)
                return subprocess.CompletedProcess(args,app_code if args[-1].endswith('app.py') else 0)
            with patch('launcher.subprocess.run',side_effect=run), patch('launcher.venv.EnvBuilder') as builder:
                result=launcher.run(root)
                self.assertEqual(result,app_code)
                if not exists: builder.return_value.create.assert_called_once_with(root/'.venv')
            for _,kwargs in calls: self.assertEqual(kwargs['cwd'],root)
            self.assertEqual(calls[-1][0], [str(launcher.environment_python(root)),str(root/'app.py')])
            return calls
    def test_complete_environment_no_install(self): self.assertEqual(len(self.exercise()),2)
    def test_missing_dependencies_repaired(self): self.assertEqual(len(self.exercise(probe_code=1)),5)
    def test_fresh_environment(self): self.assertEqual(len(self.exercise(exists=False,probe_code=1)),5)
    def test_app_failure_propagated(self): self.exercise(app_code=1)
    def test_install_failure_prevents_start(self):
        with patch('launcher.subprocess.run',side_effect=[subprocess.CompletedProcess([],1),subprocess.CalledProcessError(1,[]) ]), patch('launcher.venv.EnvBuilder'):
            with self.assertRaises(subprocess.CalledProcessError): launcher.run()
