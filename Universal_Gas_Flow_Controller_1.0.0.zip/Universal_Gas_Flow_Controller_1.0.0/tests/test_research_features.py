import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import csv, json, tempfile, time, unittest
from pathlib import Path
from unittest.mock import patch
from PySide6.QtWidgets import QApplication, QTableWidgetItem, QMessageBox
from app import MainWindow, pulse_sequence_rows
from core.gases import flammability_error, concentration_text
from core.solver import solve_source_flows


class CoreResearchTests(unittest.TestCase):
    def test_dilution_with_any_balance(self):
        # 10 ppm H2 at 400 sccm from a 1% H2/N2 premix diluted with synthetic air.
        flows=solve_source_flows([{'H2':1,'N2':99},{'Air':100}],{'H2':0.001},400,constrained_gases=['H2'])
        self.assertAlmostEqual(flows[0],0.4,9); self.assertAlmostEqual(flows[1],399.6,9)
        with self.assertRaises(ValueError):
            solve_source_flows([{'H2':1,'N2':99},{'Air':100}],{'H2':0.001,'Air':99.999},400)

    def test_any_balance_prefers_fewest_channels(self):
        flows=solve_source_flows([{'H2':1,'N2':99},{'N2':100},{'Air':100}],{'H2':0},400,constrained_gases=['H2'])
        self.assertEqual(flows,[0.0,400.0,0.0])

    def test_flammability(self):
        self.assertTrue(flammability_error({'H2':4,'Air':96}))
        self.assertTrue(flammability_error({'H2':5,'O2':20,'N2':75}))
        self.assertFalse(flammability_error({'H2':3.9,'Air':96.1}))
        self.assertFalse(flammability_error({'H2':10,'N2':90}))

    def test_concentration_text(self):
        self.assertEqual(concentration_text(0.001),'10 ppm')
        self.assertEqual(concentration_text(2),'20,000 ppm (2%)')
        self.assertEqual(concentration_text(0.00004),'0.4 ppm')

    def test_pulse_rows(self):
        rows=pulse_sequence_rows('H2','N2',[100,50],2,60,30,30,0,400)
        self.assertEqual(len(rows),1+2*2*2)
        self.assertEqual([r[3] for r in rows],['0','100','0','100','0','50','0','50','0'])
        self.assertEqual(rows[1][6],'Exposure 100 ppm (1/2)')


class WindowResearchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.app=QApplication.instance() or QApplication([])
    def setUp(self):
        self.window=MainWindow(); self.window.poll_timer.stop(); self.window.chart_timer.stop()
        self.folder=tempfile.TemporaryDirectory(); self.window.rec_dir.setText(self.folder.name)
        w=self.window; w.channels[0].source={'H2':1,'N2':99}; w.channels[1].source={'N2':100}
        for c in w.channels: c.connect()
        w.recipe_type.setCurrentIndex(1)
    def tearDown(self): self.window.close(); self.folder.cleanup()

    def set_rows(self,rows):
        w=self.window; w.recipe_table.setRowCount(0)
        for row in rows:
            w.add_recipe_step()
            for column,text in enumerate(row): w.recipe_table.setItem(w.recipe_table.rowCount()-1,column,QTableWidgetItem(text))

    def test_ppm_recipe_runs_with_expected_setpoints(self):
        w=self.window; w.conc_unit.setCurrentText('ppm')
        self.set_rows([['','5','H2','5000','N2','100','exposure'],['','5','H2','0','*','100','purge']])
        w.start_recipe()
        self.assertTrue(w.recipe_running)
        self.assertAlmostEqual(w.channels[0].configured_setpoint,50)   # 0.5% from a 1% premix
        self.assertAlmostEqual(w.channels[1].configured_setpoint,50)
        w.poll_all()
        self.assertIn('5,000 ppm',w.summary.text()); self.assertIn('left in total',w.summary.text())
        w.advance_recipe()
        self.assertAlmostEqual(w.channels[0].configured_setpoint,0)
        self.assertAlmostEqual(w.channels[1].configured_setpoint,100)
        w.stop_recipe_now('done')

    def test_unit_switch_converts_values(self):
        w=self.window; self.set_rows([['','5','H2','0.5','N2','100','']])
        w.conc_unit.setCurrentText('ppm')
        self.assertEqual(w.recipe_table.item(0,3).text(),'5000')
        self.assertIn('ppm',w.recipe_table.horizontalHeaderItem(3).text())
        w.conc_unit.setCurrentText('%')
        self.assertEqual(w.recipe_table.item(0,3).text(),'0.5')

    def test_low_range_setpoint_warns_and_can_be_declined(self):
        w=self.window; w.conc_unit.setCurrentText('ppm')
        self.set_rows([['','5','H2','10','N2','100','10 ppm']])   # needs 0.1 sccm from the premix (0.1% FS)
        steps=w.parse_recipe()
        self.assertTrue(steps[0]['warnings'])
        with patch('app.QMessageBox.question',return_value=QMessageBox.No):
            w.start_recipe()
        self.assertFalse(w.recipe_running)
        self.assertTrue(all(c.device.setpoint==0 for c in w.channels))

    def test_flammable_step_rejected(self):
        w=self.window; w.channels[0].source={'H2':100}; w.channels[1].source={'Air':100}
        self.set_rows([['','5','H2','5','*','100','too much']])
        with self.assertRaisesRegex(ValueError,'flammability'): w.parse_recipe()
        w.start_recipe(); self.assertFalse(w.recipe_running)

    def test_recording_is_autosaved_with_events(self):
        w=self.window; w.exp_name.setText('LOD run')
        w.start_recording(); w.poll_all()
        self.set_rows([['','5','H2','0.5','N2','100','exposure']]); w.start_recipe(); w.poll_all()
        path=w._record_stream['path']
        w.stop_recipe_now('stop'); w.stop_recording()
        self.assertTrue(path.exists()); self.assertTrue(path.with_suffix('.json').exists())
        with path.open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
        events=[r['event'] for r in rows if r['event']]
        self.assertIn('Recording started',events); self.assertTrue(any(e.startswith('Running Step 1/1') for e in events))
        running=[r for r in rows if r['recipe_step']=='1' and not r['event']]
        self.assertAlmostEqual(float(running[0]['target_H2_ppm']),5000)
        self.assertAlmostEqual(float(running[0]['Channel 1 setpoint (SCCM)']),50,9)
        meta=json.loads(path.with_suffix('.json').read_text())
        self.assertEqual(meta['channels'][0]['source_percent'],{'H2':1.0,'N2':99.0})

    def test_recipe_deadlines_do_not_accumulate_delay(self):
        w=self.window; self.set_rows([['','10','H2','0.5','N2','100',''],['','10','H2','0','N2','100','']])
        w.start_recipe(); st=w.recipe_state
        st['t0']-=3   # simulate the step-1 timer firing 3 s late
        w.advance_recipe()
        self.assertAlmostEqual(st['step_end'],st['t0']+20,6)
        w.stop_recipe_now('done')

    def test_recipe_unit_saved_and_loaded(self):
        w=self.window; w.conc_unit.setCurrentText('ppm'); self.set_rows([['','5','H2','100','N2','100','']])
        path=Path(self.folder.name)/'r.json'
        with patch('app.QFileDialog.getSaveFileName',return_value=(str(path),'')): w.save_recipe()
        w.conc_unit.setCurrentText('%')
        with patch('app.QFileDialog.getOpenFileName',return_value=(str(path),'')): w.load_recipe()
        self.assertEqual(w.conc_unit.currentText(),'ppm'); self.assertEqual(w.recipe_table.item(0,3).text(),'100')


if __name__=='__main__': unittest.main()
