import unittest
from core.modbus import crc16, append_crc
from core.gases import correction_factor, outlet_composition, normalize_composition
from core.solver import solve_source_flows
from core.channel import Channel

class TestCore(unittest.TestCase):
    def test_crc_read_basic(self):
        req=bytes.fromhex('01 03 00 03 00 03')
        self.assertEqual(append_crc(req).hex(' '), '01 03 00 03 00 03 f5 cb')
    def test_crc_zero(self):
        req=bytes.fromhex('01 06 00 25 00 01')
        self.assertEqual(append_crc(req).hex(' '), '01 06 00 25 00 01 59 c1')
    def test_crc_factory_restore(self):
        req=bytes.fromhex('01 06 00 25 00 02')
        self.assertEqual(append_crc(req).hex(' '), '01 06 00 25 00 02 19 c0')
    def test_n2_factor(self): self.assertAlmostEqual(correction_factor({'N2':100}),1.0,12)
    def test_normalize(self): self.assertEqual(normalize_composition({'H2':1,'N2':99}),{'H2':1.0,'N2':99.0})
    def test_three_source_solution(self):
        x=solve_source_flows([{'H2':100},{'O2':100},{'N2':100}],{'H2':1,'O2':20,'N2':79},100)
        self.assertAlmostEqual(x[0],1,6); self.assertAlmostEqual(x[1],20,6); self.assertAlmostEqual(x[2],79,6)
    def test_blended_source_solution(self):
        x=solve_source_flows([{'H2':5,'N2':95},{'N2':100}],{'H2':1,'N2':99},100)
        self.assertAlmostEqual(x[0],20,6); self.assertAlmostEqual(x[1],80,6)
    def test_impossible_solution(self):
        with self.assertRaises(ValueError): solve_source_flows([{'N2':100}],{'H2':1,'N2':99},100)
    def test_outlet(self):
        o=outlet_composition([({'H2':100},1),({'O2':100},20),({'N2':100},79)])
        self.assertAlmostEqual(o['H2'],1); self.assertAlmostEqual(o['O2'],20); self.assertAlmostEqual(o['N2'],79)
    def test_setpoint_configure_does_not_start(self):
        c=Channel(port='Simulator'); c.connect(); c.configure(25); self.assertFalse(c.working); self.assertEqual(c.device.setpoint,0)
    def test_start_stop_and_emergency(self):
        c=Channel(port='Simulator'); c.connect(); c.configure(25); c.start(); self.assertTrue(c.working); self.assertGreater(c.device.setpoint,0); c.stop(); self.assertFalse(c.working); self.assertEqual(c.device.setpoint,0)
        c.configure(10); c.start(); self.assertTrue(c.emergency_stop()); self.assertFalse(c.working); self.assertEqual(c.device.setpoint,0)
    def test_h2_n2_correction_factor(self):
        self.assertAlmostEqual(correction_factor({'H2':5,'N2':95}), 1.0386151797603197, 9)

    def test_set_zero_configuration_does_not_run(self):
        c=Channel(port='Simulator'); c.connect(); c.configure(25); c.start(); c.stop(); c.configure(0); self.assertFalse(c.working); self.assertEqual(c.configured_setpoint,0); self.assertEqual(c.device.setpoint,0)

    def test_disconnected_emergency_unconfirmed(self):
        c=Channel(port='Simulator'); c.connect(); c.configure(10); c.start(); c.device.failed=True; self.assertTrue(c.emergency_stop()) # simulator emergency zero remains reachable as local object

if __name__=='__main__': unittest.main()
