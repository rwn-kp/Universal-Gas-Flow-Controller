import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import unittest
from unittest.mock import patch, Mock
from PySide6.QtWidgets import QApplication, QDialogButtonBox, QTableWidgetItem
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from app import MainWindow
from version import PROJECT_SCHEMA
from ui.composition import GasCompositionDialog, TargetCompositionEditor
from core.gases import BUILTIN_GASES, validate_composition
from core.channel import Channel
from core.modbus import BusPool, SerialBus, ModbusClient, ModbusError, append_crc
from core.devices import PhysicalDevice, PROFILES


class CompositionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.dialog = GasCompositionDialog({'N2': 100}, dict(BUILTIN_GASES))
        self.editor = self.dialog.editor
        self.dialog.show()
        self.app.processEvents()

    def tearDown(self):
        self.dialog.close()

    def test_real_edit_does_not_snap_to_100(self):
        spin = self.editor.rows[0]['pct']
        spin.setFocus(); spin.selectAll()
        QTest.keyClicks(spin, '95'); QTest.keyClick(spin, Qt.Key_Tab)
        self.assertEqual(spin.value(), 95)
        self.assertFalse(self.dialog.buttons.button(QDialogButtonBox.Save).isEnabled())
        QTest.mouseClick(self.editor.add_button, Qt.LeftButton)
        self.assertEqual(len(self.editor.rows), 2)
        row = self.editor.rows[1]
        self.app.processEvents()
        self.assertTrue(row['gas'].isVisible())
        self.assertEqual(row['gas'].currentText(), 'H2')
        row['pct'].setValue(5)
        self.dialog._accept()
        self.assertEqual(self.dialog.composition, {'N2': 95, 'H2': 5})

    def test_balance_and_overfull(self):
        self.editor.set_composition({'H2': 1, 'O2': 20, 'N2': 79})
        rows = self.editor.rows
        self.assertTrue(rows[2]['pct'].isReadOnly())
        rows[0]['pct'].setValue(5)
        self.assertEqual(rows[2]['pct'].value(), 75)
        rows[0]['pct'].setValue(90)
        with self.assertRaises(ValueError): self.editor.composition()
        self.assertEqual(rows[0]['pct'].value(), 90)

    def test_duplicate_and_balance_switch(self):
        self.editor.set_composition({'H2': 5, 'N2': 95})
        rows = self.editor.rows
        rows[0]['gas'].setCurrentText('N2')
        self.assertEqual(rows[0]['gas'].currentText(), 'H2')
        rows[0]['auto'].setChecked(True)
        self.assertFalse(rows[1]['auto'].isChecked())
        self.assertFalse(rows[1]['pct'].isReadOnly())
        remaining = rows[1]
        self.editor.remove_row(rows[0])
        self.assertFalse(remaining['pct'].isReadOnly())

    def test_cancel_does_not_modify_library(self):
        self.dialog.lib['Custom'] = ('Custom', 2)
        self.dialog.reject()
        self.assertNotIn('Custom', BUILTIN_GASES)


class ChannelTests(unittest.TestCase):
    def test_invalid_percentages(self):
        for comp in ({'H2': 5}, {'N2': float('nan')}, {'N2': -1, 'H2': 101}):
            with self.assertRaises(ValueError): validate_composition(comp)

    def test_custom_gas_used_for_commands_and_measurements(self):
        channel = Channel(source={'Custom': 100}, gas_library={'Custom': ('Custom', 2)})
        channel.connect(); channel.configure(50); channel.start()
        self.assertEqual(channel.device.setpoint, 25)
        channel.reading.raw_flow = 10
        self.assertEqual(channel.corrected_flow, 20)
        channel.disconnect()

    def test_nonfinite_setpoints(self):
        for value in (float('nan'), float('inf'), -1):
            with self.assertRaises(ValueError): Channel().configure(value)

    def test_failed_channel_connection_cleanup(self):
        device = Mock(); device.read.side_effect = RuntimeError('link failed')
        with patch('core.channel.PhysicalDevice', return_value=device):
            channel = Channel(port='COM3')
            with self.assertRaises(RuntimeError): channel.connect()
            device.disconnect.assert_called_once()
            self.assertFalse(channel.connected); self.assertIsNone(channel.device)


class BusTests(unittest.TestCase):
    def test_pool_shares_and_rejects_conflicting_baud(self):
        pool = BusPool()
        with patch.object(SerialBus, 'open'), patch.object(SerialBus, 'close') as close:
            a=pool.acquire('COM3',9600); b=pool.acquire('COM3',9600)
            self.assertIs(a,b)
            with self.assertRaises(ModbusError): pool.acquire('COM3',19200)
            pool.release(a); close.assert_not_called()
            pool.release(b); close.assert_called_once()
            self.assertFalse(pool._buses)

    def test_failed_open_does_not_leak(self):
        pool = BusPool()
        with patch.object(SerialBus, 'open', side_effect=OSError('busy')):
            with self.assertRaises(OSError): pool.acquire('COM3',9600)
        self.assertFalse(pool._buses)

    def test_probe_failure_releases_bus(self):
        bus=Mock()
        with patch('core.devices.BUS_POOL') as pool, patch.object(PhysicalDevice,'read_basic',side_effect=ModbusError('no reply')):
            pool.acquire.return_value=bus
            device=PhysicalDevice('COM3',9600,1,PROFILES['MFC-E'])
            with self.assertRaises(ModbusError): device.connect()
            pool.release.assert_called_once_with(bus)
            self.assertIsNone(device.bus)

    def test_multiwrite_echo_must_match_register_and_count(self):
        bus=Mock(); bus.transact.return_value=append_crc(bytes.fromhex('01 10 00 22 00 03'))
        with self.assertRaises(ModbusError): ModbusClient(bus,1).write_multiple(0x21,[0,0,0])

    def test_short_exception_response_is_decoded(self):
        bus=SerialBus('COM3',9600)
        serial=Mock(); serial.in_waiting=5; serial.read.return_value=append_crc(bytes.fromhex('01 90 02'))
        bus._serial=serial
        with patch.object(bus,'open'):
            with self.assertRaisesRegex(ModbusError,'exception code 2'):
                ModbusClient(bus,1).write_multiple(0x21,[0,0,0])


class WindowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.app=QApplication.instance() or QApplication([])
    def setUp(self):
        import tempfile
        self.window=MainWindow(); self.window.poll_timer.stop(); self.window.chart_timer.stop()
        self._rec_dir=tempfile.TemporaryDirectory(); self.window.rec_dir.setText(self._rec_dir.name)
    def tearDown(self): self.window.close(); self._rec_dir.cleanup()

    def test_communication_failure_stops_other_channels_and_latches(self):
        w=self.window
        for c in w.channels: c.connect(); c.configure(10); c.start()
        failed=w.channels[0]
        failed.device.read=Mock(side_effect=RuntimeError('cable removed'))
        failed.device.emergency_zero=Mock(side_effect=RuntimeError('unreachable'))
        w.recipe_running=True; w.mixture_applied=True
        w.poll_all()
        self.assertTrue(w.fail_safe_latched)
        self.assertFalse(w.recipe_running); self.assertFalse(w.mixture_applied)
        self.assertFalse(failed.stop_confirmed); self.assertFalse(failed.connected)
        self.assertEqual(w.channels[1].device.setpoint,0)
        w.cards[1].do_start()
        self.assertEqual(w.channels[1].device.setpoint,0)
        self.assertIn('unconfirmed',w.banner.text().lower() + w.logbox.toPlainText().lower().replace('could not be confirmed','unconfirmed'))

    def test_window_shutdown_sends_zero_and_disconnects(self):
        devices=[]
        for c in self.window.channels:
            c.connect(); c.configure(20); c.start(); devices.append(c.device)
        result=self.window._shutdown_best_effort('test')
        self.assertTrue(all(ok for _,ok in result))
        self.assertTrue(all(d.setpoint==0 and not d.connected for d in devices))

    def test_recipe_rejects_later_invalid_step_before_start(self):
        w=self.window
        for c in w.channels: c.connect()
        w.recipe_table.setItem(1,2,QTableWidgetItem('nan'))
        w.start_recipe()
        self.assertFalse(w.recipe_running)
        self.assertTrue(all(c.device.setpoint==0 for c in w.channels))

    def test_project_roundtrip_preserves_custom_gas_without_start(self):
        w=self.window
        w.gas_library['Custom']=('Custom',2)
        w.channels[0].source={'Custom':100}; w.channels[0].configure(40)
        data=w.project_dict()
        c=Channel.from_dict(data['channels'][0]); c.gas_library=data['gas_library']
        self.assertEqual(c.cmix,2); self.assertEqual(c.configured_setpoint,40)
        self.assertFalse(c.connected); self.assertFalse(c.working)

    def test_valve_cannot_bypass_latch(self):
        w=self.window; c=w.channels[0]; c.connect()
        w.fail_safe_latched=True; w.valve.setValue(80); w.apply_valve()
        self.assertEqual(c.device.setpoint,0)

    def test_recording_keeps_historical_settings_after_channel_removal(self):
        import tempfile, csv
        from pathlib import Path
        w=self.window; c=w.channels[0]; c.connect(); c.configure(10)
        w.start_recording(); w.poll_all(); w.stop_recording()
        rec=w.recordings[-1]
        c.configure(99); c.source={'H2':100}
        w.remove_channel(w.cards[0])
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'recording.csv'
            with patch('app.QFileDialog.getSaveFileName',return_value=(str(path),'')):
                w.export_recording(rec)
            with path.open(encoding='utf-8-sig') as stream: rows=list(csv.reader(stream))
        header=rows[3]; sample=rows[4]
        self.assertEqual(sample[header.index('Channel 1 configured_setpoint')],'10.0')
        self.assertEqual(sample[header.index('Channel 1 source')],'{"N2": 100.0}')

    def test_concentration_recipe_and_mixture_apply(self):
        w=self.window
        w.channels[0].source={'H2':5,'N2':95}
        for c in w.channels: c.connect()
        w.recalculate_mixture(); w.apply_mixture()
        self.assertTrue(w.mixture_applied)
        self.assertAlmostEqual(w.channels[0].configured_setpoint,20)
        self.assertAlmostEqual(w.channels[1].configured_setpoint,80)
        w.emergency_stop_all()
        w.recipe_type.setCurrentIndex(1); w.add_recipe_step()
        for column,text in enumerate(['1','2','H2','1','N2','100','test']):
            w.recipe_table.setItem(0,column,QTableWidgetItem(text))
        w.start_recipe()
        self.assertTrue(w.recipe_running)
        self.assertAlmostEqual(w.channels[0].configured_setpoint,20)
        w.stop_recipe_now('test complete')

    def test_saved_project_loads_disconnected_and_stopped(self):
        import json, tempfile
        from pathlib import Path
        w=self.window
        w.gas_library['Custom']=('Custom',2)
        w.channels[0].source={'Custom':100}; w.channels[0].configure(40)
        project=w.project_dict()
        self.assertEqual(project['schema'],PROJECT_SCHEMA)
        for c in w.channels: c.connect(); c.configure(10); c.start()
        devices=[c.device for c in w.channels]
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'saved project.gfc.json'
            path.write_text(json.dumps(project))
            with patch('app.QFileDialog.getOpenFileName',return_value=(str(path),'')):
                w.load_project()
        self.assertIn('Project loaded',w.banner.text())
        self.assertTrue(all(not c.connected and not c.working for c in w.channels))
        self.assertTrue(all(d.setpoint==0 and not d.connected for d in devices))
        self.assertEqual(w.channels[0].cmix,2)
        self.assertEqual(w.channels[0].configured_setpoint,40)
