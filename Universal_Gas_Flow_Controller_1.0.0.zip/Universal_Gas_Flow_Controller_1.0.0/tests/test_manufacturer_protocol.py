"""Checks against the worked examples in the Xinnovis documents in 'Related Docs':
MFC_ComP_RS485-RS232(MODBUS) v1.0.1, S500-S300_ComP_RS485-RS232(MODBUS) v1.0.0 and the MFC-E/S300 user manuals v2.0.0."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import time, unittest
from core.modbus import ModbusClient, ModbusError, append_crc
from core.devices import PhysicalDevice, PROFILES, scan_port
from core.channel import Channel
from core.gases import outlet_concentration_uncertainty

h=bytes.fromhex

class FakeBus:
    """Records requests and answers from a {request-without-CRC: response-hex} table (responses include CRC)."""
    def __init__(self, answers=None, baud=9600, alive=True):
        self.answers=answers or {}; self.sent=[]; self.baud=baud; self.alive=alive
    def open(self): pass
    def close(self): pass
    def transact(self, request, expected_min=5):
        self.sent.append(request)
        if not self.alive: raise ModbusError('No valid Modbus response')
        key=request[:-2].hex()
        if key in self.answers: return h(self.answers[key])
        if request[1]==0x10 or request[1]==0x06: return request[:6]+append_crc(request[:6])[-2:]
        raise ModbusError('No valid Modbus response')

def device(profile, answers=None):
    d=PhysicalDevice('COM3',9600,1,PROFILES[profile]); d.bus=FakeBus(answers); d.client=ModbusClient(d.bus,1); return d

class RequestFrames(unittest.TestCase):
    def test_mfce_set_flow_method2(self):            # MFC doc example 6, method 2: 123.4 SCCM
        d=device('MFC-E'); d.set_flow(123.4)
        self.assertEqual(d.bus.sent[-1],h('01 10 00 21 00 03 06 00 00 00 00 30 34 A3 F8'))
    def test_s300_set_flow_method2(self):            # S300 doc example 5, method 2: 12.34 SCCM (x0.001)
        d=device('S300-new'); d.set_flow(12.34)
        self.assertEqual(d.bus.sent[-1],h('01 10 00 21 00 03 06 00 00 00 00 30 34 A3 F8'))
    def test_valve_opening_method2(self):            # example 7 (MFC) / 6 (S300): 12.34 %
        d=device('MFC-E'); d.valve_opening(12.34)
        self.assertEqual(d.bus.sent[-1],h('01 10 00 21 00 04 08 00 03 00 00 00 00 04 D2 7B 9B'))
    def test_clear_accumulated(self):                # example 5 (MFC) / 4 (S300)
        d=device('MFC-E'); d.clear_accumulated()
        self.assertEqual(d.bus.sent[-1],h('01 10 00 18 00 04 08 00 00 00 00 00 00 00 00 96 5A'))
    def test_zero_and_factory(self):                 # examples 11/12
        d=device('MFC-E'); d.zero_calibration(); d.factory_restore()
        self.assertEqual(d.bus.sent[-2],h('01 06 00 25 00 01 59 C1')); self.assertEqual(d.bus.sent[-1],h('01 06 00 25 00 02 19 C0'))
    def test_read_isolated_address(self):            # example 8
        bus=FakeBus({'fe0300000001':'FE 03 02 00 01 6D 90'})
        self.assertEqual(ModbusClient(bus,0xFE).read_regs(0x0000,1),[1]); self.assertEqual(bus.sent[-1],h('FE 03 00 00 00 01 90 05'))
    def test_emergency_zero_is_flow_mode_zero(self):
        d=device('S300-new'); d.emergency_zero()
        self.assertEqual(d.bus.sent[-1],append_crc(h('01 10 00 21 00 03 06 00 00 00 00 00 00')))

class ResponseDecoding(unittest.TestCase):
    BASIC={'010300030003':'01 03 06 00 0D 00 64 00 0A CD 6C'}            # example 1: N2, 100, SCCM
    ACCUM={'010300180009':'01 03 12 00 00 00 00 07 5B CD 15 00 00 27 10 00 0A 00 32 00 1E 6E F9'}
    def test_mfce_reading(self):
        regs=append_crc(h('01 03 06 FF 85 00 00 30 34')).hex()            # examples 2+3: -12.3 C, 123.4
        d=device('MFC-E',{**self.BASIC,**self.ACCUM,'010300150003':regs}); r=d.read()
        self.assertEqual((r.calibration_gas,r.full_scale,r.flow_unit),('N2',100.0,'SCCM'))
        self.assertAlmostEqual(r.temperature,-12.3); self.assertAlmostEqual(r.raw_flow,123.4)
        self.assertAlmostEqual(r.accumulated,123456.789); self.assertEqual(r.elapsed_s,10000*86400+10*3600+50*60+30)
    def test_s300_reading_with_decimal_register(self): # S300 example 2: 3 decimals, 25.3 C, 12.345
        d=device('S300-new',{**self.BASIC,'010300140004':'01 03 08 00 01 00 FD 00 00 30 39 3C D1'}); r=d.read()
        self.assertAlmostEqual(r.temperature,25.3); self.assertAlmostEqual(r.raw_flow,12.345)
    def test_integer_flow_reporting(self):          # decimal code 2 (seen on the lab S300D, 500 SCCM): whole SCCM
        regs=append_crc(h('01 03 08 00 02 01 0E 00 00 00 13')).hex()
        r=device('S300-new',{**self.BASIC,'010300140004':regs}).read()
        self.assertEqual((r.raw_flow,r.resolution,r.temperature),(19.0,1.0,27.0))
    def test_unknown_decimal_code_rejected(self):
        regs=append_crc(h('01 03 08 00 09 00 FD 00 00 30 39')).hex()
        with self.assertRaisesRegex(ModbusError,'decimal code'): device('S300-new',{**self.BASIC,'010300140004':regs}).read()
    def test_hydrogen_calibrated_device(self):
        basic={'010300030003':append_crc(h('01 03 06 00 07 00 0A 00 0A')).hex()}
        regs=append_crc(h('01 03 06 00 FA 00 00 03 E8')).hex()
        r=device('MFC-E',{**basic,'010300150003':regs}).read()
        self.assertEqual(r.calibration_gas,'H2')
        c=Channel(source={'H2':100}); c.reading=r
        self.assertAlmostEqual(c.cmix,1.0)                                  # no conversion for its own gas
        c.reading.calibration_gas='N2'; self.assertAlmostEqual(c.cmix,3.9)  # manual appendix: H2 = 3.900

class Specifications(unittest.TestCase):
    def test_accuracy_rules(self):
        e,s=PROFILES['MFC-E'],PROFILES['S300-new']
        self.assertAlmostEqual(e.accuracy(10,100),0.8); self.assertAlmostEqual(e.accuracy(100,100),1.0)   # max(0.8% FS, 1% SP)
        self.assertAlmostEqual(s.accuracy(20,100),0.3); self.assertAlmostEqual(s.accuracy(50,100),0.5)    # 0.3% FS <=30% FS, else 1% SP
        self.assertEqual((e.min_fraction,s.min_fraction),(0.01,0.02))                                     # range ratio 100:1 / 50:1
    def test_setpoint_resolution(self):
        self.assertAlmostEqual(PROFILES['MFC-E'].quantize(0.126),0.13); self.assertAlmostEqual(PROFILES['S300-new'].quantize(0.1234),0.123)
    def test_concentration_uncertainty(self):
        # 100 ppm from a 1% premix (4 SCCM on 100 SCCM FS, +/-0.8) in 396 SCCM N2 (+/-3.96)
        conc,err=outlet_concentration_uncertainty([({'H2':1,'N2':99},4,0.8),({'N2':100},396,3.96)],'H2')
        self.assertAlmostEqual(conc,0.01)
        self.assertAlmostEqual(err,(((1-0.01)/400*0.8)**2+((0-0.01)/400*3.96)**2)**0.5)   # dC/dq_i = (c_i - C)/Q
        self.assertGreater(err/conc,0.19)    # a low-range premix setpoint dominates: ~20% of the concentration

class Scanning(unittest.TestCase):
    def test_scan_finds_baud_and_addresses(self):
        def factory(port,baud):
            answers={} if baud!=19200 else {'010300030003':'01 03 06 00 0D 00 64 00 0A CD 6C','030300030003':append_crc(h('03 03 06 00 07 00 0A 00 0A')).hex()}
            return FakeBus(answers,baud)
        found=scan_port('COM3',bauds=(9600,19200,115200),addresses=range(1,5),bus_factory=factory)
        self.assertEqual([(d['baud'],d['address'],d['gas']) for d in found],[(19200,1,'N2'),(19200,3,'H2')])
    def test_scan_cancel(self):
        self.assertEqual(scan_port('COM3',bauds=(9600,),progress=lambda t:False,bus_factory=lambda p,b:FakeBus()),[])

class Tracking(unittest.TestCase):
    def test_overflow_detected_for_wrong_model_scale(self):
        # an MFC-E driven with the S300 profile receives 10x the intended setpoint
        c=Channel(); c.connect(); c.configure(20); c.start()
        self.assertEqual(c.check_overflow(),'')
        c.setpoint_since=time.monotonic()-10; c.device.flow=200.0; c.device.setpoint=200.0
        msgs=[(c.poll(),c.check_overflow())[1] for _ in range(2)]
        self.assertFalse(msgs[0]); self.assertIn('selected model',msgs[1])
    def test_no_flow_detected_after_settling(self):    # seen on the lab MFC-E with the N2 supply closed
        c=Channel(); c.connect(); c.configure(100); c.start()
        c.device.set_flow(0); c.device.flow=0                # gas does not arrive
        self.assertEqual(c.check_no_flow(),'')                # within settling time (start-up dead time)
        c.setpoint_since=time.monotonic()-10
        msgs=[(c.poll(),c.check_no_flow())[1] for _ in range(4)]
        self.assertFalse(any(msgs[:3])); self.assertIn('Open the cylinder',msgs[3])
    def test_no_flow_not_judged_below_reliable_range(self):
        c=Channel(); c.connect(); c.configure(0.5); c.start(); c.setpoint_since=time.monotonic()-10; c.device.flow=0
        self.assertFalse(any((c.poll(),c.check_no_flow())[1] for _ in range(6)))
    def test_valve_drive_read_with_totalizer(self):
        regs=append_crc(bytes.fromhex('01 03 1a'+'0000'*3+'18ee'+'0000'*2+'0006'+'0028'+'0032'+'0000'+'0000'+'2710'+'1db0')).hex()
        d=device('MFC-E',{'010300030003':'01 03 06 00 0D 00 64 00 0A CD 6C','010300150003':append_crc(bytes.fromhex('01 03 06 01 45 00 00 00 00')).hex(),'01030018000d':regs})
        r=d.read(); self.assertAlmostEqual(r.valve,76.0); self.assertAlmostEqual(r.accumulated,6.382)
    def test_overflow_ignores_normal_flow_and_decreasing_setpoint_transients(self):
        c=Channel(); c.connect(); c.configure(100); c.start(); c.setpoint_since=time.monotonic()-10
        c.device.flow=c.device.setpoint=100.0
        self.assertFalse(any((c.poll(),c.check_overflow())[1] for _ in range(3)))
        c.configure(20); c.start(); c.device.flow=100.0     # just lowered: still above, within settling time
        self.assertEqual(c.check_overflow(),'')
    def test_no_flow_warning_after_settling(self):
        c=Channel(); c.connect(); c.configure(50); c.start()
        self.assertEqual(c.check_tracking(),'')                 # still settling
        c.setpoint_since=time.monotonic()-10; c.device.set_flow(0); c.device.flow=0   # e.g. closed cylinder valve
        msgs=[(c.poll(),c.check_tracking())[1] for _ in range(4)]
        self.assertFalse(any(msgs[:3])); self.assertIn('cylinder valve',msgs[3])
        self.assertEqual(c.check_tracking(),'')                  # reported once
        self.assertTrue(c.tracking_warning)

from unittest.mock import patch
from PySide6.QtWidgets import QApplication, QMessageBox

class WindowDeviceTools(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.app=QApplication.instance() or QApplication([])
    def setUp(self):
        from app import MainWindow
        self.w=MainWindow(); self.w.poll_timer.stop(); self.w.chart_timer.stop()
    def tearDown(self): self.w.close()

    def test_zero_calibration_blocked_while_flowing_and_confirmed(self):
        w=self.w; c=w.channels[0]; c.connect(); c.configure(10); c.start(); w.refresh_tools_channels()
        with patch.object(c.device,'zero_calibration') as zero:
            w.tools_zero(); zero.assert_not_called()
            c.stop()
            with patch('app.QMessageBox.question',return_value=QMessageBox.No): w.tools_zero()
            zero.assert_not_called()
            with patch('app.QMessageBox.question',return_value=QMessageBox.Yes): w.tools_zero()
            zero.assert_called_once()

    def test_device_info_and_expected_concentration(self):
        w=self.w; w.channels[0].source={'H2':1,'N2':99}
        for c in w.channels: c.connect()
        w.refresh_tools_channels(); self.assertIn('Calibrated for N2',w.tools_info.text()); self.assertIn('0.8% FS',w.tools_info.text())
        w.target_editor.set_composition({'H2':0.5,'N2':99.5}); w.recalculate_mixture(); w.apply_mixture(); w.poll_all()
        self.assertIn('Expected',w.summary.text()); self.assertIn('±',w.summary.text())
        self.assertIn('±',w.solver_status.text())

    def test_uncertain_step_flagged_even_inside_range(self):
        from PySide6.QtWidgets import QTableWidgetItem
        w=self.w; w.channels[0].source={'H2':1,'N2':99}
        for c in w.channels: c.connect()
        w.recipe_type.setCurrentIndex(1); w.conc_unit.setCurrentText('ppm'); w.recipe_table.setRowCount(0); w.add_recipe_step()
        for col,text in enumerate(['','5','H2','150','N2','100','']): w.recipe_table.setItem(0,col,QTableWidgetItem(text))
        warnings=w.parse_recipe()[0]['warnings']
        self.assertEqual(len(warnings),1); self.assertIn('exceeds ±10%',warnings[0])   # 1.5 SCCM = 1.5% FS: in range, but ±0.8 SCCM

    def test_s300_address_write_refused(self):
        w=self.w; c=w.channels[0]; c.port='COM9'; c.profile_key='S300-new'; w.refresh_tools_channels()
        w.assign_isolated_address(); self.assertIn('rotary switches',w.banner.text())

if __name__=='__main__': unittest.main()
