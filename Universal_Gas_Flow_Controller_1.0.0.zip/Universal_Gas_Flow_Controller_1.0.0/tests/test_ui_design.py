"""Interface checks: the window fits small laptop screens, no text is clipped, limits are enforced and shown,
charts navigate predictably, recipe errors are visible before running, and the Windows launch path is used."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import tempfile, unittest
from pathlib import Path
from unittest.mock import patch
from PySide6.QtCore import Qt
from PySide6.QtGui import QFontMetrics
from PySide6.QtWidgets import QApplication, QLabel, QAbstractButton, QTableWidgetItem, QMessageBox
from app import MainWindow
from ui.widgets import ElidedLabel
from ui.chart import ChartGroup, nice_ticks, tick_label
import launcher


class Layout(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.app = QApplication.instance() or QApplication([])
    def setUp(self):
        self.w = MainWindow(); self.w.poll_timer.stop(); self.w.chart_timer.stop()
        self.folder = tempfile.TemporaryDirectory(); self.w.rec_dir.setText(self.folder.name)
        self.w.channels[0].source = {'H2': 1, 'N2': 99}
        for c in self.w.channels: c.connect()
        for card in self.w.cards: card.update_all()
    def tearDown(self): self.w.close(); self.folder.cleanup()

    def test_fits_small_screens(self):
        hint = self.w.minimumSizeHint()
        self.assertLessEqual(hint.height(), 640, 'window must fit a 1366x768 laptop with taskbar')
        self.assertLessEqual(hint.width(), 1000)

    def clipped(self):
        problems = []
        for lab in self.w.findChildren(QLabel):
            if not lab.isVisible() or not lab.text().strip() or lab.width() < 5 or isinstance(lab, ElidedLabel):   # elided labels end with … and show the full text as tooltip
                continue
            if lab.wordWrap():
                if lab.heightForWidth(lab.width()) > lab.height() + 1: problems.append(lab.text()[:60])
            elif QFontMetrics(lab.font()).horizontalAdvance(lab.text()) > lab.contentsRect().width() + 1 and '<' not in lab.text():
                problems.append(lab.text()[:60])
        for b in self.w.findChildren(QAbstractButton):
            if b.isVisible() and b.text() and b.sizeHint().width() > b.width() + 2:
                problems.append('button ' + b.text())
        return problems

    def test_no_clipped_text_in_any_tab(self):
        self.w.show()
        for size in ((1280, 720), (1000, 600)):
            self.w.resize(*size)
            for i in range(self.w.tabs.count()):
                self.w.tabs.setCurrentIndex(i); self.app.processEvents(); self.app.processEvents()
                self.assertEqual(self.clipped(), [], f'{self.w.tabs.tabText(i)} at {size}')

    def test_setpoint_limited_to_device_maximum_and_limits_shown(self):
        card = self.w.cards[0]; c = card.channel
        self.assertAlmostEqual(card.setpoint.maximum(), c.reading.full_scale * c.cmix, places=2)   # rounded down to 3 decimals
        card.setpoint.setValue(1e6); self.assertLessEqual(card.setpoint.value(), c.reading.full_scale * c.cmix)
        self.assertIn('Allowed 0 –', card.limits.text()); self.assertIn('reliable from', card.limits.text())
        card.setpoint.setValue(0.5)
        self.assertTrue(card.hint.isVisibleTo(card)); self.assertIn('below the reliable range', card.hint.text())

    def test_running_setpoint_can_be_changed_without_stopping(self):
        card = self.w.cards[1]
        card.setpoint.setValue(20); card.do_start(); self.assertEqual(card.channel.device.setpoint, 20)
        self.assertEqual(card.start.text(), 'Apply new setpoint')
        card.setpoint.setValue(30); card.do_start(); self.assertEqual(card.channel.device.setpoint, 30)
        self.assertTrue(card.channel.working)

    def test_simulator_is_clearly_marked(self):
        self.assertTrue(self.w.cards[0].sim_pill.isVisibleTo(self.w.cards[0]))
        self.w.update_summary(); self.assertIn('SIMULATOR', self.w.summary.text())

    def test_mixture_shows_allowed_total_flow(self):
        self.w.target_editor.set_composition({'H2': 0.5, 'N2': 99.5}); self.w.recalculate_mixture()
        self.assertIn('Allowed total flow for this target: up to', self.w.mix_limits.text())
        self.w.total_flow.setValue(500); self.w.recalculate_mixture()       # needs 250 SCCM of premix > 100.75
        self.assertFalse(self.w.apply_mix.isEnabled()); self.assertTrue(self.w.solver_status.text().startswith('✗'))

    def test_recipe_errors_marked_before_running_and_table_locked_while_running(self):
        w = self.w; w.recipe_type.setCurrentIndex(1); w.conc_unit.setCurrentText('ppm'); w.recipe_table.setRowCount(0)
        for row in (['', '5', 'H2', '5000', 'N2', '100', 'ok'], ['', 'x', 'H2', '100', 'N2', '100', 'bad duration'], ['', '5', 'H2', '50000', 'N2', '100', 'too high']):
            w.add_recipe_step()
            for col, text in enumerate(row): w.recipe_table.setItem(w.recipe_table.rowCount() - 1, col, QTableWidgetItem(text))
        w.validate_recipe_table()
        self.assertIn('Step 2: duration must be a number', w.recipe_check.text())
        self.assertIn('duration must be a number', w.recipe_table.item(1, 0).toolTip())
        self.assertTrue(w.recipe_table.item(2, 0).toolTip())                  # 5% from a 1% premix is impossible
        self.assertIn('up to', w.recipe_limits.text())
        w.recipe_table.removeRow(2); w.recipe_table.removeRow(1); w.start_recipe()
        self.assertTrue(w.recipe_running); w.update_summary()
        self.assertEqual(w.recipe_table.editTriggers(), w.recipe_table.EditTrigger.NoEditTriggers)
        w.stop_recipe_now('done'); w.update_summary()
        self.assertNotEqual(w.recipe_table.editTriggers(), w.recipe_table.EditTrigger.NoEditTriggers)

    def test_close_by_user_asks_while_flowing(self):
        from PySide6.QtGui import QCloseEvent
        card = self.w.cards[1]; card.setpoint.setValue(10); card.do_start()
        with patch('app.QMessageBox.question', return_value=QMessageBox.No) as ask:
            ev = QCloseEvent(); ev.setAccepted(True)
            with patch.object(QCloseEvent, 'spontaneous', return_value=True): self.w.closeEvent(ev)
            ask.assert_called_once(); self.assertFalse(ev.isAccepted()); self.assertTrue(card.channel.working)


class ChartNavigation(unittest.TestCase):
    def test_live_span_pan_zoom(self):
        g = ChartGroup(300); g.set_data_range(1000.0, 5000.0)
        self.assertEqual(g.view(), (4700.0, 5000.0))
        g.pan(-600); self.assertFalse(g.live); self.assertEqual(g.view(), (4100.0, 4400.0))
        g.zoom(0.5, anchor=4250.0); self.assertAlmostEqual(g.view()[1] - g.view()[0], 150.0)
        g.go_live(); self.assertTrue(g.live); self.assertEqual(g.view()[1], 5000.0)
        g.set_span(None); self.assertEqual(g.view(), (1000.0, 5000.0))
        g.set_span(300); g.pan(10_000); self.assertTrue(g.live)               # panning past "now" returns to live

    def test_ticks(self):
        t = nice_ticks(0, 2500); self.assertEqual([tick_label(x, t[1] - t[0]) for x in t], ['0', '500', '1,000', '1,500', '2,000', '2,500'])
        t = nice_ticks(0, 0.013); self.assertEqual(tick_label(t[1], t[1] - t[0]), '0.005')


class WindowsLaunch(unittest.TestCase):
    def test_windows_environment_path(self):
        from types import SimpleNamespace
        with patch.object(launcher, 'os', SimpleNamespace(name='nt')):
            self.assertEqual(launcher.environment_python(Path('C:/app')), Path('C:/app/.venv/Scripts/python.exe'))

    def test_batch_files_use_crlf(self):
        root = Path(__file__).resolve().parent.parent
        for name in ('START_GAS_FLOW_CONTROLLER.bat', 'build_windows.bat'):
            data = (root / name).read_bytes()
            self.assertNotIn(b'\n', data.replace(b'\r\n', b''), name)


if __name__ == '__main__': unittest.main()


class OverflowFailSafe(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.app = QApplication.instance() or QApplication([])
    def test_window_stops_all_flows_on_overflow(self):
        import time
        w = MainWindow(); w.poll_timer.stop(); w.chart_timer.stop()
        try:
            for c in w.channels: c.connect(); c.configure(20); c.start()
            bad = w.channels[0]; bad.setpoint_since = time.monotonic() - 10
            bad.device.read = lambda: __import__('core.devices', fromlist=['Reading']).Reading(raw_flow=200.0)
            w.poll_all(); w.poll_all()
            self.assertTrue(w.fail_safe_latched)
            self.assertTrue(all(not c.working for c in w.channels))
            self.assertIn('above setpoint', w.banner.text())
        finally:
            w.close()


class SequencedSwitching(unittest.TestCase):
    """The S300D needs ~3 s to start from 0 while the carrier reacts at once; without sequencing the total flow would dip ~9%."""
    @classmethod
    def setUpClass(cls): cls.app = QApplication.instance() or QApplication([])
    def setUp(self):
        self.w = MainWindow(); self.w.poll_timer.stop(); self.w.chart_timer.stop()
        self.prem, self.carrier = self.w.channels
        for c in self.w.channels: c.connect()
        self.carrier.configure(100); self.carrier.start()
    def tearDown(self): self.w.close()

    def test_carrier_reduction_waits_for_premix_flow(self):
        from PySide6.QtTest import QTest
        w = self.w
        w.apply_flows([(self.prem, 10.0), (self.carrier, 90.0)])
        self.assertEqual(self.carrier.device.setpoint, 100)        # held
        self.assertEqual(self.prem.device.setpoint, 10)
        QTest.qWait(300); self.assertEqual(self.carrier.device.setpoint, 100)   # premix reading not updated yet
        w.poll_all(); QTest.qWait(300); w.poll_all(); QTest.qWait(300)
        self.assertEqual(self.carrier.device.setpoint, 90)         # applied once the premix flows

    def test_held_change_is_cancelled_by_stop_all(self):
        from PySide6.QtTest import QTest
        w = self.w
        w.apply_flows([(self.prem, 10.0), (self.carrier, 90.0)])
        w.emergency_stop_all('test stop')
        w.poll_all(); QTest.qWait(400); w.poll_all(); QTest.qWait(400)
        self.assertEqual(self.carrier.device.setpoint, 0); self.assertFalse(self.carrier.working)
        self.assertEqual(self.prem.device.setpoint, 0)

    def test_switch_off_applies_everything_at_once(self):
        self.w.sequence_switch.setChecked(False)
        self.w.apply_flows([(self.prem, 10.0), (self.carrier, 90.0)])
        self.assertEqual(self.carrier.device.setpoint, 90)

    def test_arrival_time_reported(self):
        import time
        c = self.prem; c.configure(50); c.start(); c._step = (time.monotonic() - 2.5, 0.0, 50.0)
        c.reading.raw_flow = 10; self.assertIsNone(c.step_arrival())
        c.reading.raw_flow = 30; dt = c.step_arrival(); self.assertAlmostEqual(dt, 2.5, delta=0.2)
        self.assertIsNone(c.step_arrival())                          # reported once


class Timing(unittest.TestCase):
    """Qt's default (coarse) timer may fire up to 5% early or late, i.e. ±1 s on a 20 s step, so recipe and sampling timers must be precise."""
    @classmethod
    def setUpClass(cls): cls.app = QApplication.instance() or QApplication([])
    def test_recipe_and_sampling_timers_are_precise(self):
        w = MainWindow(); w.chart_timer.stop()
        try:
            self.assertEqual(w.poll_timer.timerType(), Qt.PreciseTimer)
            for c in w.channels: c.connect()
            w.recipe_type.setCurrentIndex(1); w.recipe_table.setRowCount(0); w.add_recipe_step()
            for col, text in enumerate(['', '20', 'H2', '0', 'N2', '100', '']): w.recipe_table.setItem(0, col, QTableWidgetItem(text))
            w.start_recipe(); self.assertTrue(w.recipe_running)
            self.assertEqual(w.recipe_timer.timerType(), Qt.PreciseTimer)
            w.stop_recipe_now('done')
        finally:
            w.close()
