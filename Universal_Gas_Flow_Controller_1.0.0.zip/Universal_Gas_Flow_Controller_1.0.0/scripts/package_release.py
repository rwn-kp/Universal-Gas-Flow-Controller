"""Build a portable source ZIP for another computer (Windows or macOS).

Excludes machine-local items (.venv, caches, recordings, build output) and keeps the executable bit of the
macOS launcher so it can be double-clicked after unzipping. Run:  python scripts/package_release.py
"""
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import stat
import sys

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from version import VERSION  # noqa: E402

SKIP_DIRS = {'.venv', '__pycache__', 'dist', 'build', 'recordings', '.git'}
SKIP_FILES = {'.DS_Store', 'Thumbs.db', '.write_test'}
TOP_FILES = ['app.py', 'launcher.py', 'version.py', 'requirements.txt', 'START_HERE.txt', 'README.md', 'HANDOVER.md', 'TEST_RESULTS_HARDWARE.md',
             'START_GAS_FLOW_CONTROLLER.bat', 'START_GAS_FLOW_CONTROLLER.command', 'build_windows.bat', 'build_macos.sh']
EXECUTABLE = {'.command', '.sh'}


def collect_files():
    """Source files to distribute (no machine-local environments, caches, recordings or build output)."""
    files = [root / f for f in TOP_FILES]
    for folder in ['core', 'ui', 'tests', 'examples', 'docs', 'scripts']:
        files += [p for p in sorted((root / folder).rglob('*'))
                  if p.is_file() and not SKIP_DIRS & set(p.relative_to(root).parts) and p.name not in SKIP_FILES and p.suffix != '.pyc']
    missing = [str(f.relative_to(root)) for f in files if not f.exists()]
    if missing:
        raise SystemExit(f'Missing files: {missing}')
    return files


def main():
    name = f'Universal_Gas_Flow_Controller_{VERSION}'
    out = root / 'dist' / f'{name}.zip'
    out.parent.mkdir(exist_ok=True)
    files = collect_files()
    with ZipFile(out, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            info = ZipInfo.from_file(path, f'{name}/{path.relative_to(root).as_posix()}')
            mode = 0o755 if path.suffix in EXECUTABLE else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            info.compress_type = ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())

    with ZipFile(out) as archive:
        names = archive.namelist()
        assert archive.testzip() is None, 'CRC check failed'
        assert not any(part in SKIP_DIRS for n in names for part in n.split('/')), 'machine-local folder packed'
        launcher = archive.getinfo(f'{name}/START_GAS_FLOW_CONTROLLER.command')
        assert (launcher.external_attr >> 16) & 0o111, 'macOS launcher is not executable'
        bat = archive.read(f'{name}/START_GAS_FLOW_CONTROLLER.bat')
        assert b'\n' not in bat.replace(b'\r\n', b''), 'Windows launcher lost CRLF line endings'
    print(f'{out}\n{len(names)} files, {out.stat().st_size / 1e6:.1f} MB; CRC, permissions and line endings verified')


if __name__ == '__main__':
    main()
