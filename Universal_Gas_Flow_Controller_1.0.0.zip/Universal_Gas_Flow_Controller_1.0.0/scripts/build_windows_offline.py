"""Build an offline, install-free Windows package (64-bit Windows 10/11).

It bundles the official embeddable Python from python.org with the Windows wheels of PySide6-Essentials,
numpy and pyserial pre-installed, so the target laptop needs neither Python nor internet. This script can run
on macOS or Windows (it only downloads and unpacks; nothing is compiled). Run:

    python scripts/build_windows_offline.py

Downloads are cached in build/win_cache. Output: dist/GasFlowController_<version>_Windows_offline.zip
"""
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import urllib.request
import zipfile

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from version import VERSION  # noqa: E402
from scripts.package_release import collect_files  # noqa: E402

PY_VERSION = '3.12.10'          # last 3.12 release with Windows binaries; numpy/PySide6 wheels exist for it
PY_TAG = 'python312'
EMBED_URL = f'https://www.python.org/ftp/python/{PY_VERSION}/python-{PY_VERSION}-embed-amd64.zip'
# Versions tested with the app (86 automated tests). PySide6-Essentials holds QtCore/QtGui/QtWidgets/QtSvg.
PACKAGES = ['PySide6-Essentials==6.12.0', 'shiboken6==6.12.0', 'numpy==2.5.3', 'pyserial==3.5']
# Not used by this Qt Widgets app; removed to keep the package small.
PRUNE = ['PySide6/qml', 'PySide6/include', 'PySide6/typesystems', 'PySide6/glue', 'PySide6/scripts', 'PySide6/translations/qtwebengine_locales']
PRUNE_GLOBS = ['PySide6/Qt6Quick*.dll', 'PySide6/Qt6Qml*.dll', 'PySide6/QtQuick*.pyd', 'PySide6/QtQml*.pyd', 'PySide6/Qt6Designer*.dll',
               'PySide6/QtDesigner*.pyd', 'PySide6/*.exe', 'PySide6/*.pyi', 'shiboken6/*.pyi', 'numpy/**/tests', 'numpy/**/*.pyi']

name = f'GasFlowController_{VERSION}_Windows_offline'
cache = root / 'build' / 'win_cache'
stage = root / 'build' / 'win_offline' / name
out = root / 'dist' / f'{name}.zip'

BAT = r'''@echo off
setlocal
cd /d "%~dp0"
if not exist "runtime\python.exe" (
  echo The "runtime" folder is missing.
  echo Extract the whole ZIP first: right-click the ZIP - Extract All - then run this file from the extracted folder.
  pause
  exit /b 1
)
echo Starting Universal Gas Flow Controller... Keep this window open; error messages appear here.
"runtime\python.exe" app.py
if errorlevel 1 (
  echo.
  echo The program exited with an error. See the details above.
  pause
  exit /b 1
)
endlocal
'''

GUIDE = f'''UNIVERSAL GAS FLOW CONTROLLER {VERSION} - OFFLINE WINDOWS PACKAGE
==============================================================

No installation and no internet needed. Python {PY_VERSION} and all libraries are inside the "runtime" folder.
Requires 64-bit Windows 10 or 11.

1. Copy the ZIP to the laptop (USB stick is fine).
2. Right-click the ZIP -> Extract All... and choose a SHORT folder, for example  C:\\GasFlow
   (Program Files and very long paths can cause problems). Do not run it from inside the ZIP.
3. Open the extracted folder and double-click  START_GAS_FLOW_CONTROLLER.bat
   - If Windows SmartScreen shows "Windows protected your PC": More info -> Run anyway.
   - A black window opens first: keep it open; it shows error messages if something fails.

Flow controllers
- The PSC-100/PSC-200 converter uses a CH340 USB-serial chip. If it does not appear as a COM port
  (Device Manager -> Ports (COM & LPT)), install the CH341SER driver (see "Related Docs"/SmartFlow manual;
  this needs a one-time download or a copy of the driver on the USB stick).
- In the program: Channels -> Port (COMx), Model, Address, Baud -> Connect.
  If unsure: Device Tools -> Find devices. Practise first with the Simulator port (no gas flows).

Data
- Recordings are written to the "recordings" folder next to the program
  (or Documents\\Gas Flow Recordings if this folder is read-only).
- Projects (.gfc.json) and recipes (.json) from another computer open with Load project / Load recipe.

Help -> Quick guide and safety notes inside the program summarises operation. README.md has the details.
'''


def run(cmd):
    print('>', ' '.join(str(c) for c in cmd))
    subprocess.run([str(c) for c in cmd], check=True)


def main():
    cache.mkdir(parents=True, exist_ok=True)
    embed = cache / Path(EMBED_URL).name
    if not embed.exists():
        print(f'Downloading {EMBED_URL}')
        urllib.request.urlretrieve(EMBED_URL, embed)
    with zipfile.ZipFile(embed) as z:
        assert z.testzip() is None and 'python.exe' in z.namelist(), 'embeddable Python download is damaged'

    if stage.parent.exists():
        shutil.rmtree(stage.parent)
    runtime = stage / 'runtime'
    site = runtime / 'Lib' / 'site-packages'
    site.mkdir(parents=True)
    with zipfile.ZipFile(embed) as z:
        z.extractall(runtime)
    # ._pth defines sys.path for embedded Python: stdlib zip, runtime, site-packages and the app folder (..).
    (runtime / f'{PY_TAG}._pth').write_text(f'{PY_TAG}.zip\n.\nLib\\site-packages\n..\nimport site\n', encoding='ascii', newline='\r\n')

    wheels = cache / 'wheels'
    run([sys.executable, '-m', 'pip', 'download', '--only-binary=:all:', '--platform', 'win_amd64', '--python-version', PY_VERSION.rsplit('.', 1)[0],
         '--implementation', 'cp', '--no-deps', '-d', wheels, *PACKAGES])
    for whl in sorted(wheels.glob('*.whl')):
        if not any(whl.name.lower().startswith(p.split('==')[0].lower().replace('-', '_')) and p.split('==')[1] in whl.name for p in PACKAGES):
            continue
        with zipfile.ZipFile(whl) as z:          # a wheel is a zip laid out as site-packages
            z.extractall(site)
        print('  unpacked', whl.name)

    for rel in PRUNE:
        shutil.rmtree(site / rel, ignore_errors=True)
    for pattern in PRUNE_GLOBS:
        for p in site.glob(pattern):
            shutil.rmtree(p) if p.is_dir() else p.unlink()

    # application files (same selection as the portable source ZIP), without the macOS/launcher-only items
    for src in collect_files():
        rel = src.relative_to(root)
        if rel.name in ('START_GAS_FLOW_CONTROLLER.command', 'build_macos.sh', 'START_HERE.txt', 'START_GAS_FLOW_CONTROLLER.bat'):
            continue
        dst = stage / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    (stage / 'START_GAS_FLOW_CONTROLLER.bat').write_text(BAT.replace('\r\n', '\n'), encoding='ascii', newline='\r\n')
    (stage / 'START_HERE.txt').write_text(GUIDE, encoding='utf-8', newline='\r\n')

    verify_stage(site)
    out.parent.mkdir(exist_ok=True)
    out.unlink(missing_ok=True)
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(stage.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:
                info = zipfile.ZipInfo.from_file(p, f'{name}/{p.relative_to(stage).as_posix()}')
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(info, p.read_bytes())
    with zipfile.ZipFile(out) as z:
        names = z.namelist()
        assert z.testzip() is None, 'CRC check failed'
        longest = max(len(n) for n in names)
    size = sum(p.stat().st_size for p in stage.rglob('*') if p.is_file())
    print(f'\n{out}\n{len(names)} files, ZIP {out.stat().st_size / 1e6:.0f} MB, extracted {size / 1e6:.0f} MB')
    print(f'Longest path inside: {longest} characters -> extract to a folder shorter than {259 - longest} characters (e.g. C:\\GasFlow)')


def verify_stage(site):
    need = ['runtime/python.exe', 'runtime/pythonw.exe', f'runtime/{PY_TAG}.dll', f'runtime/{PY_TAG}.zip', f'runtime/{PY_TAG}._pth',
            'runtime/Lib/site-packages/PySide6/QtWidgets.pyd', 'runtime/Lib/site-packages/PySide6/QtGui.pyd', 'runtime/Lib/site-packages/PySide6/QtCore.pyd',
            'runtime/Lib/site-packages/PySide6/QtSvg.pyd', 'runtime/Lib/site-packages/PySide6/plugins/platforms/qwindows.dll',
            'runtime/Lib/site-packages/PySide6/plugins/imageformats/qsvg.dll', 'runtime/Lib/site-packages/PySide6/msvcp140.dll',
            'runtime/Lib/site-packages/shiboken6/Shiboken.pyd', 'runtime/Lib/site-packages/numpy/__init__.py', 'runtime/Lib/site-packages/serial/tools/list_ports_windows.py',
            'app.py', 'launcher.py', 'version.py', 'core/devices.py', 'ui/chart.py', 'ui/icons/chevron.svg', 'START_GAS_FLOW_CONTROLLER.bat', 'START_HERE.txt']
    missing = [n for n in need if not (stage / n).exists()]
    assert not missing, f'missing in package: {missing}'
    bat = (stage / 'START_GAS_FLOW_CONTROLLER.bat').read_bytes()
    assert b'\n' not in bat.replace(b'\r\n', b''), 'batch file must use CRLF line endings'
    print('All required files present.')


if __name__ == '__main__':
    main()
