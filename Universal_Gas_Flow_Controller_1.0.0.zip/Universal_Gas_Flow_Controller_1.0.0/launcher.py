"""Cross-platform bootstrap. Invoke with Python 3.10+; no dependencies required."""
from pathlib import Path
import os
import stat
import subprocess
import sys
try:
    import venv
except ImportError:  # the embeddable Python in the offline Windows package has no venv; it never needs one
    venv = None

ROOT = Path(__file__).resolve().parent
PROBE = '''
import importlib.metadata as m
import numpy, serial
from PySide6 import QtCore, QtWidgets
for package, minimum, maximum in [('PySide6',(6,7),(7,)),('pyserial',(3,5),(4,)),('numpy',(2,0),(3,))]:
    version=tuple(int(p) for p in m.version(package).split('.')[:2])
    assert minimum <= version < maximum, package
'''


def environment_python(root=ROOT):
    return root / '.venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def unhide_tree(path):
    """Clear the macOS 'hidden' file flag below path and return how many entries changed.

    iCloud Desktop & Documents sync marks files inside dot-folders such as .venv as hidden. Qt skips hidden
    files when it scans for plugins and then fails with "Could not find the Qt platform plugin".
    """
    flag = getattr(stat, 'UF_HIDDEN', 0)
    if not flag or not hasattr(os, 'chflags') or not os.path.isdir(path):
        return 0
    changed = 0
    for folder, dirs, files in os.walk(path):
        for name in dirs + files:
            entry = os.path.join(folder, name)
            try:
                flags = os.lstat(entry).st_flags
                if flags & flag:
                    os.chflags(entry, flags & ~flag, follow_symlinks=False)
                    changed += 1
            except (OSError, NotImplementedError):
                pass
    return changed


def run(root=ROOT):
    if sys.version_info < (3, 10):
        raise RuntimeError('Python 3.10 or newer is required.')
    python = environment_python(root)
    if not python.exists():
        print('Creating the application environment...', flush=True)
        venv.EnvBuilder(with_pip=True).create(root / '.venv')
    if unhide_tree(root / '.venv'):
        print('Repaired hidden-file flags in the environment (set by iCloud Desktop sync).', flush=True)
    probe = subprocess.run([str(python), '-c', PROBE], cwd=root, capture_output=True, text=True)
    if probe.returncode:
        print('Installing or repairing required packages...', flush=True)
        subprocess.run([str(python), '-m', 'ensurepip', '--upgrade'], cwd=root, check=True)
        subprocess.run([str(python), '-m', 'pip', 'install', '-r', str(root / 'requirements.txt')], cwd=root, check=True)
        subprocess.run([str(python), '-c', PROBE], cwd=root, check=True)
    return subprocess.run([str(python), str(root / 'app.py')], cwd=root).returncode


if __name__ == '__main__':
    try:
        raise SystemExit(run())
    except (OSError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f'\nStartup failed: {error}\nCheck Python, your internet connection and requirements.txt.\n'
              'If the environment was copied from another computer, rename .venv and launch again.', file=sys.stderr)
        raise SystemExit(1)
