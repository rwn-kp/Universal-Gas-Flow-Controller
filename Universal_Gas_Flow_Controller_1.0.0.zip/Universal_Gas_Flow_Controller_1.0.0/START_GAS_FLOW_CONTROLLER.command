#!/bin/bash
cd "$(dirname "$0")" || exit 1
if ! python3 launcher.py; then
  echo 'Startup failed. Review the details above.'
  read -r -p 'Press Enter to close...'
  exit 1
fi
