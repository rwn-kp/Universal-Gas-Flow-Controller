from __future__ import annotations
import numpy as np
import math
from .gases import normalize_composition

def solve_source_flows(source_compositions: list[dict[str, float]], target: dict[str, float], total_flow: float,
                       tolerance: float = 1e-6, constrained_gases: list[str] | None = None) -> list[float]:
    """Return per-source flows producing ``target`` at ``total_flow``.

    By default every gas in the target and sources is matched exactly. With ``constrained_gases`` only those
    gases (plus the total flow) are matched; the remainder is whatever the sources carry. This is the usual
    dilution case, e.g. 10 ppm H2 from an H2/N2 premix diluted with synthetic air. Among valid solutions the
    one using the fewest channels (then the lowest channel numbers) is chosen.
    """
    if not math.isfinite(total_flow) or total_flow < 0:
        raise ValueError("Total flow cannot be negative")
    if not source_compositions:
        raise ValueError("Select at least one source channel")
    if constrained_gases is None:
        target = normalize_composition(target)
        gases = sorted(set(target) | {g for c in source_compositions for g in c})
    else:
        target = {g: float(target.get(g, 0.0)) for g in constrained_gases}
        if any(not math.isfinite(p) or not 0 <= p <= 100 for p in target.values()) or sum(target.values()) > 100 + 1e-9:
            raise ValueError("Target concentrations must be between 0 and 100%")
        gases = list(constrained_gases)
    A = np.array([[normalize_composition(c).get(g, 0.0)/100.0 for c in source_compositions] for g in gases] +
                 [[1.0] * len(source_compositions)], dtype=float)
    b = np.array([target.get(g, 0.0)/100.0 * total_flow for g in gases] + [total_flow], dtype=float)
    limit = max(tolerance, abs(total_flow)*1e-6)
    # Enumerate active subsets to obtain a non-negative exact solution without scipy.
    n = len(source_compositions)
    best = None
    for mask in range(1, 1 << n):
        idx = [i for i in range(n) if mask & (1 << i)]
        x_sub, *_ = np.linalg.lstsq(A[:, idx], b, rcond=None)
        if np.any(x_sub < -tolerance):
            continue
        x = np.zeros(n)
        x[idx] = np.maximum(0.0, x_sub)
        err = float(np.max(np.abs(A @ x - b))) if b.size else 0.0
        key = (err,) if constrained_gases is None else (err > limit, len(idx), err)
        if best is None or key < best[0]:
            best = (key, x, err)
    if best is None or best[2] > limit:
        raise ValueError("Requested outlet composition cannot be produced exactly from the selected sources")
    return [float(v) for v in best[1]]
