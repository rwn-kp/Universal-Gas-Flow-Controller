from __future__ import annotations
from dataclasses import dataclass, field
import math, time
from .devices import PROFILES, SimulatorDevice, PhysicalDevice, Reading
from .gases import BUILTIN_GASES, correction_factor, normalize_composition

@dataclass
class Channel:
    name:str='Channel'; port:str='Simulator'; profile_key:str='MFC-E'; address:int=1; baud:int=9600
    source:dict[str,float]=field(default_factory=lambda:{'N2':100.0})
    connected:bool=False; working:bool=False; configured_setpoint:float|None=None; reading:Reading=field(default_factory=Reading)
    device:object|None=None; last_error:str=''; stop_confirmed:bool=True
    gas_library:dict|None=field(default=None, repr=False, compare=False)
    setpoint_since:float=0.0; tracking_warning:str=''; _off_track_polls:int=0; _over_polls:int=0; _noflow_polls:int=0
    _step:tuple|None=field(default=None, repr=False, compare=False)
    def profile(self): return PROFILES[self.profile_key]
    @property
    def calibration_coefficient(self):
        """Conversion coefficient of the gas the device was calibrated with (register 0x0003; N2 by default)."""
        lib=BUILTIN_GASES if self.gas_library is None else self.gas_library
        gas=self.reading.calibration_gas
        return float(lib[gas][1]) if gas in lib else 1.0
    @property
    def cmix(self):
        # Coefficients are N2-referenced, so a device calibrated for another gas is corrected relative to it.
        return correction_factor(self.source, self.gas_library)/self.calibration_coefficient
    def flow_uncertainty(self, corrected):
        """Manufacturer accuracy for a corrected setpoint, in corrected flow units (0 when the channel is off)."""
        raw=float(corrected or 0)/self.cmix
        return 0.0 if raw<=0 else self.profile().accuracy(raw,self.reading.full_scale)*self.cmix
    def quantized(self, corrected):
        """Corrected flow the controller will actually deliver after setpoint rounding."""
        return self.profile().quantize(float(corrected)/self.cmix)*self.cmix
    def step_arrival(self, give_up_s=20.0):
        """Seconds from the last setpoint command until the measured flow crossed the middle of the change
        (returned once), else None. Starting from zero the lab controllers showed 1.3 s (MFC-E) and 2.7-2.9 s (S300D)."""
        if not self._step or not self.connected: return None
        t0,f0,f1=self._step; f=self.reading.raw_flow; fs=self.reading.full_scale or 1
        if abs(f1-f0)<max(2*self.reading.resolution,self.profile().min_fraction*fs): self._step=None; return None
        mid=(f0+f1)/2
        if (f1>f0 and f>=mid) or (f1<f0 and f<=mid): self._step=None; return time.monotonic()-t0
        if time.monotonic()-t0>give_up_s: self._step=None
        return None
    def check_overflow(self, settle_s=5.0, polls=2):
        """Return a message when a running channel delivers far MORE than its setpoint after settling.

        Over-delivery is treated as a fault (the caller stops all flows): it happens when the selected model has
        the wrong setpoint scale (S300 x0.001 vs MFC-E x0.01 gives 10x) or when a valve sticks open. Both models
        answer the same registers, so the model cannot be detected automatically.
        """
        if not (self.connected and self.working and self.configured_setpoint is not None) or time.monotonic()-self.setpoint_since<settle_s:
            self._over_polls=0; return ''
        fs=self.reading.full_scale; raw_sp=self.configured_setpoint/self.cmix
        limit=1.5*raw_sp+max(3*self.profile().accuracy(raw_sp,fs),self.profile().min_fraction*fs)
        self._over_polls=self._over_polls+1 if self.reading.raw_flow>limit else 0
        if self._over_polls>=polls:
            return (f'{self.name} delivers {self.reading.raw_flow:.4g} {self.reading.flow_unit} for a setpoint of {raw_sp:.4g} (N2-equivalent). '
                    'Check that the selected model matches the device (S300 and MFC-E scale setpoints differently) and that the valve is not stuck open.')
        return ''
    def check_no_flow(self, settle_s=6.0, polls=4):
        """Return a message when a running channel delivers (almost) nothing after settling.

        Without gas the controller drives its valve fully open; opening the cylinder then causes a surge, and a
        missing carrier during a mixture sends undiluted premix to the sensor. The caller stops all flows.
        Starting from zero the lab S300D showed ~2.7 s dead time, hence the 6 s settling time.
        """
        if not (self.connected and self.working and self.configured_setpoint) or time.monotonic()-self.setpoint_since<settle_s:
            self._noflow_polls=0; return ''
        fs=self.reading.full_scale; raw_sp=self.configured_setpoint/self.cmix
        if raw_sp<self.profile().min_fraction*fs: return ''          # too small to judge with this device
        self._noflow_polls=self._noflow_polls+1 if self.reading.raw_flow<0.2*raw_sp else 0
        if self._noflow_polls>=polls:
            v=f' The controller valve is at {self.reading.valve:.0f}%.' if self.reading.valve else ''
            return (f'No gas through {self.name}: {self.reading.raw_flow:.4g} {self.reading.flow_unit} measured for {raw_sp:.4g} commanded.{v} '
                    'Open the cylinder and set the regulator (0.5-6 bar above the outlet) BEFORE restarting flows, otherwise the open valve causes a surge.')
        return ''
    def check_tracking(self, settle_s=5.0, polls=4):
        """Flag a running channel whose measured flow stays away from its setpoint after the settling time."""
        if not (self.connected and self.working and self.configured_setpoint is not None) or time.monotonic()-self.setpoint_since<settle_s:
            self._off_track_polls=0; self.tracking_warning=''; return ''
        fs=self.reading.full_scale; raw_sp=self.configured_setpoint/self.cmix
        tolerance=max(3*self.profile().accuracy(raw_sp,fs),self.profile().min_fraction*fs)
        self._off_track_polls=self._off_track_polls+1 if abs(self.reading.raw_flow-raw_sp)>tolerance else 0
        new=''
        if self._off_track_polls>=polls:
            new=(f'{self.name}: measured {self.reading.raw_flow:.4g} vs setpoint {raw_sp:.4g} {self.reading.flow_unit} (raw). '
                 'Check the cylinder valve and inlet pressure (0.5-6 bar differential), blockages, and that the model selection matches the device.')
        changed=new!=self.tracking_warning; self.tracking_warning=new
        return new if changed and new else ''
    @property
    def corrected_flow(self): return self.reading.raw_flow*self.cmix
    def connect(self):
        self.device = SimulatorDevice() if self.port=='Simulator' else PhysicalDevice(self.port,self.baud,self.address,self.profile())
        try:
            self.device.connect(); self.reading=self.device.read()
        except Exception as error:
            self.last_error=str(error); self.disconnect(); raise
        self.connected=True; self.last_error=''; return self.reading
    def disconnect(self):
        try:
            if self.device: self.device.disconnect()
        finally:
            self.connected=False; self.working=False; self.device=None
    def poll(self):
        if not self.connected or not self.device: raise RuntimeError('Channel is not connected')
        self.reading=self.device.read(); self.last_error=''; return self.reading
    def configure(self, corrected):
        v=float(corrected)
        if not math.isfinite(v) or v<0: raise ValueError('Setpoint must be finite and nonnegative')
        self.configured_setpoint=v
    def validate_setpoint(self, corrected):
        value=float(corrected)
        if not math.isfinite(value) or value<0: raise ValueError('Setpoint must be finite and nonnegative')
        raw=value/self.cmix
        if self.reading.full_scale and raw>self.reading.full_scale+1e-9: raise ValueError(f'{self.name}: raw setpoint exceeds controller full scale')
        return raw
    def start(self):
        if self.configured_setpoint is None: raise ValueError('Configure a setpoint first')
        if not self.connected: raise RuntimeError('Channel is not connected')
        raw=self.validate_setpoint(self.configured_setpoint)
        before=self.reading.raw_flow
        self.device.set_flow(raw); self.working=True; self.stop_confirmed=False; self.setpoint_since=time.monotonic(); self._step=(self.setpoint_since,before,raw); self._off_track_polls=0; self._over_polls=0; self._noflow_polls=0; self.tracking_warning=''
    def stop(self):
        if not self.emergency_stop(): raise RuntimeError(self.last_error or 'Stop command could not be confirmed')
    def emergency_stop(self):
        ok=False
        if self.device:
            try: self.device.emergency_zero(); ok=True
            except Exception as e: self.last_error=str(e)
        self.working=False; self.stop_confirmed=ok; return ok
    def to_dict(self):
        return {'name':self.name,'port':self.port,'profile_key':self.profile_key,'address':self.address,'baud':self.baud,
                'source':normalize_composition(self.source),'configured_setpoint':self.configured_setpoint}
    @classmethod
    def from_dict(cls,d):
        return cls(name=d.get('name','Channel'),port=d.get('port','Simulator'),profile_key=d.get('profile_key','MFC-E'),
                   address=int(d.get('address',1)),baud=int(d.get('baud',PROFILES.get(d.get('profile_key','MFC-E'),PROFILES['MFC-E']).default_baud)),
                   source=normalize_composition(d.get('source',{'N2':100.0})),configured_setpoint=d.get('configured_setpoint'))
