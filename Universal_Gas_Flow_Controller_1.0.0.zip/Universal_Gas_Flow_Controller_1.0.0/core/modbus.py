from __future__ import annotations
import struct, threading, time

def crc16(data: bytes) -> int:
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = (crc >> 1) ^ 0xA001 if crc & 1 else crc >> 1
    return crc & 0xFFFF

def append_crc(payload: bytes) -> bytes:
    c = crc16(payload)
    return payload + bytes((c & 0xFF, (c >> 8) & 0xFF))

class ModbusError(RuntimeError): pass

class SerialBus:
    def __init__(self, port: str, baud: int, timeout: float = 0.20):
        self.port, self.baud, self.timeout = port, int(baud), float(timeout)
        self._serial = None
        self.lock = threading.RLock()
        self.refcount = 0
    def open(self):
        if self._serial and self._serial.is_open: return
        try:
            import serial
        except Exception as e:
            raise ModbusError("pyserial is not installed") from e
        self._serial = serial.Serial(self.port, self.baud, bytesize=8, parity='N', stopbits=1,
                                     timeout=self.timeout, write_timeout=self.timeout)
    def close(self):
        if self._serial:
            try: self._serial.close()
            except Exception: pass
        self._serial = None
    def transact(self, request: bytes, expected_min: int = 5) -> bytes:
        with self.lock:
            self.open()
            s = self._serial
            try:
                s.reset_input_buffer(); s.write(request); s.flush()
                deadline = time.monotonic() + self.timeout
                data = bytearray()
                while time.monotonic() < deadline:
                    chunk = s.read(max(1, s.in_waiting or 1))
                    if chunk: data.extend(chunk)
                    if len(data) >= 5 and data[1] & 0x80: break
                    if len(data) >= expected_min:
                        if len(data) >= 5 and data[1] in (0x06,0x10) and len(data)>=8: break
                        if len(data)>=3 and data[1] == 0x03 and len(data) >= 5 + data[2]: break
                    if not chunk: time.sleep(0.002)
            except Exception as e:
                raise ModbusError(f"Serial I/O failed on {self.port}: {e}") from e
            if len(data) < 5 or (not data[1] & 0x80 and len(data) < expected_min):
                raise ModbusError(f"No valid Modbus response from {self.port}")
            body, got = bytes(data[:-2]), int.from_bytes(data[-2:], 'little')
            if crc16(body) != got: raise ModbusError("Modbus CRC mismatch")
            if data[0] != request[0] or (data[1] & 0x7f) != request[1]: raise ModbusError('Response address or function does not match request')
            if data[1] & 0x80: raise ModbusError(f"Modbus exception code {data[2] if len(data)>2 else '?'}")
            return bytes(data)

class BusPool:
    def __init__(self): self._buses = {}; self._lock = threading.Lock()
    def acquire(self, port, baud):
        key=(port,int(baud))
        with self._lock:
            if any(p == port and b != int(baud) for p, b in self._buses):
                raise ModbusError(f'{port} is already open at a different baud rate')
            bus=self._buses.get(key) or SerialBus(port,baud)
            bus.open()
            self._buses[key]=bus; bus.refcount += 1
            return bus
    def release(self,bus):
        with self._lock:
            bus.refcount=max(0,bus.refcount-1)
            if bus.refcount==0:
                bus.close(); self._buses.pop((bus.port,bus.baud),None)
BUS_POOL=BusPool()

class ModbusClient:
    def __init__(self,bus:SerialBus,address:int): self.bus=bus; self.address=int(address)
    def read_regs(self,start:int,count:int):
        req=append_crc(struct.pack('>BBHH',self.address,0x03,start,count))
        r=self.bus.transact(req,5+2*count)
        if r[0]!=self.address or r[1]!=0x03 or r[2]!=2*count: raise ModbusError("Unexpected read response")
        return list(struct.unpack('>'+'H'*count,r[3:3+2*count]))
    def write_single(self,reg:int,value:int):
        req=append_crc(struct.pack('>BBHH',self.address,0x06,reg,value & 0xFFFF))
        r=self.bus.transact(req,8)
        if r[:6]!=req[:6]: raise ModbusError("Unexpected write response")
    def write_multiple(self,start:int,values:list[int]):
        payload=struct.pack('>BBHHB',self.address,0x10,start,len(values),2*len(values))+struct.pack('>'+'H'*len(values),*values)
        req=append_crc(payload); r=self.bus.transact(req,8)
        if r[:6]!=req[:6]: raise ModbusError("Unexpected multi-write response")
