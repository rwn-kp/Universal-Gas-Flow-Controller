from __future__ import annotations
from dataclasses import dataclass, field
import time
from .modbus import BUS_POOL, ModbusClient, ModbusError, SerialBus

FLOW_UNITS={10:'SCCM',100:'SLM'}
# Register 0x0003 "gas type" codes (Xinnovis MFC and S500/S300 Modbus protocol documents).
GAS_CODES={1:'He',2:'CO',4:'Ar',7:'H2',8:'Air',13:'N2',15:'O2',25:'CO2',28:'CH4'}
# Register 0x0014 decimal-place codes (S500/S300 protocol): code -> decimals.
DECIMAL_CODES={0:2,1:3,2:0,3:1}

@dataclass(frozen=True)
class Profile:
    """Model data from the Xinnovis user manuals (v2.0.0) and Modbus protocol documents.

    accuracy(): absolute raw-flow error. With sp_from=None the larger of acc_fs*FS and acc_sp*SP applies
    (MFC-E); otherwise acc_fs*FS up to sp_from*FS and acc_sp*SP above it (S300).
    min_fraction: lower end of the controllable range (range ratio 100:1 -> 0.01, 50:1 -> 0.02).
    """
    key:str; name:str; default_baud:int; set_scale:int; read_mode:str; address_write:bool=False
    min_fraction:float=0.02; acc_fs:float=0.01; acc_sp:float=0.01; sp_from:float|None=None
    bauds:tuple=(9600,19200,38400,115200); address_note:str=''
    def accuracy(self, raw, full_scale):
        raw=max(0.0,float(raw)); fs=float(full_scale or 0)
        if self.sp_from is None: return max(self.acc_fs*fs, self.acc_sp*raw)
        return self.acc_fs*fs if raw<=self.sp_from*fs else self.acc_sp*raw
    def quantize(self, raw):
        """Raw setpoint actually stored by the controller (setpoint resolution 1/set_scale)."""
        return max(0,int(round(float(raw)*self.set_scale)))/self.set_scale
_S300_NOTE='S300 addresses are set with the X100/X10/X1 rotary switches on the device.'
PROFILES={
 'MFC-E':Profile('MFC-E','MFC-E',9600,100,'fixed2',True,min_fraction=0.01,acc_fs=0.008,acc_sp=0.010,sp_from=None,
                 bauds=(9600,19200,38400,57600,115200,4800,14400,56000)),
 'S300-new':Profile('S300-new','S300/S300D RS485 (new x1000)',19200,1000,'decimal-reg',False,min_fraction=0.02,acc_fs=0.003,acc_sp=0.010,sp_from=0.30,
                    bauds=(19200,9600,115200,38400),address_note=_S300_NOTE),
 'S300-legacy':Profile('S300-legacy','S300/S300D RS485 (legacy x100)',19200,100,'fixed2',False,min_fraction=0.02,acc_fs=0.003,acc_sp=0.010,sp_from=0.30,
                       bauds=(19200,9600,115200,38400),address_note=_S300_NOTE),
}
SCAN_BAUDS=(9600,19200,115200,38400,57600,4800,14400,56000)

@dataclass
class Reading:
    raw_flow:float=0.0; temperature:float=25.0; accumulated:float=0.0; accumulated_unit:str='L'; elapsed_s:int=0
    full_scale:float=100.0; flow_unit:str='SCCM'; gas_code:int=13; calibration_gas:str='N2'
    resolution:float=0.01   # smallest step of the flow reading (S300: from register 0x0014)
    valve:float|None=None   # valve drive in % (register 0x0024) when the device reports it
    @property
    def calibration_text(self):
        known=GAS_CODES.get(self.gas_code)
        return known if known else f'code {self.gas_code} (unknown, assuming N2)'

def decode_basic(regs):
    gas_code,full_scale,unit_code=regs
    return {'gas_code':gas_code,'full_scale':full_scale,'unit_code':unit_code,'calibration_gas':GAS_CODES.get(gas_code,'N2'),'flow_unit':FLOW_UNITS.get(unit_code,str(unit_code))}

class SimulatorDevice:
    def __init__(self):
        self.setpoint=0.0; self.flow=0.0; self.temp=25.0; self.accum=0.0; self.connected=False; self.last=time.monotonic(); self.failed=False
    def connect(self):
        if self.failed: raise ModbusError('Simulator is disconnected')
        self.connected=True; self.last=time.monotonic()
    def disconnect(self): self.connected=False
    def _tick(self):
        if self.failed or not self.connected: raise ModbusError('Simulator is disconnected')
        now=time.monotonic(); dt=now-self.last; self.last=now
        self.flow += (self.setpoint-self.flow)*min(1.0,dt*4.0)
        self.accum += max(0,self.flow)*dt/60.0/1000.0
    def read(self): self._tick(); return Reading(self.flow,self.temp,self.accum,'L',int(self.accum*0+time.monotonic()),100.0,'SCCM')
    def set_flow(self,value): self._tick(); self.setpoint=max(0,float(value))
    def emergency_zero(self): self.setpoint=0.0; self.flow=0.0
    def zero_calibration(self): self.flow=0.0
    def clear_accumulated(self): self.accum=0.0
    def valve_opening(self,pct): self.setpoint=max(0,min(100,float(pct)))
    def factory_restore(self): self.setpoint=0.0; self.flow=0.0; self.accum=0.0

class PhysicalDevice:
    def __init__(self,port:str,baud:int,address:int,profile:Profile):
        self.port=port; self.baud=int(baud); self.address=int(address); self.profile=profile; self.bus=None; self.client=None
    def connect(self):
        self.bus=BUS_POOL.acquire(self.port,self.baud); self.client=ModbusClient(self.bus,self.address)
        try: self.read_basic(); self.read()
        except Exception:
            self.disconnect(); raise
    def disconnect(self):
        if self.bus: BUS_POOL.release(self.bus)
        self.bus=None; self.client=None
    def read_basic(self):
        return decode_basic(self.client.read_regs(0x0003,3))
    def read(self):
        b=self.read_basic()
        if self.profile.read_mode=='decimal-reg':
            regs=self.client.read_regs(0x0014,4); dec_code,temp,hi,lo=regs
            if dec_code not in DECIMAL_CODES: raise ModbusError(f'Unexpected flow decimal code {dec_code}; check that the model selection matches the device')
            decimals=DECIMAL_CODES[dec_code]
        else:
            regs=self.client.read_regs(0x0015,3); temp,hi,lo=regs; decimals=2
        if temp>=0x8000: temp-=0x10000
        flow=((hi<<16)|lo)/(10**decimals)
        valve=None
        try:
            # 0x0018-0x0020 totalizer; extended to 0x0024 in the same request to get the live valve drive.
            if getattr(self,'_long_read',True):
                try: ar=self.client.read_regs(0x0018,13); valve=ar[12]/100.0
                except ModbusError: self._long_read=False; ar=self.client.read_regs(0x0018,9)
            else: ar=self.client.read_regs(0x0018,9)
            acc=(ar[0]<<48)|(ar[1]<<32)|(ar[2]<<16)|ar[3]; accumulated=acc/1000.0; au='m3' if ar[4]==1 else 'L'
            elapsed=ar[5]*86400+ar[6]*3600+ar[7]*60+ar[8]
        except Exception:
            accumulated=0.0; au='L'; elapsed=0
        return Reading(flow,temp/10.0,accumulated,au,elapsed,float(b['full_scale']),b['flow_unit'],b['gas_code'],b['calibration_gas'],10.0**-decimals,valve)
    def set_flow(self,value):
        raw=max(0,int(round(float(value)*self.profile.set_scale)))
        if raw>0xFFFFFFFF: raise ValueError('Setpoint is outside the register range')
        self.client.write_multiple(0x0021,[0,(raw>>16)&0xFFFF,raw&0xFFFF])
    def emergency_zero(self): self.client.write_multiple(0x0021,[0,0,0])
    def zero_calibration(self): self.client.write_single(0x0025,1)
    def factory_restore(self): self.client.write_single(0x0025,2)
    def clear_accumulated(self): self.client.write_multiple(0x0018,[0,0,0,0])
    def valve_opening(self,pct):
        v=max(0,min(100,float(pct))); self.client.write_multiple(0x0021,[3,0,0,int(round(v*100))])


def scan_port(port, bauds=SCAN_BAUDS, addresses=range(1,17), progress=None, bus_factory=SerialBus):
    """Find controllers on a serial port by trying each baud rate.

    For every baud rate, addresses 1, 2 and the isolated-device address 0xFE are probed first; when anything
    answers, all ``addresses`` are swept at that baud rate. ``progress(text)`` may return False to cancel.
    Returns [{'baud', 'address', 'gas', 'full_scale', 'flow_unit'}].
    """
    found=[]
    def tell(text): return progress is None or progress(text) is not False
    for baud in bauds:
        if not tell(f'Trying {baud} baud…'): break
        bus=bus_factory(port,baud)
        try:
            try: bus.open()
            except Exception as e: raise ModbusError(f'Cannot open {port}: {e}') from e
            alive=False
            for addr in (1,2,0xFE):
                try:
                    if addr==0xFE: ModbusClient(bus,addr).read_regs(0x0000,1)
                    else: ModbusClient(bus,addr).read_regs(0x0003,3)
                    alive=True; break
                except ModbusError: continue
            if not alive: continue
            for addr in addresses:
                if not tell(f'{baud} baud: checking address {addr}…'): return found
                try: b=decode_basic(ModbusClient(bus,addr).read_regs(0x0003,3))
                except ModbusError: continue
                found.append({'baud':baud,'address':addr,'gas':GAS_CODES.get(b['gas_code'],f"code {b['gas_code']}"),'full_scale':b['full_scale'],'flow_unit':b['flow_unit']})
            if not found:
                try:
                    addr=ModbusClient(bus,0xFE).read_regs(0x0000,1)[0]
                    found.append({'baud':baud,'address':addr,'gas':'?','full_scale':'?','flow_unit':''})
                except ModbusError: pass
            if found: break
        finally:
            bus.close()
    return found
