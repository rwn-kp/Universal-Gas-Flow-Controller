from __future__ import annotations
from dataclasses import dataclass
import math

# Nitrogen-referenced gas conversion coefficients from the appendix of the Xinnovis
# MFC-E and S300 user manuals (v2.0.0).
BUILTIN_GASES = {
    "Air": ("Air", 1.001),
    "NH3": ("Ammonia (NH3)", 0.91),
    "Ar": ("Argon (Ar)", 1.6),
    "AsH3": ("AsH3", 0.755),
    "B2H6": ("B2H6", 0.507),
    "BCl3": ("BCl3", 0.481),
    "BF3": ("BF3", 0.575),
    "C2H2": ("C2H2", 0.664),
    "C2H4": ("C2H4", 0.679),
    "C2H6": ("C2H6", 0.548),
    "C2H6O": ("C2H6O", 0.439),
    "C2N2": ("C2N2", 0.508),
    "C3H4": ("C3H4", 0.478),
    "C3H6": ("C3H6", 0.453),
    "C3H8": ("C3H8", 0.395),
    "C4H10": ("C4H10", 0.289),
    "C4H6": ("C4H6", 0.362),
    "C4H8": ("C4H8", 0.331),
    "C5H12": ("C5H12", 0.244),
    "CO2": ("Carbon dioxide (CO2)", 0.75),
    "CO": ("Carbon monoxide (CO)", 1.015),
    "CCl4": ("CCl4", 0.342),
    "CF4": ("CF4", 0.469),
    "Cl2": ("Cl2", 0.841),
    "D2": ("D2", 2.449),
    "F2": ("F2", 0.949),
    "GeH4": ("GeH4", 0.638),
    "HBr": ("HBr", 0.987),
    "HCl": ("HCl", 0.998),
    "He": ("Helium (He)", 4.0),
    "HF": ("HF", 1.019),
    "HI": ("HI", 0.972),
    "H2": ("Hydrogen (H2)", 3.9),
    "H2S": ("Hydrogen sulfide (H2S)", 0.89),
    "Kr": ("Krypton (Kr)", 1.388),
    "CH4": ("Methane (CH4)", 0.9),
    "Ne": ("Neon (Ne)", 1.562),
    "N2": ("Nitrogen (N2)", 1.0),
    "N2O": ("Nitrous oxide (N2O)", 0.751),
    "NO": ("NO", 0.994),
    "NO2": ("NO2", 0.789),
    "O2": ("Oxygen (O2)", 1.025),
    "PCl3": ("PCl3", 0.399),
    "PF5": ("PF5", 0.34),
    "PH3": ("PH3", 0.784),
    "SF6": ("SF6", 0.297),
    "SiCl4": ("SiCl4", 0.318),
    "SiF4": ("SiF4", 0.39),
    "SiH2Cl2": ("SiH2Cl2", 0.467),
    "SiH4": ("SiH4", 0.685),
    "SiHCl3": ("SiHCl3", 0.381),
    "SO2": ("SO2", 1.218),
    "WF6": ("WF6", 0.24),
    "Xe": ("Xenon (Xe)", 1.369),
}

@dataclass
class GasComponent:
    gas: str
    percent: float

def correction_factor(composition: dict[str, float], gas_library: dict[str, tuple[str, float]] | None = None) -> float:
    lib = BUILTIN_GASES if gas_library is None else gas_library
    composition = validate_composition(composition)
    denom = 0.0
    for gas, pct in composition.items():
        if pct == 0:
            continue
        if gas not in lib:
            raise ValueError(f"Unknown gas {gas}: add its correction coefficient first")
        coeff = float(lib[gas][1])
        if not math.isfinite(coeff) or coeff <= 0:
            raise ValueError(f"Gas correction coefficient for {gas} must be finite and positive")
        denom += pct / 100 / coeff
    return 1.0 / denom


def validate_composition(composition: dict[str, float]) -> dict[str, float]:
    clean = {str(g): float(p) for g, p in composition.items()}
    if not clean or any(not g.strip() or not math.isfinite(p) or p < 0 or p > 100 for g, p in clean.items()):
        raise ValueError("Gas percentages must be finite values between 0 and 100%")
    total = sum(clean.values())
    if abs(total - 100) > 1e-6:
        raise ValueError(f"Total: {total:.6g}%. Enter 100% or select a balance gas.")
    return clean

def normalize_composition(composition: dict[str, float]) -> dict[str, float]:
    if any(not math.isfinite(float(v)) or float(v) < 0 for v in composition.values()):
        raise ValueError("Gas percentages must be finite and nonnegative")
    clean = {str(k): max(0.0, float(v)) for k, v in composition.items() if float(v) > 0}
    total = sum(clean.values())
    if total <= 0:
        return {"N2": 100.0}
    return {k: v * 100.0 / total for k, v in clean.items()}

def composition_text(composition: dict[str, float], sig: int = 5) -> str:
    comp = normalize_composition(composition)
    def fmt(x: float) -> str:
        return f"{x:.{max(sig-1,0)}g}"
    return " + ".join(f"{fmt(p)}% {g}" for g, p in comp.items())

PPM_PER_PERCENT = 1e4
# Lower flammability limit of hydrogen in air (vol%).
H2_LFL_PERCENT = 4.0
OXIDIZERS = ("O2", "Air")

def percent_to_ppm(percent: float) -> float:
    return float(percent) * PPM_PER_PERCENT

def ppm_to_percent(ppm: float) -> float:
    return float(ppm) / PPM_PER_PERCENT

def concentration_text(percent: float | None, sig: int = 4) -> str:
    """Show low concentrations in ppm and add % once the value is large enough to read naturally."""
    if percent is None or not math.isfinite(float(percent)):
        return "—"
    ppm = percent_to_ppm(percent)
    text = f"{_plain(ppm, sig)} ppm"
    return text if percent < 0.1 else f"{text} ({_plain(float(percent), sig)}%)"

def _plain(x: float, sig: int) -> str:
    """Round to significant digits without scientific notation, e.g. 10000 -> '10,000', 0.40 -> '0.4'."""
    if x == 0:
        return "0"
    decimals = max(0, sig - 1 - int(math.floor(math.log10(abs(x)))))
    text = f"{round(x, decimals):,.{decimals}f}"
    return text.rstrip("0").rstrip(".") if decimals else text

def flammability_error(composition: dict[str, float], fuel: str = "H2", limit: float = H2_LFL_PERCENT) -> str:
    """Return a message when an oxidizer-containing mixture reaches the fuel's lower flammability limit."""
    if not composition:
        return ""
    total = sum(max(0.0, float(v)) for v in composition.values())
    if total <= 0:
        return ""
    fuel_pct = max(0.0, float(composition.get(fuel, 0.0))) * 100.0 / total
    has_oxidizer = any(float(composition.get(g, 0.0)) > 0 for g in OXIDIZERS)
    if has_oxidizer and fuel_pct >= limit - 1e-9:
        return (f"{fuel} at {fuel_pct:.4g}% with oxygen/air present is at or above the lower flammability limit "
                f"({limit:g}%). Use an inert carrier or a lower concentration.")
    return ""

def outlet_concentration_uncertainty(sources: list[tuple[dict[str, float], float, float]], gas: str = "H2"):
    """Outlet percentage of ``gas`` and its uncertainty from per-source flow uncertainties.

    sources: (composition, flow, flow uncertainty). With C = sum(q_i c_i)/Q, dC/dq_i = (c_i - C)/Q; the
    contributions are combined as a root sum of squares. Returns (None, None) without flow.
    """
    flowing = [(normalize_composition(c).get(gas, 0.0), float(f), float(u)) for c, f, u in sources if f > 0]
    total = sum(f for _, f, _ in flowing)
    if total <= 0:
        return None, None
    conc = sum(c * f for c, f, _ in flowing) / total
    return conc, math.sqrt(sum(((c - conc) / total * u) ** 2 for c, _, u in flowing))

def outlet_composition(sources: list[tuple[dict[str, float], float]]) -> dict[str, float]:
    total_flow = sum(max(0.0, f) for _, f in sources)
    if total_flow <= 0:
        return {}
    gases: dict[str, float] = {}
    for comp, flow in sources:
        n = normalize_composition(comp)
        for gas, pct in n.items():
            gases[gas] = gases.get(gas, 0.0) + flow * pct / 100.0
    return {gas: amount * 100.0 / total_flow for gas, amount in gases.items()}
