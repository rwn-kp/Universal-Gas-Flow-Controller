"""Shared source/target composition editor; edits never normalize user input."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QDoubleSpinBox, QCheckBox, QDialog, QDialogButtonBox, QInputDialog,
    QScrollArea, QMessageBox)
from core.gases import validate_composition


class TargetCompositionEditor(QWidget):
    def __init__(self, gas_library, changed_cb=None, parent=None):
        super().__init__(parent)
        self.lib = gas_library
        self.changed_cb = changed_cb
        self.rows = []
        self._loading = True
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        header = QHBoxLayout()
        for title, stretch in [('Gas', 2), ('Concentration (%)', 1), ('Balance', 0)]:
            header.addWidget(QLabel(title), stretch)
        layout.addLayout(header)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMinimumHeight(150)
        host = QWidget()
        self.rows_box = QVBoxLayout(host)
        self.rows_box.setAlignment(Qt.AlignTop)
        scroll.setWidget(host)
        layout.addWidget(scroll)
        self.total_label = QLabel()
        self.total_label.setWordWrap(True)
        layout.addWidget(self.total_label)
        self.add_button = QPushButton('+ Add gas')
        self.add_button.clicked.connect(lambda: self.add_row())
        layout.addWidget(self.add_button)
        self.set_composition({'H2': 1, 'N2': 99})
        self._loading = False

    def add_row(self, gas=None, pct=0.0, auto=False):
        used = {r['gas'].currentText() for r in self.rows}
        if gas is None or gas in used:
            gas = next((g for g in ['H2', 'N2', *sorted(self.lib)] if g in self.lib and g not in used), None)
        if gas is None:
            return
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(0, 3, 0, 3)
        combo = QComboBox()
        combo.setMinimumWidth(130)
        combo.addItems(sorted(set(self.lib) | {gas}))
        combo.setCurrentText(gas)
        combo.setAccessibleName('Gas component')
        spin = QDoubleSpinBox()
        spin.setRange(0, 100)
        spin.setDecimals(6)
        spin.setKeyboardTracking(False)
        spin.setValue(pct)
        spin.setAccessibleName('Concentration percent')
        check = QCheckBox('Balance')
        check.setChecked(auto)
        remove = QPushButton('×')
        remove.setFixedWidth(32)
        remove.setStyleSheet('padding:0;')
        remove.setToolTip('Remove gas component')
        for item, stretch in [(combo, 2), (spin, 1), (check, 0), (remove, 0)]:
            layout.addWidget(item, stretch)
        row = dict(widget=widget, gas=combo, pct=spin, auto=check, x=remove, previous=gas)
        self.rows.append(row)
        self.rows_box.addWidget(widget)
        combo.currentTextChanged.connect(lambda: self._changed(row, 'gas'))
        spin.valueChanged.connect(lambda: self._changed(row, 'pct'))
        check.toggled.connect(lambda: self._changed(row, 'auto'))
        remove.clicked.connect(lambda: self.remove_row(row))
        self._changed(row, 'auto' if auto else 'add')

    def remove_row(self, row):
        if len(self.rows) <= 1:
            return
        self.rows.remove(row)
        self.rows_box.removeWidget(row['widget'])
        row['widget'].hide()
        row['widget'].deleteLater()
        self._rebalance()
        self._emit()

    def _changed(self, row, field):
        if field == 'gas':
            used = {r['gas'].currentText() for r in self.rows if r is not row}
            if row['gas'].currentText() in used:
                row['gas'].blockSignals(True)
                row['gas'].setCurrentText(row['previous'])
                row['gas'].blockSignals(False)
            row['previous'] = row['gas'].currentText()
        if field == 'auto' and row['auto'].isChecked():
            for other in self.rows:
                if other is not row:
                    other['auto'].blockSignals(True)
                    other['auto'].setChecked(False)
                    other['auto'].blockSignals(False)
        self._rebalance()
        self._emit()

    def _rebalance(self):
        balance = next((r for r in self.rows if r['auto'].isChecked()), None)
        for row in self.rows:
            row['pct'].setReadOnly(row is balance)
            row['x'].setEnabled(len(self.rows) > 1)
            if row is balance:
                remaining = 100 - sum(r['pct'].value() for r in self.rows if r is not balance)
                row['pct'].blockSignals(True)
                row['pct'].setValue(max(0, remaining))
                row['pct'].blockSignals(False)
            used = {r['gas'].currentText() for r in self.rows if r is not row}
            for i in range(row['gas'].count()):
                row['gas'].model().item(i).setEnabled(row['gas'].itemText(i) not in used)
        try:
            self.composition()
            self.total_label.setText('Total: 100% • Ready')
        except ValueError as error:
            self.total_label.setText(str(error))
        self.add_button.setEnabled(len(self.rows) < len(self.lib))

    def _emit(self):
        if not self._loading and self.changed_cb:
            self.changed_cb()

    def composition(self):
        return validate_composition({r['gas'].currentText(): r['pct'].value() for r in self.rows})

    def refresh_library(self):
        for row in self.rows:
            combo = row['gas']
            current = combo.currentText()
            combo.blockSignals(True)
            combo.clear()
            combo.addItems(sorted(set(self.lib) | {current}))
            combo.setCurrentText(current)
            combo.blockSignals(False)
        self._rebalance()

    def set_composition(self, composition):
        loading = self._loading
        self._loading = True
        for row in self.rows:
            self.rows_box.removeWidget(row['widget'])
            row['widget'].hide()
            row['widget'].deleteLater()
        self.rows = []
        items = list(composition.items()) or [('N2', 100)]
        for gas, percent in items:
            self.add_row(gas, percent)
        # Pure gases remain editable. For mixtures, the last component balances.
        if len(self.rows) > 1:
            self.rows[-1]['auto'].setChecked(True)
        self._rebalance()
        self._loading = loading
        self._emit()


class GasCompositionDialog(QDialog):
    def __init__(self, composition, gas_library, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Source gas composition')
        self.resize(640, 430)
        self.lib = dict(gas_library)
        layout = QVBoxLayout(self)
        hint = QLabel('Enter percentages and select one balance gas, or enter a total of 100%.')
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.editor = TargetCompositionEditor(self.lib, parent=self)
        self.editor.set_composition(composition)
        layout.addWidget(self.editor)
        custom = QPushButton('Add custom gas…')
        custom.clicked.connect(self.add_custom_gas)
        layout.addWidget(custom)
        self.buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self._accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        self.editor.changed_cb = self._validate
        self._validate()

    def _validate(self):
        try:
            self.editor.composition()
            valid = True
        except ValueError:
            valid = False
        self.buttons.button(QDialogButtonBox.Save).setEnabled(valid)

    def add_custom_gas(self):
        name, ok = QInputDialog.getText(self, 'Custom gas', 'Gas key / formula:')
        name = name.strip()
        if not ok or not name:
            return
        if name in self.lib:
            QMessageBox.warning(self, 'Custom gas', 'That gas already exists. Choose a unique name.')
            return
        coefficient, ok = QInputDialog.getDouble(self, 'Custom gas', 'Nitrogen-referenced correction coefficient:', 1, 0.000001, 1e9, 6)
        if ok:
            self.lib[name] = (name, coefficient)
            self.editor.refresh_library()
            self.editor.add_row(name)

    def _accept(self):
        self.composition = self.editor.composition()
        self.accept()
