"""Small shared widgets for a consistent, readable interface."""
from PySide6.QtCore import Qt
from PySide6.QtGui import QPainter
from PySide6.QtWidgets import QLabel, QFrame, QVBoxLayout, QSizePolicy, QStyle, QStyleOption

PILL_COLORS = {
    'off': ('#64748b', '#ffffff'), 'ok': ('#15803d', '#ffffff'), 'flow': ('#1d4ed8', '#ffffff'),
    'warn': ('#b45309', '#ffffff'), 'error': ('#b91c1c', '#ffffff'), 'sim': ('#7c3aed', '#ffffff'),
}


def wrap(text='', rich=False, selectable=False, muted=False):
    """A word-wrapping label. Put it in a box/grid layout (not a QFormLayout field) so its height follows its width."""
    lab = QLabel(text)
    lab.setWordWrap(True)
    lab.setTextFormat(Qt.RichText if rich else Qt.PlainText)
    lab.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Minimum)
    if selectable:
        lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
    if muted:
        lab.setObjectName('muted')
    return lab


class ElidedLabel(QLabel):
    """One line of text: when it does not fit it ends with … and the full text is the tooltip.
    text() still returns the full text."""
    def __init__(self, text='', parent=None, tip_suffix=''):
        super().__init__(parent)
        self.tip_suffix = tip_suffix
        self.setText(text)
    def setText(self, text):
        super().setText(text)
        self.setToolTip(text + self.tip_suffix if text else '')
    def minimumSizeHint(self):
        sz = super().minimumSizeHint(); sz.setWidth(40); return sz
    def sizeHint(self):
        sz = super().sizeHint(); sz.setWidth(min(sz.width(), 400)); return sz
    def paintEvent(self, e):
        p = QPainter(self); opt = QStyleOption(); opt.initFrom(self)
        self.style().drawPrimitive(QStyle.PE_Widget, opt, p, self)
        r = self.contentsRect()
        p.setPen(self.palette().windowText().color()); p.setFont(self.font())
        p.drawText(r, Qt.AlignVCenter | Qt.AlignLeft, self.fontMetrics().elidedText(self.text().replace('\n', ' '), Qt.ElideRight, r.width()))


class Pill(QLabel):
    """Coloured status label, e.g. FLOWING / CONNECTED / SIMULATOR."""
    def __init__(self, text='', kind='off', parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.set(text, kind)

    def set(self, text, kind='off'):
        bg, fg = PILL_COLORS.get(kind, PILL_COLORS['off'])
        self.kind = kind
        self.setText(text)
        self.setStyleSheet(f'QLabel {{background:{bg};color:{fg};border-radius:9px;padding:2px 10px;font-weight:700;}}')


class Tile(QFrame):
    """Dashboard value: small caption, large value, optional detail line."""
    def __init__(self, caption, parent=None):
        super().__init__(parent)
        self.setObjectName('tile')
        v = QVBoxLayout(self)
        v.setContentsMargins(10, 6, 10, 6)
        v.setSpacing(0)
        self.caption = ElidedLabel(caption); self.caption.setObjectName('tileCaption')
        self.value = ElidedLabel('—'); self.value.setObjectName('tileValue')
        self.detail = ElidedLabel(''); self.detail.setObjectName('tileDetail')
        for w in (self.caption, self.value, self.detail):
            v.addWidget(w)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self.setMinimumWidth(110)

    def set(self, value, detail='', kind=''):
        self.value.setText(value)
        self.detail.setText(detail or ' ')   # keep the line so every tile has the same height
        self.setProperty('kind', kind)
        self.style().unpolish(self); self.style().polish(self)
