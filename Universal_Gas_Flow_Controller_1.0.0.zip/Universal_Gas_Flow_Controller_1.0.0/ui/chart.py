"""Readable real-time charts: clock-time axis, nice ticks, gridlines, hover readout, legend toggles,
shared time navigation (live / span / pan / zoom) and automatic or manual vertical scale."""
from __future__ import annotations
from bisect import bisect_left, bisect_right
from datetime import datetime
import math

from PySide6.QtCore import Qt, QObject, Signal, QRectF, QPointF
from PySide6.QtGui import QColor, QPainter, QPen, QBrush, QPolygonF, QFontMetrics, QPainterPath
from PySide6.QtWidgets import (QWidget, QFrame, QVBoxLayout, QHBoxLayout, QLabel, QCheckBox, QDoubleSpinBox,
                               QPushButton, QSizePolicy)

SERIES_COLORS = ['#2563eb', '#ea580c', '#16a34a', '#9333ea', '#db2777', '#0891b2', '#ca8a04', '#64748b']
TIME_STEPS = [1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600, 7200, 10800, 21600, 43200, 86400]
MIN_SPAN, MAX_SPAN = 10.0, 7 * 86400.0


def nice_ticks(lo, hi, target=5):
    """Round tick values (1, 2, 2.5, 5 × 10^n) covering [lo, hi]."""
    if not (math.isfinite(lo) and math.isfinite(hi)) or hi <= lo:
        return []
    raw = (hi - lo) / max(1, target)
    mag = 10 ** math.floor(math.log10(raw))
    step = next(m * mag for m in (1, 2, 2.5, 5, 10) if m * mag >= raw)
    first = math.ceil(lo / step - 1e-9) * step
    ticks, v = [], first
    while v <= hi + step * 1e-9 and len(ticks) < 50:
        ticks.append(0.0 if abs(v) < step * 1e-9 else v)
        v += step
    return ticks


def tick_label(value, step):
    """Label with just enough decimals for the tick step (2.5 -> 1 decimal, 0.25 -> 2)."""
    decimals = 0
    while decimals < 6 and abs(round(step, decimals) - step) > abs(step) * 1e-6:
        decimals += 1
    if abs(value) >= 1e6:
        return f'{value:.3g}'
    return f'{value:,.{decimals}f}'


def time_step(span, target=6):
    raw = span / max(1, target)
    return next((s for s in TIME_STEPS if s >= raw), TIME_STEPS[-1])


def time_label(t, step):
    d = datetime.fromtimestamp(t)
    return d.strftime('%H:%M') if step >= 60 else d.strftime('%H:%M:%S')


class ChartGroup(QObject):
    """Time navigation shared by several charts so they always show the same interval."""
    changed = Signal()

    def __init__(self, span=300.0):
        super().__init__()
        self.span = span          # seconds, or None for all data
        self.live = True          # follow the newest data
        self.end = None           # right edge when not live
        self.latest = None
        self.earliest = None

    def set_data_range(self, earliest, latest):
        self.earliest, self.latest = earliest, latest

    def view(self):
        if self.latest is None:
            return None
        if self.span is None:
            return (self.earliest, max(self.latest, self.earliest + MIN_SPAN))
        t1 = self.latest if self.live or self.end is None else self.end
        return (t1 - self.span, t1)

    def set_span(self, span):
        self.span = span
        if span is None:
            self.live = True
        self.changed.emit()

    def go_live(self):
        self.live = True
        self.end = None
        self.changed.emit()

    def pan(self, dt):
        v = self.view()
        if v is None:
            return
        if self.span is None:
            self.span = v[1] - v[0]
        self.live = False
        self.end = v[1] + dt
        if self.latest is not None and self.end >= self.latest:
            self.live, self.end = True, None
        self.changed.emit()

    def zoom(self, factor, anchor=None):
        v = self.view()
        if v is None:
            return
        span = min(MAX_SPAN, max(MIN_SPAN, (v[1] - v[0]) * factor))
        if not self.live and anchor is not None:
            self.end = anchor + (v[1] - anchor) * span / (v[1] - v[0])
        self.span = span
        self.changed.emit()


class TimeSeriesChart(QWidget):
    """Plot area. Series: dicts with name, points [(t, y)], color, kind ('line'|'step'), dashed, band [(t, lo, hi)]."""
    rangeChanged = Signal()

    def __init__(self, group: ChartGroup, unit='', include_zero=True, parent=None):
        super().__init__(parent)
        self.group = group
        self.unit = unit
        self.include_zero = include_zero
        self.series = []
        self.hidden = set()
        self.y_auto = True
        self.y_min, self.y_max = 0.0, 1.0
        self.empty_text = 'No data yet. Values are plotted while channels are connected.'
        self._hover = None
        self._drag = None
        self.setMouseTracking(True)
        self.setMinimumHeight(80)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setToolTip('Scroll: zoom time · Drag: move in time · Ctrl/⌘ + scroll: zoom vertically · Double-click: back to live and auto scale')
        group.changed.connect(self.update)

    # ---- data -------------------------------------------------------------------------------
    def set_series(self, series):
        for s in series:
            s['ts'] = [p[0] for p in s['points']]
        self.series = series
        if self.y_auto:
            self.y_min, self.y_max = self.auto_range()
        self.update()

    def visible_series(self):
        return [s for s in self.series if s['name'] not in self.hidden]

    def auto_range(self):
        v = self.group.view()
        lo, hi = math.inf, -math.inf
        if v:
            for s in self.visible_series():
                i0, i1 = bisect_left(s['ts'], v[0]), bisect_right(s['ts'], v[1])
                for _, y in s['points'][i0:i1]:
                    if math.isfinite(y):
                        lo, hi = min(lo, y), max(hi, y)
                for t, a, b in s.get('band') or []:
                    if v[0] <= t <= v[1] and math.isfinite(a) and math.isfinite(b):
                        lo, hi = min(lo, a), max(hi, b)
        if not math.isfinite(lo):
            return (0.0, 1.0)
        if self.include_zero and lo >= 0:
            lo = 0.0
        if hi - lo < 1e-12:
            pad = abs(hi) * 0.1 or 1.0
            return (lo - (0 if self.include_zero and lo == 0 else pad), hi + pad)
        pad = (hi - lo) * 0.08
        return (lo if self.include_zero and lo == 0 else lo - pad, hi + pad)

    def set_manual_range(self, lo, hi):
        if hi > lo:
            self.y_auto = False
            self.y_min, self.y_max = lo, hi
            self.update()
            self.rangeChanged.emit()

    def set_auto(self, on):
        self.y_auto = bool(on)
        if self.y_auto:
            self.y_min, self.y_max = self.auto_range()
        self.update()
        self.rangeChanged.emit()

    # ---- geometry ---------------------------------------------------------------------------
    def plot_rect(self):
        fm = QFontMetrics(self.font())
        ticks = nice_ticks(self.y_min, self.y_max)
        step = ticks[1] - ticks[0] if len(ticks) > 1 else 1
        label_w = max([fm.horizontalAdvance(tick_label(t, step)) for t in ticks] + [fm.horizontalAdvance('0')])
        left = label_w + fm.height() + 14
        return QRectF(left, 8, max(40, self.width() - left - 12), max(30, self.height() - 8 - fm.height() - 12))

    def t_at(self, x):
        v, r = self.group.view(), self.plot_rect()
        if not v:
            return None
        return v[0] + (x - r.left()) / max(1.0, r.width()) * (v[1] - v[0])

    # ---- interaction ------------------------------------------------------------------------
    def wheelEvent(self, e):
        steps = e.angleDelta().y() / 120.0
        if not steps:
            return
        factor = 0.8 ** steps
        if e.modifiers() & (Qt.ControlModifier | Qt.MetaModifier | Qt.ShiftModifier):
            r = self.plot_rect()
            anchor = self.y_max - (e.position().y() - r.top()) / max(1.0, r.height()) * (self.y_max - self.y_min)
            lo = anchor - (anchor - self.y_min) * factor
            hi = anchor + (self.y_max - anchor) * factor
            self.set_manual_range(lo, hi)
        else:
            self.group.zoom(factor, self.t_at(e.position().x()))
        e.accept()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = e.position().x()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            v = self.group.view()
            if v:
                dx = e.position().x() - self._drag
                self._drag = e.position().x()
                self.group.pan(-dx / max(1.0, self.plot_rect().width()) * (v[1] - v[0]))
        self._hover = e.position()
        self.update()

    def mouseReleaseEvent(self, e):
        self._drag = None

    def leaveEvent(self, e):
        self._hover = None
        self.update()

    def mouseDoubleClickEvent(self, e):
        self.group.go_live()
        self.set_auto(True)

    # ---- painting ---------------------------------------------------------------------------
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        pal = self.palette()
        bg, fg = pal.base().color(), pal.text().color()
        grid = QColor(fg); grid.setAlpha(28)
        axis = QColor(fg); axis.setAlpha(110)
        p.fillRect(self.rect(), bg)
        r = self.plot_rect()
        fm = QFontMetrics(self.font())
        v = self.group.view()
        if self.y_auto:
            self.y_min, self.y_max = self.auto_range()
        y0, y1 = self.y_min, self.y_max
        if not v or not any(s['points'] for s in self.series):
            p.setPen(axis); p.drawRect(r)
            p.setPen(fg); p.drawText(r, Qt.AlignCenter | Qt.TextWordWrap, self.empty_text)
            return
        t0, t1 = v
        sx = lambda t: r.left() + (t - t0) / max(1e-9, t1 - t0) * r.width()
        sy = lambda y: r.bottom() - (y - y0) / max(1e-12, y1 - y0) * r.height()
        # grid + labels
        yt = nice_ticks(y0, y1)
        ystep = yt[1] - yt[0] if len(yt) > 1 else 1
        for y in yt:
            yy = sy(y)
            if r.top() - 1 <= yy <= r.bottom() + 1:
                p.setPen(QPen(grid, 1)); p.drawLine(QPointF(r.left(), yy), QPointF(r.right(), yy))
                p.setPen(fg); text = tick_label(y, ystep)
                p.drawText(QRectF(0, yy - fm.height() / 2, r.left() - 6, fm.height()), Qt.AlignRight | Qt.AlignVCenter, text)
        tstep = time_step(t1 - t0, max(2, int(r.width() / 110)))
        t = math.ceil(t0 / tstep) * tstep
        while t <= t1:
            xx = sx(t)
            p.setPen(QPen(grid, 1)); p.drawLine(QPointF(xx, r.top()), QPointF(xx, r.bottom()))
            p.setPen(fg); p.drawText(QRectF(xx - 50, r.bottom() + 3, 100, fm.height()), Qt.AlignHCenter | Qt.AlignTop, time_label(t, tstep))
            t += tstep
        # unit title (rotated)
        p.save(); p.translate(fm.height() * 0.2, r.center().y()); p.rotate(-90)
        p.setPen(fg); p.drawText(QRectF(-r.height() / 2, 0, r.height(), fm.height() + 2), Qt.AlignCenter, self.unit)
        p.restore()
        p.setPen(QPen(axis, 1)); p.drawRect(r)
        # series
        p.save(); p.setClipRect(r.adjusted(0, -1, 0, 1))
        for s in self.visible_series():
            color = QColor(s['color'])
            if s.get('band'):
                pts_hi, pts_lo = [], []
                for tt, lo, hi in s['band']:
                    if t0 - (t1 - t0) <= tt <= t1 + (t1 - t0) and math.isfinite(lo) and math.isfinite(hi):
                        pts_hi.append(QPointF(sx(tt), sy(hi))); pts_lo.append(QPointF(sx(tt), sy(lo)))
                if len(pts_hi) > 1:
                    fill = QColor(color); fill.setAlpha(40)
                    p.setPen(Qt.NoPen); p.setBrush(QBrush(fill))
                    p.drawPolygon(QPolygonF(pts_hi + pts_lo[::-1]))
                    p.setBrush(Qt.NoBrush)
            pen = QPen(color, 2.2 if not s.get('dashed') else 1.8)
            if s.get('dashed'):
                pen.setStyle(Qt.DashLine)
            p.setPen(pen)
            ts = s['ts']
            i0 = max(0, bisect_left(ts, t0) - 1)
            i1 = min(len(ts), bisect_right(ts, t1) + 1)
            pts = self._decimate(s['points'][i0:i1], r.width())
            path, pen_down, prev = QPainterPath(), False, None
            for tt, y in pts:
                if not math.isfinite(y):
                    pen_down = False; prev = None; continue
                x, yy = sx(tt), sy(y)
                if not pen_down:
                    path.moveTo(x, yy); pen_down = True
                elif s.get('kind') == 'step':
                    path.lineTo(x, prev); path.lineTo(x, yy)
                else:
                    path.lineTo(x, yy)
                prev = yy
            p.drawPath(path)
        p.restore()
        # hover readout
        if self._hover is not None and r.contains(self._hover) and self._drag is None:
            th = self.t_at(self._hover.x())
            xx = self._hover.x()
            p.setPen(QPen(axis, 1, Qt.DashLine)); p.drawLine(QPointF(xx, r.top()), QPointF(xx, r.bottom()))
            lines = [datetime.fromtimestamp(th).strftime('%H:%M:%S')]
            for s in self.visible_series():
                i = bisect_left(s['ts'], th)
                cands = [j for j in (i - 1, i) if 0 <= j < len(s['ts'])]
                if not cands:
                    continue
                j = min(cands, key=lambda k: abs(s['ts'][k] - th))
                if abs(s['ts'][j] - th) > max(5.0, (t1 - t0) / 50):
                    continue
                y = s['points'][j][1]
                if math.isfinite(y):
                    extra = ''
                    if s.get('band') and j < len(s['band']):
                        lo, hi = s['band'][j][1], s['band'][j][2]
                        if math.isfinite(lo) and math.isfinite(hi):
                            extra = f' ± {self.fmt((hi - lo) / 2)}'
                    lines.append((s['color'], f"{s['name']}: {self.fmt(y)}{extra} {self.unit_short()}"))
                    p.setPen(Qt.NoPen); p.setBrush(QColor(s['color'])); p.drawEllipse(QPointF(xx, sy(y)), 3.5, 3.5)
            box_w = max(fm.horizontalAdvance(l if isinstance(l, str) else l[1]) for l in lines) + 26
            box_h = fm.height() * len(lines) + 10
            bx = xx + 12 if xx + 12 + box_w < r.right() else xx - 12 - box_w
            by = max(r.top() + 4, min(self._hover.y() - box_h / 2, r.bottom() - box_h - 4))
            panel = QColor(bg); panel.setAlpha(235)
            p.setPen(QPen(axis, 1)); p.setBrush(panel); p.drawRoundedRect(QRectF(bx, by, box_w, box_h), 5, 5)
            for k, l in enumerate(lines):
                yline = by + 5 + k * fm.height()
                if isinstance(l, str):
                    p.setPen(fg); p.drawText(QRectF(bx + 8, yline, box_w, fm.height()), Qt.AlignLeft | Qt.AlignVCenter, l)
                else:
                    p.setPen(Qt.NoPen); p.setBrush(QColor(l[0])); p.drawRect(QRectF(bx + 8, yline + fm.height() / 2 - 4, 8, 8))
                    p.setPen(fg); p.drawText(QRectF(bx + 20, yline, box_w, fm.height()), Qt.AlignLeft | Qt.AlignVCenter, l[1])

    def unit_short(self):
        return self.unit.split('(')[-1].rstrip(')') if '(' in self.unit else self.unit

    @staticmethod
    def fmt(v):
        a = abs(v)
        if a == 0:
            return '0'
        if a >= 1000:
            return f'{v:,.0f}'
        return f'{v:.4g}'

    @staticmethod
    def _decimate(points, width):
        """Keep the minimum and maximum of each pixel column so peaks stay visible with long histories."""
        limit = int(max(50, width) * 2)
        if len(points) <= limit:
            return points
        bucket = len(points) / (limit / 2)
        out = []
        for k in range(int(limit / 2)):
            chunk = [q for q in points[int(k * bucket):int((k + 1) * bucket)] if math.isfinite(q[1])]
            if not chunk:
                continue
            lo, hi = min(chunk, key=lambda q: q[1]), max(chunk, key=lambda q: q[1])
            out.extend(sorted({lo, hi}, key=lambda q: q[0]))
        return out


class ChartCard(QFrame):
    """A titled chart with legend toggles and vertical-scale controls."""

    def __init__(self, title, group, unit='', include_zero=True, parent=None):
        super().__init__(parent)
        self.setObjectName('chartCard')
        self.chart = TimeSeriesChart(group, unit, include_zero)
        v = QVBoxLayout(self); v.setContentsMargins(8, 6, 8, 6); v.setSpacing(4)
        head = QHBoxLayout(); head.setSpacing(6)
        self.title = QLabel(f'<b>{title}</b>'); head.addWidget(self.title)
        self.legend = QHBoxLayout(); self.legend.setSpacing(4); head.addLayout(self.legend)
        head.addStretch(1)
        sc = QLabel('Scale'); sc.setToolTip('Vertical axis: Auto fits the visible data; or type min and max'); head.addWidget(sc)
        self.auto = QCheckBox('Auto'); self.auto.setChecked(True); self.auto.setToolTip('Fit the vertical axis to the visible data')
        self.lo = QDoubleSpinBox(); self.hi = QDoubleSpinBox()
        for box, tip in ((self.lo, 'Bottom of the vertical axis'), (self.hi, 'Top of the vertical axis')):
            box.setRange(-1e9, 1e9); box.setDecimals(3); box.setKeyboardTracking(False); box.setToolTip(tip); box.setMinimumWidth(80); box.setMaximumWidth(110)
        head.addWidget(self.auto); head.addWidget(QLabel('min')); head.addWidget(self.lo); head.addWidget(QLabel('max')); head.addWidget(self.hi)
        v.addLayout(head)
        v.addWidget(self.chart, 1)
        self._chips = {}
        self.auto.toggled.connect(self.chart.set_auto)
        self.lo.valueChanged.connect(self._manual)
        self.hi.valueChanged.connect(self._manual)
        self.chart.rangeChanged.connect(self.sync_controls)
        self.sync_controls()

    def _manual(self):
        if self.hi.value() <= self.lo.value():
            return
        self.auto.blockSignals(True); self.auto.setChecked(False); self.auto.blockSignals(False)
        self.chart.set_manual_range(self.lo.value(), self.hi.value())

    def sync_controls(self):
        for box, val in ((self.lo, self.chart.y_min), (self.hi, self.chart.y_max)):
            box.blockSignals(True); box.setValue(val); box.blockSignals(False)
        self.auto.blockSignals(True); self.auto.setChecked(self.chart.y_auto); self.auto.blockSignals(False)
        self.lo.setEnabled(True); self.hi.setEnabled(True)

    def set_series(self, series):
        names = [s['name'] for s in series]
        if names != list(self._chips):
            while self.legend.count():
                item = self.legend.takeAt(0)
                if item.widget():
                    item.widget().hide(); item.widget().setParent(None); item.widget().deleteLater()
            self._chips = {}
            for s in series:
                chip = QPushButton(s['name']); chip.setCheckable(True); chip.setChecked(s['name'] not in self.chart.hidden)
                chip.setObjectName('legendChip'); chip.setToolTip((s.get('desc','') + '\n' if s.get('desc') else '') + 'Click to show or hide this line')
                chip.setStyleSheet(f'QPushButton#legendChip {{border-left:5px solid {s["color"]};}}'
                                   'QPushButton#legendChip[off="true"] {color:#8793a5;border-left:5px solid #8793a5;text-decoration:line-through;}')
                chip.setProperty('off', s['name'] in self.chart.hidden)
                chip.toggled.connect(lambda on, n=s['name']: self._toggle(n, on))
                chip.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
                self.legend.addWidget(chip); self._chips[s['name']] = chip
        self.chart.set_series(series)
        if self.chart.y_auto:
            self.sync_controls()

    def _toggle(self, name, on):
        (self.chart.hidden.discard if on else self.chart.hidden.add)(name)
        chip = self._chips.get(name)
        if chip:
            chip.setProperty('off', not on); chip.style().unpolish(chip); chip.style().polish(chip)
        self.chart.set_series(self.chart.series)
        self.sync_controls()
