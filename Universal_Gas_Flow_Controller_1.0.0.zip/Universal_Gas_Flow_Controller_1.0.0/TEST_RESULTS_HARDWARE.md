# Hardware test, 14 October 2026

Setup: MacBook (macOS, Apple silicon), two Xinnovis PSC converters (CH340 USB-serial, USB ID 1a86:7523).

| Controller | Port (this Mac) | Windows port | Model profile | Baud | Address | Calibration gas | Full scale | Gas |
|---|---|---|---|---|---|---|---|---|
| S300D | /dev/cu.usbserial-1110 | COM5 | S300/S300D (new ×1000) | 19200 | 1 | N2 | 500 SCCM | 5.4% H2 in N2 (Cmix 1.0418) |
| MFC-E | /dev/cu.usbserial-1120 | COM7 | MFC-E | 9600 | 2 | N2 | 500 SCCM | N2 |

macOS port names depend on the USB socket; *Device Tools → Find devices* identifies them in a few seconds. The Windows port names are as reported by the lab PC.

## Results

| Test | Result |
|---|---|
| Read-only scan, all baud rates, addresses 1–32 | One controller per converter; the single-device address read (0xFE) confirms one device on each line |
| Communication | One full read: 79 ms (S300D) / 117 ms (MFC-E) |
| S300D setpoint scale | 20 SCCM of premix commanded → **19 SCCM N2-equivalent read** (19.20 expected); totalizer +5 mL in 15 s. Confirms the ×0.001 setpoint scale (×0.01 would give 192 SCCM) |
| S300D reading resolution | Decimal code 2 → flow reported in **whole SCCM** (±0.5 SCCM on small premix flows) |
| S300D setpoint read-back | Registers 0x0022/0x0023 read 0 while flowing: not usable for verification |
| S300D start/stop | Starting from 0: **2.7–3.0 s dead time** (the valve drive rises to ~36% before gas passes), then 0.6 s to setpoint. Stopping: < 0.4 s |
| MFC-E with the N2 cylinder closed | Setpoint stored correctly (10000 = 100.00 SCCM), valve drive 43% → 76% in 3 s, flow 0. The no-gas safety stop covers this case |
| MFC-E, 100 SCCM N2 | **100.00 SCCM (99.99–100.02)**; flow after 1.3 s, within ±2% after 2.25 s; valve ≈ 53% |
| Mixture: 1% H2 at 100 SCCM | Setpoints 18.52 + 81.48 SCCM; measured 10,104 ppm (expected 10,000 ± 796 ppm); total 100.2 SCCM |
| Recipe: 0 → 5,000 → 0 ppm at 200 SCCM (10 / 20 / 10 s) | Carrier held until the premix flowed (3.0 s), total back to 200 SCCM within 1 s, exposure step 20.00 s, **5,058 ppm** steady (expected 5,000 ± 396 ppm). Arrival events logged 3.0 s (premix on), 0.4 s (carrier) and 0.5 s (premix off) after the commands |
| Safety | No false safety stops or warnings in normal operation; all channels at setpoint 0, valve 0% at the end of every test |

The "measured" concentrations (5,058 and 10,104 ppm) are quantised by the S300D's 1 SCCM reading resolution (18 instead of ~17.8 SCCM).

Raw data: `docs/verification/hardware_2026-10-14/`:
- `s300d_premix_20sccm_step.csv`, `mfce_n2_100sccm_step.csv` and `mfce_n2_100sccm_no_supply.csv`: single-controller tests.
- `20261014_144849_pulse_test.csv` and `.json`: the recipe test, recorded by the program.

## Reachable H2 range with this hardware (±10% = controller accuracy only)

| Total flow | Max | Reliable from | Within ±10% from |
|---|---|---|---|
| 200 SCCM | 5.4% | 2,867 ppm | 4,049 ppm |
| 400 SCCM | 5.4% | 1,437 ppm | 2,150 ppm |
| 500 SCCM | 5.4% | 1,141 ppm | 1,708 ppm |

Concentrations below ~2,000 ppm at 400 SCCM need a lower-concentration premix (e.g. 100–1,000 ppm H2/N2) or a smaller premix controller (10–20 SCCM full scale).
