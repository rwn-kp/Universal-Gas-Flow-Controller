APP_NAME = "Universal Gas Flow Controller"
VERSION = "1.0.0"
PUBLIC_VERSION = "1.0.0"
PROJECT_SCHEMA = 1
RELEASE_DATE = "19 November 2026"
