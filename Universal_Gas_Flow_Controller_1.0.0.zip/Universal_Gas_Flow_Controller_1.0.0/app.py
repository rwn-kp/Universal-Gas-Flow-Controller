from __future__ import annotations
import sys, os, json, csv, math, signal, time, traceback
from copy import deepcopy
from datetime import datetime
from pathlib import Path

import PySide6
from launcher import unhide_tree
# Must run before Qt loads plugins; see launcher.unhide_tree.
unhide_tree(Path(PySide6.__file__).resolve().parent / 'Qt' / 'plugins')
from PySide6.QtCore import Qt, QTimer, QRectF, QPointF
from PySide6.QtGui import QAction, QColor, QPainter, QPen, QPalette
from PySide6.QtWidgets import (
    QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QFormLayout,QLabel,QLineEdit,QPushButton,
    QComboBox,QSpinBox,QDoubleSpinBox,QCheckBox,QTabWidget,QScrollArea,QGroupBox,QTableWidget,QTableWidgetItem,
    QHeaderView,QTextEdit,QFileDialog,QMessageBox,QDialog,QDialogButtonBox,QInputDialog,QAbstractItemView,QFrame,QProgressDialog,
    QProgressBar,QSplitter,QSizePolicy,QStyle,QStyleOption,QButtonGroup
)

from version import APP_NAME, VERSION, PUBLIC_VERSION, PROJECT_SCHEMA, RELEASE_DATE
from core.channel import Channel
from core.devices import PROFILES, scan_port
from core.gases import (BUILTIN_GASES, correction_factor, normalize_composition, composition_text, outlet_composition,
                        concentration_text, flammability_error, percent_to_ppm, ppm_to_percent, outlet_concentration_uncertainty)
from core.solver import solve_source_flows
from core.modbus import BUS_POOL, ModbusClient

APP_DIR = Path(__file__).resolve().parent
def default_record_dir():
    """<app>/recordings when writable (source install), otherwise Documents/Gas Flow Recordings
    (packaged app or a read-only install such as C:\\Program Files on Windows)."""
    here=APP_DIR/'recordings'
    if not getattr(sys,'frozen',False):
        try:
            here.mkdir(exist_ok=True); probe=here/'.write_test'; probe.write_text('ok',encoding='utf-8'); probe.unlink(); return here
        except OSError: pass
    docs=Path.home()/'Documents'
    return (docs if docs.is_dir() else Path.home())/'Gas Flow Recordings'
DEFAULT_RECORD_DIR = default_record_dir()
ANY_BALANCE = ('', '*', 'any')
# Steps whose expected concentration is less certain than this (relative) are flagged before running.
MAX_REL_UNCERTAINTY = 0.10

def port_label(info):
    """'device — description', marking the CH340 USB-serial chip used by the Xinnovis PSC-100/PSC-200 converters."""
    desc=(getattr(info,'description','') or '').strip(); text=info.device
    if desc and desc!='n/a' and desc!=info.device: text+=f' — {desc}'
    if 'CH34' in (desc+(getattr(info,'manufacturer',None) or '')).upper() or getattr(info,'vid',None)==0x1A86: text+='  (PSC converter)'
    return text

# macOS system pseudo-ports that are never a flow controller.
IGNORED_PORTS=('debug-console','wlan-debug','Bluetooth-Incoming-Port')

def list_serial_ports():
    try:
        from serial.tools import list_ports
        return [p for p in list_ports.comports() if not any(x in p.device for x in IGNORED_PORTS)]
    except Exception: return []

def fmt_duration(seconds):
    seconds=max(0,int(round(seconds))); h,rem=divmod(seconds,3600); m,s=divmod(rem,60)
    return f'{h}:{m:02d}:{s:02d}' if h else f'{m}:{s:02d}'

def low_range_warnings(channels, flows, label=''):
    out=[]
    for c,f in zip(channels,flows):
        fs=c.reading.full_scale; raw=f/c.cmix if f else 0.0
        lo=c.profile().min_fraction
        if fs and 0<raw<lo*fs: out.append(f'{label}{c.name} at {fmt_sig(100*raw/fs,3)}% of full scale (the {c.profile().name} controls from {lo*100:g}%)')
    return out

def expected_concentration(channels, flows, gas):
    """Outlet percentage and ± uncertainty after setpoint rounding, from the manufacturer accuracy specs."""
    q=[c.quantized(f) if f else 0.0 for c,f in zip(channels,flows)]
    return outlet_concentration_uncertainty([(c.source,f,c.flow_uncertainty(f)) for c,f in zip(channels,q)],gas)

def concentration_limits(channels, gas, total, balance=None):
    """Reachable outlet range of ``gas`` (percent) at ``total`` flow with these sources.

    Returns (max_reachable, min_reliable, min_within_uncertainty) or None when it cannot be judged
    (no source contains the gas, or a channel is not connected so its full scale is unknown).
    balance=None means any remainder (dilution); otherwise the outlet is gas + balance only.
    """
    if not channels or total<=0 or any(not c.connected for c in channels): return None
    srcs=[c.source for c in channels]; top=max(normalize_composition(s).get(gas,0.0) for s in srcs)
    if top<=0: return None
    feasible=[]; reliable=[]; good=[]
    for k in range(0,281):
        x=top*10**(-k/40)
        try:
            fl=solve_source_flows(srcs,{gas:x},total,constrained_gases=[gas]) if balance is None else solve_source_flows(srcs,normalize_composition({gas:x,balance:100-x}),total)
        except ValueError: continue
        if any(f/c.cmix>c.reading.full_scale*(1+1e-9) for c,f in zip(channels,fl)): continue
        feasible.append(x)
        if all(f<=1e-12 or f/c.cmix>=c.profile().min_fraction*c.reading.full_scale for c,f in zip(channels,fl)): reliable.append(x)
        e,u=expected_concentration(channels,fl,gas)
        if e and u is not None and u/e<=MAX_REL_UNCERTAINTY: good.append(x)
    if not feasible: return (None,None,None)
    return (max(feasible),min(reliable) if reliable else None,min(good) if good else None)

def limits_text(lim, gas, total, unit):
    if lim is None: return f'Connect all channels to see which {gas} concentrations are reachable.'
    mx,rel,good=lim
    if mx is None: return f'{gas} cannot be produced at {fmt_sig(total,5)} {unit} total with these sources and controller ranges.'
    return (f'At {fmt_sig(total,5)} {unit} total: {gas} up to {concentration_text(mx)}'+
            (f' · reliable from {concentration_text(rel)}' if rel else '')+
            (f' · within ±{MAX_REL_UNCERTAINTY*100:g}% from {concentration_text(good)}' if good else ''))

def uncertainty_text(pct, err):
    if pct is None: return '—'
    if err is None: return concentration_text(pct)
    return concentration_text(pct)+f' ± {concentration_text(err)}'+(f' ({100*err/pct:.2g}%)' if pct>0 and 0<100*err/pct<10 else f' ({100*err/pct:.0f}%)' if pct>0 and err>0 else '')

def fmt_sig(v, sig=5):
    try:
        v=float(v)
        if not math.isfinite(v): return '—'
        if v==0: return '0'
        return f'{v:.{max(1,int(sig))}g}'
    except Exception: return '—'

def now_text(): return datetime.now().strftime('%H:%M:%S')

def button_color(btn, role):
    btn.setProperty('role',role); btn.style().unpolish(btn); btn.style().polish(btn)

from ui.composition import GasCompositionDialog, TargetCompositionEditor
from ui.chart import ChartGroup, ChartCard, SERIES_COLORS
from ui.widgets import wrap, Pill, Tile, ElidedLabel

def pulse_sequence_rows(gas, balance, concentrations, repeats, baseline_s, exposure_s, purge_s, final_purge_s, total_flow, unit='ppm'):
    """Rows for a 'Gas concentration' recipe: baseline, then exposure/purge pulses for each concentration."""
    rows=[]; add=lambda dur,conc,note: rows.append(['',fmt_sig(dur,9),gas,fmt_sig(conc,9),balance,fmt_sig(total_flow,9),note])
    if baseline_s>0: add(baseline_s,0,'Baseline')
    for conc in concentrations:
        for k in range(1,int(repeats)+1):
            add(exposure_s,conc,f'Exposure {fmt_sig(conc,6)} {unit} ({k}/{int(repeats)})')
            if purge_s>0: add(purge_s,0,'Purge')
    if final_purge_s>0: add(final_purge_s,0,'Final purge')
    return rows

class SummaryBar(QFrame):
    """Dashboard tiles under the banner; the grid re-flows to the window width."""
    KEYS=[('mode','Mode'),('target','Target'),('expected','Expected (± accuracy)'),('measured','Measured (from flows)'),('total','Total flow'),('recipe','Recipe'),('rec','Recording')]
    def __init__(self):
        super().__init__(); self.setObjectName('summaryBar'); self.grid=QGridLayout(self); self.grid.setContentsMargins(0,0,0,0); self.grid.setSpacing(6)
        self.tiles={k:Tile(cap) for k,cap in self.KEYS}; self._cols=0; self.reflow()
    def reflow(self):
        n=len(self.KEYS); cols=n if self.width()<=0 or self.width()>=n*118 else (n+1)//2
        if cols==self._cols: return
        self._cols=cols
        for k,_ in self.KEYS: self.grid.removeWidget(self.tiles[k])
        for i,(k,_) in enumerate(self.KEYS): self.grid.addWidget(self.tiles[k],i//cols,i%cols)
        for c in range(len(self.KEYS)): self.grid.setColumnStretch(c,1 if c<cols else 0)
    def resizeEvent(self,e): super().resizeEvent(e); self.reflow()
    def text(self):
        return ' | '.join(f"{t.caption.text()}: {t.value.text()} {t.detail.text()}".strip() for t in self.tiles.values())

class ChannelCard(QFrame):
    """One controller: status, connection, gas, live measurement and a range-limited setpoint."""
    def __init__(self, mw, channel, index):
        super().__init__(); self.mw=mw; self.channel=channel; self.index=index; self.setObjectName('channelCard')
        v=QVBoxLayout(self); v.setContentsMargins(12,10,12,10); v.setSpacing(6)
        head=QHBoxLayout(); self.name=QLineEdit(channel.name); self.name.setObjectName('cardName'); self.name.setToolTip('Channel name (used in charts, recipes and recordings)'); self.name.editingFinished.connect(self.rename); head.addWidget(self.name,1)
        self.sim_pill=Pill('SIMULATOR','sim'); self.sim_pill.setToolTip('No real gas flows: this channel uses the built-in simulator'); head.addWidget(self.sim_pill)
        self.state_pill=Pill('OFFLINE','off'); head.addWidget(self.state_pill)
        self.remove_btn=QPushButton('Remove'); self.remove_btn.setToolTip('Remove this channel'); self.remove_btn.clicked.connect(self.ask_remove); head.addWidget(self.remove_btn); v.addLayout(head)
        # connection
        self.conn_box=QFrame(); cg=QGridLayout(self.conn_box); cg.setContentsMargins(0,0,0,0); cg.setHorizontalSpacing(8)
        self.port=QComboBox(); self.port.setToolTip('Serial port of the USB converter, or Simulator'); self.profile=QComboBox(); self.profile.setToolTip('Controller model; it sets the setpoint scaling and accuracy')
        for k,p in PROFILES.items(): self.profile.addItem(p.name,k)
        self.addr=QSpinBox(); self.addr.setRange(1,247); self.addr.setValue(channel.address); self.addr.setToolTip('Modbus address of the controller (factory default 1)')
        self.baud=QComboBox(); self.baud.setEditable(True); self.baud.addItems(['9600','19200','38400','57600','115200']); self.baud.setCurrentText(str(channel.baud)); self.baud.setToolTip('Baud rate. If unsure use Device Tools → Find devices')
        cg.addWidget(QLabel('Port'),0,0); cg.addWidget(self.port,0,1); cg.addWidget(QLabel('Model'),0,2); cg.addWidget(self.profile,0,3)
        cg.addWidget(QLabel('Address'),1,0); cg.addWidget(self.addr,1,1); cg.addWidget(QLabel('Baud'),1,2); cg.addWidget(self.baud,1,3)
        cg.setColumnStretch(1,1); cg.setColumnStretch(3,1); v.addWidget(self.conn_box)
        ch=QHBoxLayout(); self.conn_summary=wrap(muted=True); ch.addWidget(self.conn_summary,1); self.connect_btn=QPushButton('Connect'); self.connect_btn.clicked.connect(self.toggle_connect); ch.addWidget(self.connect_btn); v.addLayout(ch)
        v.addWidget(self.separator())
        # gas
        gh=QHBoxLayout(); gl=QVBoxLayout(); gl.setSpacing(0); self.source=wrap(); self.source.setObjectName('sourceText'); gl.addWidget(self.source); self.cmix=wrap(muted=True); gl.addWidget(self.cmix); gh.addLayout(gl,1)
        self.gas_btn=QPushButton('Change gas…'); self.gas_btn.setToolTip('Gas composition of the cylinder feeding this controller'); self.gas_btn.clicked.connect(self.edit_gas); gh.addWidget(self.gas_btn,0,Qt.AlignTop); v.addLayout(gh)
        v.addWidget(self.separator())
        # measurement
        mh=QHBoxLayout(); mv=QVBoxLayout(); mv.setSpacing(0); cap=QLabel('Measured flow (this gas)'); cap.setObjectName('caption'); mv.addWidget(cap)
        self.corrected=QLabel('—'); self.corrected.setObjectName('flowValue'); mv.addWidget(self.corrected); mh.addLayout(mv)
        self.bar=QProgressBar(); self.bar.setRange(0,1000); self.bar.setTextVisible(True); self.bar.setToolTip('Device reading as a fraction of its full scale'); mh.addWidget(self.bar,1); v.addLayout(mh)
        self.raw=wrap(muted=True); v.addWidget(self.raw)
        v.addWidget(self.separator())
        # setpoint
        sh=QHBoxLayout(); sh.addWidget(QLabel('Setpoint'))
        self.setpoint=QDoubleSpinBox(); self.setpoint.setDecimals(3); self.setpoint.setRange(0,1e6); self.setpoint.setKeyboardTracking(False); self.setpoint.setToolTip('Flow of this gas to deliver. It cannot exceed the controller maximum.'); self.setpoint.valueChanged.connect(self.setpoint_edited); sh.addWidget(self.setpoint,1)
        self.start=QPushButton('Start flow'); self.start.clicked.connect(self.do_start); button_color(self.start,'start'); sh.addWidget(self.start)
        self.stop=QPushButton('Stop'); self.stop.setToolTip('Command 0 flow'); self.stop.clicked.connect(self.do_stop); button_color(self.stop,'stop'); sh.addWidget(self.stop); v.addLayout(sh)
        self.limits=wrap(muted=True); v.addWidget(self.limits)
        self.configured=QLabel('—'); self.configured.setVisible(False)
        self.hint=wrap(); self.hint.setObjectName('warnText'); self.hint.setVisible(False); v.addWidget(self.hint)
        self.tracking=wrap(); self.tracking.setObjectName('errorText'); self.tracking.setVisible(False); v.addWidget(self.tracking)
        self.device_info=wrap(muted=True); v.addWidget(self.device_info)
        self.profile.setCurrentIndex(max(0,self.profile.findData(channel.profile_key))); self.profile.currentIndexChanged.connect(self.profile_changed); self.addr.valueChanged.connect(self.sync_config); self.baud.currentTextChanged.connect(self.sync_config); self.port.currentIndexChanged.connect(self.sync_config)
        self.setMinimumWidth(420); self.refresh_ports(); self.update_all()
    @staticmethod
    def separator():
        f=QFrame(); f.setFrameShape(QFrame.HLine); f.setObjectName('sep'); return f
    def setTitle(self,text): pass
    def refresh_ports(self):
        current=self.channel.port; self.port.blockSignals(True); self.port.clear(); self.port.addItem('Simulator (no real gas)','Simulator')
        for p in list_serial_ports(): self.port.addItem(port_label(p),p.device)
        if self.port.findData(current)<0: self.port.addItem(current,current)
        self.port.setCurrentIndex(max(0,self.port.findData(current))); self.port.blockSignals(False)
    def rename(self):
        name=self.name.text().strip() or f'Channel {self.index+1}'
        if any(c is not self.channel and c.name==name for c in self.mw.channels): name=f'{name} ({self.index+1})'; self.mw.status('Channel names must be unique; a number was added.',error=True)
        self.channel.name=name; self.name.setText(name); self.mw.structure_changed()
    def ask_remove(self):
        c=self.channel
        if (c.connected or c.working) and QMessageBox.question(self,'Remove channel',f'Remove {c.name}?'+('\n\nIt is flowing; all channels will be stopped.' if c.working else '\n\nIt will be disconnected.'))!=QMessageBox.Yes: return
        self.mw.remove_channel(self)
    def profile_changed(self):
        key=self.profile.currentData(); self.channel.profile_key=key; d=PROFILES[key].default_baud; self.baud.setCurrentText(str(d)); self.sync_config(); self.update_all()
    def sync_config(self):
        if self.channel.connected: return
        self.channel.port=self.port.currentData() or self.port.currentText(); self.channel.address=self.addr.value();
        try:self.channel.baud=int(self.baud.currentText())
        except ValueError:self.channel.baud=PROFILES[self.channel.profile_key].default_baud
        if hasattr(self,'sim_pill'): self.update_all()
    def toggle_connect(self):
        if self.channel.connected:
            if self.channel.working and QMessageBox.question(self,'Disconnect',f'{self.channel.name} is flowing. Disconnecting stops ALL channels (safety stop). Continue?')!=QMessageBox.Yes: return
            # User-requested disconnection is treated as a fail-safe event if any output is active.
            if any(c.working for c in self.mw.channels): self.mw.fail_safe_stop(f'{self.channel.name} was disconnected by the user', self.channel)
            self.channel.disconnect(); self.mw.status(f'{self.channel.name} disconnected'); self.update_all(); self.mw.refresh_mixture_sources(); self.mw.update_summary(); self.mw.schedule_recipe_check(); return
        if self.mw.fail_safe_latched: self.mw.status('Acknowledge the safety stop before reconnecting or starting outputs',error=True); return
        if self.channel.port != 'Simulator' and any(c is not self.channel and c.connected and c.port == self.channel.port and c.address == self.channel.address for c in self.mw.channels):
            self.mw.status('Another connected channel already uses this port and address.', error=True); return
        self.sync_config(); self.mw.status(f'Connecting {self.channel.name}…',working=True)
        try:self.channel.connect(); self.mw.status(f'{self.channel.name} connected')
        except Exception as e:self.channel.connected=False; self.mw.status(f'Connection failed: {e}. Check 24 V power, the cable, model, address and baud rate (Device Tools → Find devices).',error=True)
        self.update_all(); self.mw.update_tools_info(); self.mw.refresh_mixture_sources(); self.mw.update_summary(); self.mw.rebuild_recipe_table(preserve=True); self.mw.schedule_recipe_check()
    def edit_gas(self):
        d=GasCompositionDialog(self.channel.source,self.mw.gas_library,self)
        if d.exec()==QDialog.Accepted: self.channel.source=d.composition; self.mw.gas_library.update(d.lib); self.mw.refresh_gas_library_ui(); self.mw.invalidate_mixture(); self.update_all(); self.mw.structure_changed()
    # setpoint limits (corrected units)
    def max_setpoint(self):
        r=self.channel.reading; return r.full_scale*self.channel.cmix if self.channel.connected and r.full_scale else None
    def min_reliable(self):
        r=self.channel.reading; return self.channel.profile().min_fraction*r.full_scale*self.channel.cmix if self.channel.connected and r.full_scale else None
    def setpoint_edited(self):
        self.update_hint()
    def update_hint(self):
        val=self.setpoint.value(); lo=self.min_reliable(); msg=''
        if lo and 0<val<lo: msg=f'⚠ {self.mw.fmt(val)} is below the reliable range (from {self.mw.fmt(lo)} {self.channel.reading.flow_unit}); the delivered flow may differ a lot.'
        self.hint.setText(msg); self.hint.setVisible(bool(msg))
    def apply_config(self):
        try:self.channel.configure(self.setpoint.value()); self.mw.status(f'{self.channel.name} setpoint stored ({self.mw.fmt(self.channel.configured_setpoint)}); press Start flow to run'); self.mw.invalidate_mixture()
        except Exception as e:self.mw.status(str(e),error=True)
        self.update_buttons()
    def configure_zero(self): self.setpoint.setValue(0); self.apply_config()
    def do_start(self):
        if self.mw.fail_safe_latched: self.mw.status('Safety stop is active. Acknowledge it before starting.',error=True); return
        if self.mw.recipe_running: self.mw.status('A recipe controls the flows. Stop the recipe before manual control.',error=True); return
        if not self.channel.connected: self.mw.status(f'Connect {self.channel.name} first.',error=True); return
        was=self.channel.working
        try:self.channel.configure(self.setpoint.value())
        except Exception as e:self.mw.status(str(e),error=True); return
        self.mw.invalidate_mixture()
        try:
            self.channel.start(); verb='updated to' if was else 'started at'
            self.mw.status(f'{self.channel.name} {verb} {self.mw.fmt(self.channel.configured_setpoint)} {self.channel.reading.flow_unit}'); self.mw.record_event(f'{self.channel.name} {verb} {self.mw.fmt(self.channel.configured_setpoint)}')
        except Exception as e:self.mw.fail_safe_stop(f'Start failed: {e}', self.channel)
        self.update_all(); self.mw.update_summary()
    def do_stop(self):
        if self.mw.recipe_running: self.mw.stop_recipe_now('Recipe stopped by channel Stop'); return
        self.mw.status(f'Stopping {self.channel.name}…',working=True)
        try:self.channel.stop(); self.mw.status(f'{self.channel.name} stopped'); self.mw.record_event(f'{self.channel.name} stopped')
        except Exception as e:self.mw.fail_safe_stop(f'Stop failed: {e}', self.channel)
        self.mw.invalidate_mixture(); self.update_all(); self.mw.update_summary()
    def update_buttons(self):
        c=self.channel; busy=self.mw.recipe_running; latched=self.mw.fail_safe_latched
        self.start.setText('Apply new setpoint' if c.working else 'Start flow')
        self.start.setEnabled(c.connected and not latched and not busy)
        self.start.setToolTip('Send the setpoint now' if c.working else 'Start flowing at the setpoint')
        self.stop.setEnabled(c.connected and c.working)
        self.setpoint.setEnabled(c.connected and not busy)
        self.gas_btn.setEnabled(not c.working and not busy)
        self.remove_btn.setEnabled(not busy)
        self.connect_btn.setText('Disconnect' if c.connected else 'Connect')
        self.conn_box.setVisible(not c.connected)
        for w in (self.profile,self.port,self.addr,self.baud): w.setEnabled(not c.connected)
    def update_all(self):
        c=self.channel; r=c.reading; sig=self.mw.sig_digits; unit=r.flow_unit; p=c.profile()
        sim=(c.port=='Simulator'); self.sim_pill.setVisible(sim)
        if not c.connected: self.state_pill.set('OFFLINE','off')
        elif self.mw.fail_safe_latched: self.state_pill.set('SAFETY STOP','error')
        elif c.tracking_warning: self.state_pill.set('CHECK FLOW','warn')
        elif c.working: self.state_pill.set('FLOWING','flow')
        else: self.state_pill.set('CONNECTED · IDLE','ok')
        self.conn_summary.setText(f'{c.port} · {p.name} · address {c.address} · {c.baud} baud' if c.connected else 'Not connected. Choose port, model, address and baud rate, then Connect.')
        self.source.setText('Gas: '+composition_text(c.source,sig))
        self.cmix.setText(f'Correction factor Cmix {fmt_sig(c.cmix,sig)} · device calibrated for {r.calibration_text}' if c.connected else f'Correction factor Cmix {fmt_sig(c.cmix,sig)} (relative to N2)')
        if c.connected:
            self.corrected.setText(f'{fmt_sig(c.corrected_flow,sig)} {unit}')
            frac=r.raw_flow/r.full_scale if r.full_scale else 0
            self.bar.setValue(int(max(0,min(1,frac))*1000)); self.bar.setFormat(f'{frac*100:.1f}% of maximum')
            self.raw.setText(f'Device reading {fmt_sig(r.raw_flow,sig)} {unit} (N2-equivalent)'+(f' · valve {r.valve:.0f}%' if r.valve is not None else '')+f' · {fmt_sig(r.temperature,3)} °C · total {fmt_sig(r.accumulated,sig)} {r.accumulated_unit}')
        else:
            self.corrected.setText('—'); self.bar.setValue(0); self.bar.setFormat('not connected'); self.raw.setText('')
        self.raw.setVisible(c.connected)
        mx=self.max_setpoint(); lo=self.min_reliable()
        if self.setpoint.suffix()!=' '+unit: self.setpoint.setSuffix(' '+unit)
        if mx is not None and abs(self.setpoint.maximum()-mx)>1e-9: self.setpoint.setMaximum(mx)
        if c.working and c.configured_setpoint is not None and not self.setpoint.hasFocus():
            self.setpoint.blockSignals(True); self.setpoint.setValue(c.configured_setpoint); self.setpoint.blockSignals(False)
        if mx is None: self.limits.setText('The allowed setpoint range is shown after connecting (it depends on the device full scale and the gas).')
        else:
            acc=c.flow_uncertainty(c.configured_setpoint) if c.working and c.configured_setpoint else p.accuracy(0,r.full_scale)*c.cmix
            self.limits.setText(f'Allowed 0 – {self.mw.fmt(mx)} {unit} for this gas · reliable from {self.mw.fmt(lo)} {unit} · accuracy ±{fmt_sig(acc,2)} {unit}'+(f' · now running at {self.mw.fmt(c.configured_setpoint)} {unit}' if c.working else ''))
        self.configured.setText('—' if c.configured_setpoint is None else fmt_sig(c.configured_setpoint,sig))
        self.tracking.setText('⚠ '+c.tracking_warning); self.tracking.setVisible(bool(c.tracking_warning))
        acc=f'±{p.acc_fs*100:g}% of full scale or ±{p.acc_sp*100:g}% of setpoint'+(', whichever is larger' if p.sp_from is None else f' (above {p.sp_from*100:g}% FS)')
        self.device_info.setText(f'{p.name}: {acc}; controls from {p.min_fraction*100:g}% of full scale'+(f' · full scale {fmt_sig(r.full_scale,sig)} {unit} N2 · reading resolution {r.resolution:g} {unit}' if c.connected else ''))
        self.update_hint(); self.update_buttons()

class MainWindow(QMainWindow):
    POLL_MS=500
    def __init__(self):
        super().__init__(); self.setWindowTitle(f'{APP_NAME} {PUBLIC_VERSION}'); self.resize(1280,820); self.channels=[]; self.cards=[]; self.gas_library=dict(BUILTIN_GASES); self.sig_digits=5; self.dark=False; self.fail_safe_latched=False; self._failsafe_running=False; self._closing=False; self.mixture_applied=False; self.chart_data=[]; self.recordings=[]; self.active_recording=None; self.recipe_running=False; self.recipe_state=None; self._record_stream=None; self._pending_events=[]; self._sequence=None
        self._build_ui(); self.add_channel(); self.add_channel(); self.poll_timer=QTimer(self); self.poll_timer.setTimerType(Qt.PreciseTimer); self.poll_timer.timeout.connect(self.poll_all); self.poll_timer.start(self.POLL_MS); self.chart_timer=QTimer(self); self.chart_timer.timeout.connect(self.refresh_charts); self.chart_timer.start(1000); self.update_summary()
        self.setMinimumSize(900,560); self.fit_window(); QTimer.singleShot(0,self.showMaximized)
    def _build_ui(self):
        root=QWidget(); self.setCentralWidget(root); v=QVBoxLayout(root); v.setContentsMargins(8,6,8,6); v.setSpacing(6)
        top=QHBoxLayout(); self.save_btn=QPushButton('Save project'); self.load_btn=QPushButton('Load project'); self.save_btn.setToolTip('Save channels, gases, mixture and recipe settings (not recordings)'); self.save_btn.clicked.connect(self.save_project); self.load_btn.clicked.connect(self.ui_load_project); top.addWidget(self.save_btn); top.addWidget(self.load_btn)
        self.banner=ElidedLabel('Ready',tip_suffix='\n\n(Full history: Log tab)'); self.banner.setObjectName('statusBanner'); self.banner.setMinimumHeight(32); self.banner.setContentsMargins(8,0,8,0); top.addWidget(self.banner,1)
        self.failsafe_label=Pill('SAFETY OK','ok'); self.failsafe_label.setToolTip('Any communication or command error stops all flows and shows SAFETY STOP until acknowledged'); top.addWidget(self.failsafe_label)
        self.ack_btn=QPushButton('Acknowledge safety stop…'); self.ack_btn.clicked.connect(self.ask_ack_failsafe); self.ack_btn.setVisible(False); top.addWidget(self.ack_btn)
        self.stop_all=QPushButton('■  STOP ALL'); self.stop_all.setObjectName('stopAll'); self.stop_all.setToolTip('Command 0 flow on every channel and stop any recipe (Esc)'); self.stop_all.setShortcut('Esc'); button_color(self.stop_all,'stop'); self.stop_all.clicked.connect(lambda:self.emergency_stop_all('STOP ALL pressed', latch=False)); top.addWidget(self.stop_all); v.addLayout(top)
        self.summary=SummaryBar(); v.addWidget(self.summary)
        self.tabs=QTabWidget(); self.tabs.tabBar().setDrawBase(False); v.addWidget(self.tabs,1); self._build_channels_tab(); self._build_mixture_tab(); self._build_recipes_tab(); self._build_charts_tab(); self._build_data_tab(); self._build_tools_tab(); self._build_log_tab(); self._build_menu(); self.apply_theme()
    def _build_menu(self):
        fm=self.menuBar().addMenu('File');
        for text,fn in [('New project',self.ui_new_project),('Load project…',self.ui_load_project),('Save project',self.save_project),('Export chart data (CSV)…',self.export_chart_csv),('Exit',self.request_close)]: a=QAction(text,self); a.triggered.connect(fn); fm.addAction(a)
        dm=self.menuBar().addMenu('Devices'); a=QAction('Refresh serial ports',self); a.triggered.connect(self.refresh_ports); dm.addAction(a); a=QAction('Auto-number channel addresses',self); a.triggered.connect(self.auto_number_addresses); dm.addAction(a)
        vm=self.menuBar().addMenu('View'); a=QAction('Fit window to screen',self); a.triggered.connect(self.fit_window); vm.addAction(a); self.dark_action=QAction('Dark mode',self); self.dark_action.setCheckable(True); self.dark_action.toggled.connect(self.set_dark); vm.addAction(self.dark_action)
        hm=self.menuBar().addMenu('Help'); g=QAction('Quick guide and safety notes',self); g.triggered.connect(self.show_guide); hm.addAction(g); a=QAction('About',self); a.triggered.connect(lambda:QMessageBox.information(self,'About',f'{APP_NAME}\nVersion {PUBLIC_VERSION} ({VERSION})\nReleased {RELEASE_DATE}\nProject schema {PROJECT_SCHEMA}\n\nDesktop control of Xinnovis MFC-E and S300/S300D mass flow controllers for gas-sensor experiments: H2 concentrations in ppm, timed pulse recipes, uncertainty estimates, crash-safe recording and safety interlocks.')); hm.addAction(a)
    def _build_channels_tab(self):
        w=QWidget(); v=QVBoxLayout(w); v.setContentsMargins(0,6,0,0); bar=QHBoxLayout(); add=QPushButton('+ Add channel'); add.setToolTip('Add another flow controller'); add.clicked.connect(lambda: self.add_channel()); bar.addWidget(add)
        bar.addWidget(wrap('Each card is one flow controller. Connect it, choose its gas, then set a flow. Flows can also be set from the Mixture or Recipes tab.',muted=True),1)
        bar.addWidget(QLabel('Significant digits')); self.sig=QSpinBox(); self.sig.setRange(2,9); self.sig.setValue(5); self.sig.setToolTip('Number of significant digits shown'); self.sig.valueChanged.connect(self.set_sig); bar.addWidget(self.sig); v.addLayout(bar)
        self.channel_scroll=QScrollArea(); self.channel_scroll.setWidgetResizable(True); self.channel_scroll.setFrameShape(QFrame.NoFrame); self.cards_host=QWidget(); self.cards_grid=QGridLayout(self.cards_host); self.cards_grid.setAlignment(Qt.AlignTop); self.cards_grid.setSpacing(10); self.channel_scroll.setWidget(self.cards_host); v.addWidget(self.channel_scroll); self.tabs.addTab(w,'Channels')
    def _build_mixture_tab(self):
        w=QWidget(); outer=QVBoxLayout(w); outer.setContentsMargins(0,6,0,0)
        outer.addWidget(wrap('Set a fixed outlet mixture: enter the target composition and total flow; the program computes every channel setpoint from the cylinder compositions. Nothing flows until you click Apply mixture.',muted=True))
        split=QSplitter(Qt.Horizontal); split.setChildrenCollapsible(False); outer.addWidget(split,1)
        left=QGroupBox('1  Target outlet composition'); lv=QVBoxLayout(left); self.target_editor=TargetCompositionEditor(self.gas_library,self.recalculate_mixture); lv.addWidget(self.target_editor)
        th=QHBoxLayout(); th.addWidget(QLabel('Total flow')); self.total_flow=QDoubleSpinBox(); self.total_flow.setRange(0,1e6); self.total_flow.setDecimals(3); self.total_flow.setValue(100); self.total_flow.setSuffix(' SCCM'); self.total_flow.setKeyboardTracking(False); self.total_flow.setToolTip('Sum of all channel flows (corrected for each gas)'); self.total_flow.valueChanged.connect(self.recalculate_mixture); th.addWidget(self.total_flow,1); lv.addLayout(th)
        self.mix_limits=wrap(muted=True); lv.addWidget(self.mix_limits)
        self.solver_status=wrap(); lv.addWidget(self.solver_status)
        scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame); scroll.setWidget(left); scroll.setMinimumWidth(320); split.addWidget(scroll)
        right=QGroupBox('2  Sources and computed setpoints'); rv=QVBoxLayout(right); self.mix_table=QTableWidget(0,6); self.mix_table.setHorizontalHeaderLabels(['Use','Channel','Cylinder gas','Setpoint (this gas)','Device setpoint (N2-eq.)','% of max']); self.mix_table.verticalHeader().setVisible(False); self.mix_table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.mix_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.mix_table.horizontalHeader().setSectionResizeMode(2,QHeaderView.Stretch); rv.addWidget(self.mix_table,1)
        hb=QHBoxLayout(); self.apply_mix=QPushButton('▶  Apply mixture'); self.apply_mix.setToolTip('Start all used channels at the computed setpoints'); self.apply_mix.clicked.connect(self.apply_mixture); self.stop_mix=QPushButton('■  Stop mixture'); self.stop_mix.clicked.connect(lambda:self.emergency_stop_all('Mixture stopped',latch=False)); button_color(self.apply_mix,'start'); button_color(self.stop_mix,'stop'); self.mix_badge=Pill('NOT APPLIED','off'); hb.addWidget(self.apply_mix); hb.addWidget(self.stop_mix); hb.addStretch(); hb.addWidget(self.mix_badge); rv.addLayout(hb)
        split.addWidget(right); split.setStretchFactor(0,2); split.setStretchFactor(1,3); self.tabs.addTab(w,'Mixture')
    def _build_charts_tab(self):
        w=QWidget(); v=QVBoxLayout(w); v.setContentsMargins(0,6,0,0); v.setSpacing(6); self.chart_group=ChartGroup(300)
        bar=QHBoxLayout(); bar.addWidget(QLabel('Time span'))
        self.span_buttons=QButtonGroup(self); self.span_buttons.setExclusive(True); self._span_btn={}
        for label,span in [('1 min',60),('5 min',300),('15 min',900),('1 h',3600),('6 h',21600),('All',None)]:
            b=QPushButton(label); b.setCheckable(True); b.setObjectName('segment'); b.setToolTip('Show this much history' if span else 'Show all collected data'); b.clicked.connect(lambda _,s=span:self.chart_group.set_span(s)); self.span_buttons.addButton(b); bar.addWidget(b); self._span_btn[span]=b
        self._span_btn[300].setChecked(True)
        self.live_btn=QPushButton('● Live'); self.live_btn.setObjectName('liveBtn'); self.live_btn.setToolTip('Follow the newest data. Dragging a chart pauses following; click to return.'); self.live_btn.clicked.connect(self.chart_group.go_live); bar.addSpacing(8); bar.addWidget(self.live_btn)
        bar.addStretch(1); bar.addWidget(QLabel('Gas')); self.chart_gas=QComboBox(); self.chart_gas.addItems(sorted(self.gas_library)); self.chart_gas.setCurrentText('H2'); self.chart_gas.setToolTip('Gas shown in the concentration chart and summary'); self.chart_gas.currentTextChanged.connect(lambda _: (self.refresh_charts(), self.update_summary())); bar.addWidget(self.chart_gas)
        bar.addWidget(QLabel('in')); self.chart_unit=QComboBox(); self.chart_unit.addItems(['ppm','%']); self.chart_unit.currentTextChanged.connect(lambda _: self.refresh_charts()); bar.addWidget(self.chart_unit); v.addLayout(bar)
        bar2=QHBoxLayout(); bar2.addWidget(QLabel('Show'))
        self.chart_cards={}
        specs=[('flow','Flow rate','Flow (SCCM)',True),('conc','Concentration','H2 (ppm)',True),('temp','Controller temperature','Temperature (°C)',False)]
        for key,title,unit,zero in specs: self.chart_cards[key]=ChartCard(title,self.chart_group,unit,zero)
        for key,title,_,_ in specs:
            cb=QCheckBox(title); cb.setChecked(key!='temp'); cb.toggled.connect(self.chart_cards[key].setVisible); self.chart_cards[key].setVisible(key!='temp'); bar2.addWidget(cb)
        tip=ElidedLabel('Scroll: zoom time · Drag: look back · Ctrl/⌘+scroll: zoom vertically · Double-click: live · Hover: read values · Click a legend name to hide a line'); tip.setObjectName('muted'); bar2.addWidget(tip,1)
        exp=QPushButton('Export CSV…'); exp.setToolTip('Save the data in the visible time span'); exp.clicked.connect(self.export_chart_csv); bar2.addWidget(exp)
        clr=QPushButton('Clear history…'); clr.clicked.connect(self.clear_chart_data); bar2.addWidget(clr); v.addLayout(bar2)
        self.chart_split=QSplitter(Qt.Vertical); self.chart_split.setChildrenCollapsible(False)
        for key in ('flow','conc','temp'): self.chart_split.addWidget(self.chart_cards[key])
        v.addWidget(self.chart_split,1); self.chart_group.changed.connect(self.chart_view_changed); self.tabs.addTab(w,'Charts')
    def chart_view_changed(self):
        g=self.chart_group
        for span,b in self._span_btn.items(): b.setChecked(span==g.span)
        if g.span not in self._span_btn:
            self.span_buttons.setExclusive(False); [b.setChecked(False) for b in self._span_btn.values()]; self.span_buttons.setExclusive(True)
        self.live_btn.setText('● Live' if g.live else '❚❚ Paused – go to live'); self.live_btn.setProperty('paused',not g.live); self.live_btn.style().unpolish(self.live_btn); self.live_btn.style().polish(self.live_btn)
        self.refresh_charts()
    def _build_recipes_tab(self):
        w=QWidget(); v=QVBoxLayout(w); v.setContentsMargins(0,6,0,0); v.setSpacing(6)
        bar=QHBoxLayout(); bar.addWidget(QLabel('Recipe type')); self.recipe_type=QComboBox(); self.recipe_type.setSizeAdjustPolicy(QComboBox.AdjustToContents); self.recipe_type.addItems(['Channel flow setpoints','Gas concentration']); self.recipe_type.setToolTip('Flow setpoints: enter each channel flow. Gas concentration: enter a target and the flows are computed.'); self.recipe_type.currentIndexChanged.connect(lambda: (self.rebuild_recipe_table(), self.schedule_recipe_check())); bar.addWidget(self.recipe_type)
        bar.addWidget(QLabel('Unit')); self.conc_unit=QComboBox(); self.conc_unit.addItems(['%','ppm']); self._conc_unit_prev='%'; self.conc_unit.setToolTip('Unit of the Target column; switching converts the values'); self.conc_unit.currentTextChanged.connect(self.change_conc_unit); bar.addWidget(self.conc_unit)
        bar.addWidget(QLabel('Repeat')); self.cycles=QSpinBox(); self.cycles.setRange(1,999); self.cycles.setValue(1); self.cycles.setSuffix(' cycle(s)'); self.cycles.valueChanged.connect(self.schedule_recipe_check); bar.addWidget(self.cycles)
        self.stop_end=QCheckBox('Stop flows at end'); self.stop_end.setChecked(True); self.stop_end.setToolTip('Unchecked: the last step keeps running after the recipe ends'); bar.addWidget(self.stop_end)
        self.sequence_switch=QCheckBox('Hold carrier until premix flows'); self.sequence_switch.setChecked(True)
        self.sequence_switch.setToolTip('A controller starting from 0 has a start-up delay (about 3 s on the S300D). When checked, it is started first and\nthe other channels are reduced only once its flow arrives (max. 6 s), so the total flow does not dip and the\nconcentration never exceeds the target. Also used by Apply mixture.'); bar.addStretch(1)
        save_r=QPushButton('Save recipe…'); save_r.clicked.connect(self.save_recipe); load_r=QPushButton('Load recipe…'); load_r.clicked.connect(self.load_recipe); v.addLayout(bar)
        self.recipe_limits=wrap(muted=True); v.addWidget(self.recipe_limits)
        self.recipe_table=QTableWidget(); self.recipe_table.setSelectionBehavior(QAbstractItemView.SelectRows); self.recipe_table.verticalHeader().setVisible(False); self.recipe_table.setMinimumHeight(140); self.recipe_table.itemChanged.connect(self.schedule_recipe_check); v.addWidget(self.recipe_table,1)
        self.recipe_check=wrap(); v.addWidget(self.recipe_check)
        hb=QHBoxLayout(); add=QPushButton('+ Add step'); add.clicked.connect(self.add_recipe_step); rem=QPushButton('Remove step'); rem.setToolTip('Remove the selected step'); rem.clicked.connect(self.remove_recipe_step); pulse=QPushButton('Pulse sequence…'); pulse.setToolTip('Generate baseline / exposure / purge cycles for a list of concentrations'); pulse.clicked.connect(self.open_pulse_generator); preview=QPushButton('Preview / check…'); preview.setToolTip('Show the channel setpoints, expected concentration and total duration of every step'); preview.clicked.connect(self.preview_recipe)
        for b in (add,rem,pulse,preview): hb.addWidget(b)
        hb.addSpacing(12); hb.addWidget(QLabel('Durations ×')); self.mult=QDoubleSpinBox(); self.mult.setRange(0.001,1000); self.mult.setDecimals(3); self.mult.setValue(1); hb.addWidget(self.mult); mb=QPushButton('Apply'); mb.setToolTip('Multiply every step duration by this factor'); mb.clicked.connect(self.apply_multiplier); hb.addWidget(mb); hb.addStretch(1); v.addLayout(hb)
        rb=QHBoxLayout(); rb.addWidget(save_r); rb.addWidget(load_r); self.recipe_status=wrap('Not running'); rb.addWidget(self.recipe_status,1); self.recipe_lock_note=QLabel('Table locked while running'); self.recipe_lock_note.setObjectName('muted'); self.recipe_lock_note.setVisible(False); rb.addWidget(self.recipe_lock_note); rb.addWidget(self.sequence_switch)
        self.run_recipe=QPushButton('▶  Run recipe'); self.run_recipe.clicked.connect(self.start_recipe); self.stop_recipe=QPushButton('■  Stop recipe'); self.stop_recipe.clicked.connect(lambda:self.stop_recipe_now('Recipe stopped by user')); button_color(self.run_recipe,'start'); button_color(self.stop_recipe,'stop'); self.stop_recipe.setEnabled(False); rb.addWidget(self.run_recipe); rb.addWidget(self.stop_recipe); v.addLayout(rb)
        self._recipe_edit_widgets=[self.recipe_type,self.conc_unit,self.cycles,load_r,add,rem,pulse,self.mult,mb,self.sequence_switch]
        self.tabs.addTab(w,'Recipes'); self.rebuild_recipe_table(); self.add_recipe_step(); self.add_recipe_step(); self.set_recipe_locked(False)
    def _build_data_tab(self):
        w=QWidget(); outer=QVBoxLayout(w); outer.setContentsMargins(0,6,0,0); scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame); host=QWidget(); v=QVBoxLayout(host); scroll.setWidget(host); outer.addWidget(scroll)
        box=QGroupBox('New recording'); g=QGridLayout(box); g.setColumnStretch(1,1)
        self.exp_name=QLineEdit('Experiment'); self.exp_name.setToolTip('Used in the file name'); g.addWidget(QLabel('Experiment name'),0,0); g.addWidget(self.exp_name,0,1,1,2)
        self.exp_note=QTextEdit(); self.exp_note.setFixedHeight(60); self.exp_note.setPlaceholderText('Sample, sensor ID, cylinder, conditions…'); g.addWidget(QLabel('Note'),1,0,Qt.AlignTop); g.addWidget(self.exp_note,1,1,1,2)
        self.rec_dir=QLineEdit(str(DEFAULT_RECORD_DIR)); self.rec_dir.setToolTip('Every recording is written here continuously (CSV + JSON metadata), so data survives a crash'); browse=QPushButton('Browse…'); browse.clicked.connect(self.choose_record_dir); g.addWidget(QLabel('Autosave folder'),2,0); g.addWidget(self.rec_dir,2,1); g.addWidget(browse,2,2)
        g.addWidget(QLabel('Current file'),3,0,Qt.AlignTop); self.rec_file_label=wrap('Not recording',selectable=True); g.addWidget(self.rec_file_label,3,1,1,2)
        self.data_channels=QHBoxLayout(); g.addLayout(self.data_channels,4,0,1,3)
        hb=QHBoxLayout(); self.start_rec=QPushButton('●  Start recording'); self.stop_rec=QPushButton('■  Stop recording'); button_color(self.start_rec,'start'); button_color(self.stop_rec,'stop'); self.stop_rec.setEnabled(False); self.start_rec.clicked.connect(self.start_recording); self.stop_rec.clicked.connect(self.stop_recording); hb.addWidget(self.start_rec); hb.addWidget(self.stop_rec); hb.addStretch(); g.addLayout(hb,5,0,1,3)
        g.addWidget(wrap('Each sample (every 0.5 s) stores time, target and expected concentration, measured flows and events (step changes, starts, stops, safety stops). Use the unix_time_s column to align with spectrometer data recorded on the same computer.',muted=True),6,0,1,3); v.addWidget(box)
        lst=QGroupBox('Recordings in this session'); lv=QVBoxLayout(lst); sh=QHBoxLayout(); sh.addWidget(QLabel('Sort')); self.sort_rec=QComboBox(); self.sort_rec.addItems(['Newest first','Oldest first','Name A-Z','Name Z-A','Most samples','Fewest samples']); self.sort_rec.currentIndexChanged.connect(self.refresh_recordings); sh.addWidget(self.sort_rec); sh.addStretch(); lv.addLayout(sh)
        self.rec_table=QTableWidget(0,5); self.rec_table.setHorizontalHeaderLabels(['Name','Started','Samples','Note','Export']); self.rec_table.verticalHeader().setVisible(False); self.rec_table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.rec_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); self.rec_table.horizontalHeader().setSectionResizeMode(3,QHeaderView.Stretch); self.rec_table.setMinimumHeight(140); lv.addWidget(self.rec_table)
        v.addWidget(lst,1); self.tabs.addTab(w,'Data')
    def _build_tools_tab(self):
        w=QWidget(); outer=QVBoxLayout(w); outer.setContentsMargins(0,6,0,0); scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame); host=QWidget(); v=QVBoxLayout(host); scroll.setWidget(host); outer.addWidget(scroll)
        find=QGroupBox('Find devices on a serial port'); fv=QVBoxLayout(find)
        fv.addWidget(wrap('Use this when a controller does not connect. It tries every supported baud rate (the manufacturer documents give 9600, 19200 or 115200 as the S300 default) and lists the addresses that answer. Disconnect channels on that port first.',muted=True))
        fh=QHBoxLayout(); self.scan_port_box=QComboBox(); self.scan_port_box.setSizeAdjustPolicy(QComboBox.AdjustToContents); fh.addWidget(QLabel('Port')); fh.addWidget(self.scan_port_box,1); rp=QPushButton('Refresh'); rp.clicked.connect(self.refresh_scan_ports); fh.addWidget(rp); sb=QPushButton('Scan'); sb.clicked.connect(self.scan_devices); fh.addWidget(sb); fv.addLayout(fh)
        self.scan_table=QTableWidget(0,5); self.scan_table.setHorizontalHeaderLabels(['Baud','Address','Calibration gas','Full scale','Unit']); self.scan_table.verticalHeader().setVisible(False); self.scan_table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.scan_table.setSelectionBehavior(QAbstractItemView.SelectRows); self.scan_table.setMaximumHeight(160); self.scan_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); fv.addWidget(self.scan_table)
        ah=QHBoxLayout(); ab=QPushButton('Use selected result for the channel below'); ab.clicked.connect(self.apply_scan_result); ah.addWidget(ab); ah.addStretch(); fv.addLayout(ah); v.addWidget(find)
        dev=QGroupBox('Selected controller'); g=QGridLayout(dev); g.setColumnStretch(1,1)
        self.tools_channel=QComboBox(); self.tools_channel.currentIndexChanged.connect(self.update_tools_info); g.addWidget(QLabel('Channel'),0,0); g.addWidget(self.tools_channel,0,1,1,2)
        self.tools_info=wrap(); g.addWidget(QLabel('Device'),1,0,Qt.AlignTop); g.addWidget(self.tools_info,1,1,1,2)
        self.tools_acc=QLabel('—'); g.addWidget(QLabel('Accumulated flow'),2,0); g.addWidget(self.tools_acc,2,1)
        hb=QHBoxLayout(); read=QPushButton('Read accumulated'); read.clicked.connect(self.read_accum); clear=QPushButton('Clear accumulated…'); clear.clicked.connect(self.clear_accum); hb.addWidget(read); hb.addWidget(clear); hb.addStretch(); g.addLayout(hb,3,1,1,2)
        zero=QPushButton('Zero calibration…'); zero.setToolTip('Run only with the stop valves closed and no gas flowing'); zero.clicked.connect(self.tools_zero); g.addWidget(QLabel('Zero'),4,0); g.addWidget(zero,4,1,Qt.AlignLeft)
        g.addWidget(wrap('Only with no gas flowing (stop valves closed). Use when the reading is not zero without flow.',muted=True),5,1,1,2)
        vh=QHBoxLayout(); self.valve=QDoubleSpinBox(); self.valve.setRange(0,100); self.valve.setDecimals(2); self.valve.setSuffix(' %'); vh.addWidget(self.valve); vb=QPushButton('Apply valve opening…'); vb.clicked.connect(self.apply_valve); vh.addWidget(vb); vh.addStretch(); g.addWidget(QLabel('Valve opening'),6,0); g.addLayout(vh,6,1,1,2)
        g.addWidget(wrap('Valve mode bypasses flow control (flow depends only on pressure). For diagnostics only.',muted=True),7,1,1,2)
        factory=QPushButton('Restore factory settings…'); factory.clicked.connect(self.factory_restore); g.addWidget(factory,8,1,Qt.AlignLeft); v.addWidget(dev)
        addr=QGroupBox('Device address (MFC-E)'); av=QVBoxLayout(addr)
        steps=wrap('Every controller ships with address 1, so two controllers on one converter must get different addresses. For MFC-E: connect <b>only that controller</b> to the converter, select a channel on the same port and baud rate, read the address, enter a new one and assign it. Repeat for the next controller. S300 addresses are set with the rotary switches on the device.',rich=True); av.addWidget(steps)
        ah2=QHBoxLayout(); rd=QPushButton('Read address'); rd.clicked.connect(self.detect_isolated_address); ah2.addWidget(rd); ah2.addWidget(QLabel('New address')); self.assign_addr_spin=QSpinBox(); self.assign_addr_spin.setRange(1,247); ah2.addWidget(self.assign_addr_spin); asg=QPushButton('Assign address…'); asg.clicked.connect(self.assign_isolated_address); ah2.addWidget(asg); ah2.addStretch(); av.addLayout(ah2); v.addWidget(addr)
        v.addStretch(); self.tabs.addTab(w,'Device Tools'); self.refresh_scan_ports()
    def refresh_scan_ports(self):
        cur=self.scan_port_box.currentData(); self.scan_port_box.clear()
        for p in list_serial_ports(): self.scan_port_box.addItem(port_label(p),p.device)
        if not self.scan_port_box.count(): self.scan_port_box.addItem('No serial ports found',None)
        i=self.scan_port_box.findData(cur); self.scan_port_box.setCurrentIndex(max(0,i))
    def scan_devices(self):
        port=self.scan_port_box.currentData()
        if not port: self.status('No serial port selected. Check the USB cable and the CH340 driver.',error=True); return
        if any(c.connected and c.port==port for c in self.channels): self.status('Disconnect the channels on this port before scanning.',error=True); return
        dlg=QProgressDialog('Scanning…','Cancel',0,0,self); dlg.setWindowTitle('Find devices'); dlg.setMinimumDuration(0); dlg.show()
        def progress(text):
            dlg.setLabelText(text); QApplication.processEvents(); return not dlg.wasCanceled()
        try: found=scan_port(port,progress=progress)
        except Exception as e: dlg.close(); self.status(f'Scan failed: {e}',error=True); return
        dlg.close(); self.scan_table.setRowCount(len(found))
        for r,d in enumerate(found):
            for col,key in enumerate(['baud','address','gas','full_scale','flow_unit']): it=QTableWidgetItem(str(d[key])); it.setData(Qt.UserRole,d); self.scan_table.setItem(r,col,it)
        if found: self.scan_table.selectRow(0); self.status(f'Found {len(found)} device(s) on {port} at {found[0]["baud"]} baud')
        else: self.status(f'No device answered on {port}. Check 24 V power, the data cable and RS485 A/B wiring (S300: RS485 is an ordering option; EtherCAT units do not answer).',error=True)
    def apply_scan_result(self):
        row=self.scan_table.currentRow(); c=self.tools_selected()
        if row<0 or not c: self.status('Select a scan result and a device channel first.',error=True); return
        if c.connected: self.status('Disconnect the channel before changing its port settings.',error=True); return
        d=self.scan_table.item(row,0).data(Qt.UserRole); port=self.scan_port_box.currentData()
        c.port=port; c.baud=int(d['baud']); c.address=int(d['address'])
        for card in self.cards:
            if card.channel is c: card.refresh_ports(); card.baud.setCurrentText(str(c.baud)); card.addr.setValue(c.address)
        self.status(f'{c.name}: {port}, {c.baud} baud, address {c.address}. Choose the matching model, then Connect.')
    def update_tools_info(self):
        c=self.tools_selected()
        if not c: self.tools_info.setText('—'); return
        p=c.profile(); r=c.reading
        spec=f'{p.name}: accuracy ±{p.acc_fs*100:g}% FS' + (f' or ±{p.acc_sp*100:g}% SP, whichever is larger' if p.sp_from is None else f' up to {p.sp_from*100:g}% FS, ±{p.acc_sp*100:g}% SP above') + f'; controls from {p.min_fraction*100:g}% FS; setpoint resolution {1/p.set_scale:g}'
        live=f'Calibrated for {r.calibration_text}, full scale {fmt_sig(r.full_scale,5)} {r.flow_unit}, reading resolution {r.resolution:g} {r.flow_unit}, {fmt_sig(r.temperature,3)} °C. ' if c.connected else 'Not connected. '
        self.tools_info.setText(live+spec+(f'. {p.address_note}' if p.address_note else ''))
    def _build_log_tab(self): self.logbox=QTextEdit(); self.logbox.setReadOnly(True); self.tabs.addTab(self.logbox,'Log')
    def set_sig(self,v): self.sig_digits=v; [c.update_all() for c in self.cards]
    def fmt(self,v): return fmt_sig(v,self.sig_digits)
    def status(self,text,error=False,working=False):
        self.banner.setText(text); self.banner.setProperty('state','error' if error else 'working' if working else 'ok'); self.banner.style().unpolish(self.banner); self.banner.style().polish(self.banner); self.logbox.append(f'[{now_text()}] {text}')
    def set_dark(self,on): self.dark=bool(on); self.apply_theme(); self.refresh_charts()
    def apply_theme(self):
        # Sizes are in points so text has the same physical size on Windows (96 dpi) and macOS (72 dpi).
        if self.dark: bg,surface,alt,text,muted,border,accent=('#111827','#1f2937','#273449','#f1f5f9','#9aa8bc','#3b4a60','#60a5fa')
        else: bg,surface,alt,text,muted,border,accent=('#eef2f7','#ffffff','#f6f8fb','#1e293b','#5b6b80','#cbd5e1','#2563eb')
        palette=QPalette()
        for role,col in ((QPalette.Window,bg),(QPalette.WindowText,text),(QPalette.Base,surface),(QPalette.AlternateBase,alt),(QPalette.Text,text),(QPalette.Button,surface),(QPalette.ButtonText,text),(QPalette.ToolTipBase,surface),(QPalette.ToolTipText,text),(QPalette.PlaceholderText,muted)):
            palette.setColor(role,QColor(col))
        palette.setColor(QPalette.Highlight,QColor(accent)); palette.setColor(QPalette.HighlightedText,QColor('white'))
        self.setPalette(palette)
        chevron=(APP_DIR/'ui'/'icons'/'chevron.svg').as_posix()
        self.setStyleSheet(f"""
        QWidget {{background:{bg};color:{text};font-size:10pt;}}
        QLabel, QCheckBox {{background:transparent;}}
        QToolTip {{background:{surface};color:{text};border:1px solid {border};padding:4px;}}
        QTabWidget::pane {{border:0;}}
        QTabBar {{background:{bg};}} QTabWidget::tab-bar {{left:0;}}
        QTabBar::tab:!selected {{color:{text};}}
        QTabBar::tab {{background:transparent;padding:8px 16px;margin-right:2px;border-bottom:3px solid transparent;font-size:10.5pt;}}
        QTabBar::tab:selected {{color:{accent};border-bottom:3px solid {accent};font-weight:600;}}
        QTabBar::tab:hover {{color:{accent};}}
        QGroupBox {{background:{surface};border:1px solid {border};border-radius:8px;margin-top:14px;padding:12px 10px 10px;}}
        QGroupBox::title {{subcontrol-origin:margin;left:12px;padding:0 4px;font-weight:600;}}
        QFrame#channelCard, QFrame#chartCard {{background:{surface};border:1px solid {border};border-radius:8px;}}
        QFrame#channelCard QLabel, QFrame#chartCard QLabel, QFrame#channelCard QCheckBox, QFrame#chartCard QCheckBox {{background:transparent;}}
        QFrame#sep {{background:{border};max-height:1px;border:0;}}
        QLineEdit,QComboBox,QSpinBox,QDoubleSpinBox,QTextEdit,QTableWidget {{background:{surface};color:{text};border:1px solid {border};border-radius:4px;padding:3px 5px;selection-background-color:{accent};}}
        QLineEdit:focus,QComboBox:focus,QSpinBox:focus,QDoubleSpinBox:focus,QTextEdit:focus {{border:1px solid {accent};}}
        QLineEdit:disabled,QComboBox:disabled,QSpinBox:disabled,QDoubleSpinBox:disabled {{color:{muted};background:{alt};}}
        QLineEdit#cardName {{font-size:12pt;font-weight:600;border:1px solid transparent;background:transparent;}}
        QLineEdit#cardName:hover, QLineEdit#cardName:focus {{border:1px solid {border};background:{surface};}}
        QComboBox::drop-down {{width:22px;border-left:1px solid {border};}}
        QComboBox::down-arrow {{image:url("{chevron}");width:12px;height:8px;}}
        QTableWidget {{gridline-color:{border};alternate-background-color:{alt};}}
        QHeaderView::section {{background:{alt};color:{text};padding:5px 6px;border:0;border-bottom:1px solid {border};border-right:1px solid {border};font-weight:600;}}
        QPushButton {{background:{surface};border:1px solid {border};border-radius:5px;padding:5px 12px;}}
        QPushButton:hover {{border-color:{accent};}}
        QPushButton:pressed {{background:{alt};}}
        QPushButton:disabled {{color:{muted};border-color:{border};background:{alt};}}
        QPushButton[role="start"]:enabled {{background:#15803d;color:white;border-color:#15803d;font-weight:600;}}
        QPushButton[role="stop"]:enabled {{background:#b91c1c;color:white;border-color:#b91c1c;font-weight:600;}}
        QPushButton#stopAll {{font-size:11.5pt;padding:7px 18px;}}
        QPushButton#segment {{padding:4px 10px;border-radius:0;margin:0;}}
        QPushButton#segment:checked {{background:{accent};color:white;border-color:{accent};}}
        QPushButton#liveBtn {{color:#15803d;font-weight:600;}}
        QPushButton#liveBtn[paused="true"] {{background:#b45309;color:white;border-color:#b45309;}}
        QPushButton#legendChip {{padding:2px 8px;font-size:9pt;}}
        QProgressBar {{border:1px solid {border};border-radius:4px;background:{alt};text-align:center;min-height:16px;}}
        QProgressBar::chunk {{background:{accent};border-radius:3px;}}
        QSplitter::handle {{background:{border};}}
        QSplitter::handle:vertical {{height:5px;}} QSplitter::handle:horizontal {{width:5px;}}
        QScrollArea {{border:0;}}
        QLabel#statusBanner {{border-radius:6px;padding:4px 8px;background:{surface};border:1px solid {border};}}
        QLabel#statusBanner[state="error"] {{background:#b91c1c;color:#ffffff;border-color:#b91c1c;font-weight:600;}}
        QLabel#statusBanner[state="working"] {{background:#b45309;color:#ffffff;border-color:#b45309;}}
        QFrame#tile {{background:{surface};border:1px solid {border};border-radius:6px;}}
        QFrame#tile[kind="sim"] {{border:2px solid #7c3aed;}} QFrame#tile[kind="warn"] {{border:2px solid #b45309;}}
        QFrame#tile[kind="error"] {{border:2px solid #b91c1c;}} QFrame#tile[kind="ok"] {{border:2px solid #15803d;}} QFrame#tile[kind="flow"] {{border:2px solid {accent};}}
        QLabel#tileCaption {{color:{muted};font-size:8.5pt;}}
        QLabel#tileValue {{font-size:13pt;font-weight:700;}}
        QLabel#tileDetail {{color:{muted};font-size:8.5pt;}}
        QLabel#caption {{color:{muted};font-size:9pt;}}
        QLabel#flowValue {{font-size:18pt;font-weight:700;}}
        QLabel#sourceText {{font-weight:600;}}
        QLabel#muted {{color:{muted};font-size:9pt;}}
        QLabel#warnText {{color:#b45309;font-weight:600;}}
        QLabel#errorText {{color:#dc2626;font-weight:600;}}
        QLabel#okText {{color:#15803d;font-weight:600;}}
        """)
        if hasattr(self,'recipe_table'): self.schedule_recipe_check()
        if hasattr(self,'chart_cards'): [c.chart.update() for c in self.chart_cards.values()]
    def fit_window(self):
        scr=(self.screen() or QApplication.primaryScreen())
        if scr is None: return
        g=scr.availableGeometry(); w=min(1400,g.width()-20); h=min(900,g.height()-20)
        self.resize(max(self.minimumWidth(),w),max(self.minimumHeight(),h)); self.move(g.left()+(g.width()-self.width())//2,g.top()+(g.height()-self.height())//2)
    def add_channel(self, channel=None):
        used={c.address for c in self.channels}; addr=next((i for i in range(1,248) if i not in used),1); channel=channel or Channel(name=f'Channel {len(self.channels)+1}',address=addr,baud=9600); channel.gas_library=self.gas_library; self.channels.append(channel); card=ChannelCard(self,channel,len(self.cards)); self.cards.append(card); self.relayout_cards(); self.structure_changed()
    def remove_channel(self,card):
        if card.channel.working: self.emergency_stop_all(f'{card.channel.name} was removed while working', latch=True)
        try: card.channel.disconnect()
        except: pass
        self.channels.remove(card.channel); self.cards.remove(card); card.deleteLater(); self.relayout_cards(); self.structure_changed()
    def relayout_cards(self):
        card_width=max((card.minimumSizeHint().width() for card in self.cards),default=440)
        avail=self.channel_scroll.viewport().width() if hasattr(self,'channel_scroll') and self.channel_scroll.viewport().width()>100 else self.width()-40
        cols=max(1,min(3,avail//(card_width+12)))
        if getattr(self,'_card_cols',None)==cols and self.cards_grid.count()==len(self.cards): return
        self._card_cols=cols
        for c in self.cards: self.cards_grid.removeWidget(c)
        for i,c in enumerate(self.cards): self.cards_grid.addWidget(c,i//cols,i%cols)
        for c in range(3): self.cards_grid.setColumnStretch(c,1 if c<cols else 0)
    def resizeEvent(self,e): super().resizeEvent(e); self.relayout_cards()
    def refresh_ports(self): [c.refresh_ports() for c in self.cards]; self.status('Serial-port list refreshed')
    def auto_number_addresses(self):
        for i,c in enumerate(self.channels):
            if not c.connected: c.address=i+1
        for card in self.cards: card.addr.setValue(card.channel.address)
        self.status('Software channel addresses auto-numbered')
    def refresh_gas_library_ui(self):
        
        for channel in self.channels: channel.gas_library=self.gas_library
        self.target_editor.lib=self.gas_library; self.target_editor.refresh_library()
        cur=self.chart_gas.currentText(); self.chart_gas.blockSignals(True); self.chart_gas.clear(); self.chart_gas.addItems(sorted(self.gas_library));
        if self.chart_gas.findText(cur)<0:self.chart_gas.addItem(cur)
        self.chart_gas.setCurrentText(cur); self.chart_gas.blockSignals(False)
    def structure_changed(self): self.refresh_mixture_sources(); self.refresh_chart_selectors(); self.refresh_data_selectors(); self.refresh_tools_channels(); self.rebuild_recipe_table(preserve=True); self.schedule_recipe_check()
    def refresh_mixture_sources(self):
        old={self.mix_table.cellWidget(r,0).property('channel_id'):self.mix_table.cellWidget(r,0).isChecked() for r in range(self.mix_table.rowCount())} if self.mix_table.rowCount() else {}
        self.mix_table.setRowCount(len(self.channels))
        for r,c in enumerate(self.channels):
            chk=QCheckBox(); chk.setProperty('channel_id',id(c)); chk.setChecked(old.get(id(c),True)); chk.setToolTip('Use this channel as a source'); chk.toggled.connect(self.recalculate_mixture); self.mix_table.setCellWidget(r,0,chk); self.mix_table.setItem(r,1,QTableWidgetItem(c.name+('  (not connected)' if not c.connected else ''))); self.mix_table.setItem(r,2,QTableWidgetItem(composition_text(c.source,self.sig_digits))); self.mix_table.setItem(r,3,QTableWidgetItem('—')); self.mix_table.setItem(r,4,QTableWidgetItem('—')); self.mix_table.setItem(r,5,QTableWidgetItem('—'))
        self.recalculate_mixture()
    def selected_mix_channels(self): return [c for r,c in enumerate(self.channels) if (w:=self.mix_table.cellWidget(r,0)) and w.isChecked()]
    def mixture_total_limits(self, selected, per_unit):
        """Allowed total flow for this target: flows scale linearly with the total."""
        if any(not c.connected for c,f in zip(selected,per_unit) if f>1e-12): return None
        hi=[(c.reading.full_scale*c.cmix/f,c) for c,f in zip(selected,per_unit) if f>1e-12]
        lo=[c.profile().min_fraction*c.reading.full_scale*c.cmix/f for c,f in zip(selected,per_unit) if f>1e-12]
        if not hi: return None
        mx,limiting=min(hi,key=lambda x:x[0]); return mx,limiting,max(lo)
    def recalculate_mixture(self):
        if not hasattr(self,'mix_table'):return
        unit=next((c.reading.flow_unit for c in self.channels if c.connected),'SCCM'); self.total_flow.setSuffix(' '+unit); self.mix_limits.setText('')
        for r in range(self.mix_table.rowCount()):
            for col in (3,4,5): self.mix_table.item(r,col).setText('—')
            if r<len(self.channels): c=self.channels[r]; self.mix_table.item(r,1).setText(c.name+('' if c.connected else '  (not connected)'))
        try:
            selected=self.selected_mix_channels(); target=self.target_editor.composition(); total=self.total_flow.value()
            if (err:=flammability_error(target)): raise ValueError(err)
            per_unit=solve_source_flows([c.source for c in selected],target,1.0)
            lim=self.mixture_total_limits(selected,per_unit)
            if lim:
                mx,limiting,lo=lim
                self.mix_limits.setText(f'Allowed total flow for this target: up to {self.fmt(mx)} {unit} (limited by the maximum of {limiting.name}) · reliable from {self.fmt(lo)} {unit}')
            else: self.mix_limits.setText('Connect the source channels to see the allowed total-flow range.')
            flows=[f*total for f in per_unit]
            for channel, flow in zip(selected, flows): channel.validate_setpoint(flow)
            fmap={id(c):f for c,f in zip(selected,flows)}
            for r,c in enumerate(self.channels):
                f=fmap.get(id(c)); fs=c.reading.full_scale; self.mix_table.item(r,3).setText('—' if f is None else f'{self.fmt(f)} {c.reading.flow_unit}'); self.mix_table.item(r,4).setText('—' if f is None else f'{self.fmt(f/c.cmix)} {c.reading.flow_unit}'); self.mix_table.item(r,5).setText('—' if f is None or not fs or not c.connected else fmt_sig(100*f/c.cmix/fs,3)+'%')
            warnings=low_range_warnings(selected,flows); gas=self.chart_gas.currentText() if hasattr(self,'chart_gas') else 'H2'
            exp,err=expected_concentration(selected,flows,gas)
            self.solver_status.setText(f'✓ Achievable. {gas} = {concentration_text(target.get(gas,0))}; expected {uncertainty_text(exp,err)} from controller accuracy and setpoint resolution. Review the setpoints, then click Apply mixture.'+('\n⚠ '+'\n⚠ '.join(warnings) if warnings else '')); self.solver_status.setObjectName('warnText' if warnings else 'okText'); self.apply_mix.setEnabled(not self.fail_safe_latched); self._mix_solution=fmap
        except Exception as e:
            self.solver_status.setText('✗ '+str(e)); self.solver_status.setObjectName('errorText'); self.apply_mix.setEnabled(False); self._mix_solution={}
        self.solver_status.style().unpolish(self.solver_status); self.solver_status.style().polish(self.solver_status)
        self.invalidate_mixture()
    def invalidate_mixture(self):
        if hasattr(self,'mix_badge'): self.mixture_applied=False; self.mix_badge.set('NOT APPLIED','off')
    def apply_flows(self, pairs, label=''):
        """Send channel setpoints. With 'Hold carrier until premix flows' on, controllers that start from 0 (they have
        a start-up dead time: 2.7-2.9 s on the lab S300D) are commanded first and reductions on the other channels wait
        until those flows arrive (max. 6 s). Meanwhile the concentration can only be below target, never above, and the
        total flow does not dip."""
        self.cancel_sequence()
        prev={id(c):((c.configured_setpoint or 0.0) if c.working else 0.0) for c,_ in pairs}
        starters=[(c,f) for c,f in pairs if f>0 and prev[id(c)]<=0]
        hold_ids={id(c) for c,f in pairs if f<prev[id(c)]} if (starters and getattr(self,'sequence_switch',None) and self.sequence_switch.isChecked()) else set()
        for c,f in pairs:
            if id(c) not in hold_ids: c.configure(f); c.start()
        if not hold_ids: return
        token=object(); t0=time.monotonic(); held=[(c,f) for c,f in pairs if id(c) in hold_ids]; self._sequence=token
        self.record_event(f'Holding {", ".join(c.name for c,_ in held)} until {", ".join(c.name for c,_ in starters)} flows')
        timer=QTimer(self); timer.setInterval(100)
        def check():
            if self._sequence is not token or self.fail_safe_latched: timer.stop(); timer.deleteLater(); return
            ready=all(c.reading.raw_flow>=0.5*c.configured_setpoint/c.cmix for c,_ in starters)
            if not ready and time.monotonic()-t0<6.0: return
            timer.stop(); timer.deleteLater(); self._sequence=None
            try:
                for c,f in held: c.configure(f); c.start()
                self.record_event(f'Applied held setpoints after {time.monotonic()-t0:.1f} s'+('' if ready else ' (timeout: premix flow not detected)'))
                [card.update_all() for card in self.cards]
            except Exception as e: self.fail_safe_stop(f'Command failed: {e}')
        timer.timeout.connect(check); timer.start()
    def cancel_sequence(self): self._sequence=None
    def apply_mixture(self):
        if self.fail_safe_latched: self.status('Fail-safe stop is latched. Acknowledge before applying a mixture.',error=True); return
        try:
            if not getattr(self,'_mix_solution',{}): raise ValueError('No valid mixture solution')
            req=[c for c in self.channels if id(c) in self._mix_solution and self._mix_solution[id(c)]>1e-12]
            if any(not c.connected for c in req): raise RuntimeError('All required source channels must be connected')
            if self.recipe_running: raise RuntimeError('Stop the recipe before applying a mixture')
            for c in self.channels:
                if id(c) in self._mix_solution: c.validate_setpoint(self._mix_solution[id(c)])
            self.mix_badge.set('APPLYING…','warn')
            for c in self.channels:
                if id(c) not in self._mix_solution and c.working: c.stop()
            self.apply_flows([(c,self._mix_solution[id(c)]) for c in self.channels if id(c) in self._mix_solution and c.connected],'mixture')
            self.mixture_applied=True; self.mix_badge.set(f'APPLIED {now_text()}','flow'); self.status('Mixture applied successfully'); self.record_event('Mixture applied: '+composition_text(self.target_editor.composition(),self.sig_digits)); self.update_summary(); [card.update_all() for card in self.cards]
        except Exception as e:
            self.emergency_stop_all(f'Mixture apply failed: {e}', latch=True)
    def refresh_chart_selectors(self): self.refresh_charts()
    def refresh_data_selectors(self):
        while self.data_channels.count():
            item=self.data_channels.takeAt(0); w=item.widget();
            if w:w.deleteLater()
        self._data_check_widgets=[]
        self.data_channels.addWidget(QLabel('Record channels:'))
        for c in self.channels:
            chk=QCheckBox(c.name); chk.setChecked(True); chk.setProperty('channel_id',id(c)); self.data_channels.addWidget(chk); self._data_check_widgets.append(chk)
    def refresh_tools_channels(self):
        if not hasattr(self,'tools_info'): return
        cur=self.tools_channel.currentData() if self.tools_channel.count() else None; self.tools_channel.clear()
        for c in self.channels:self.tools_channel.addItem(c.name,id(c))
        i=self.tools_channel.findData(cur); self.tools_channel.setCurrentIndex(max(0,i)); self.update_tools_info()
    def selected_chart_channels(self): return list(self.channels)
    def poll_all(self):
        if self._closing:return
        ts=datetime.now().timestamp(); row={'t':ts}
        for c in list(self.channels):
            if not c.connected: continue
            try:
                c.poll(); row[id(c)]={'raw':c.reading.raw_flow,'corrected':c.corrected_flow,'temp':c.reading.temperature,'accum':c.reading.accumulated,'valve':c.reading.valve}
            except Exception as e:
                c.last_error=str(e)
                # First detected communication failure triggers a latched stop immediately.
                self.fail_safe_stop(f'Communication lost with {c.name}: {e}', c); break
        for c in list(self.channels):
            if (dt:=c.step_arrival()) is not None: self.record_event(f'{c.name} flow reached the middle of its change {dt:.1f} s after the command')
            if (msg:=c.check_overflow()): self.fail_safe_stop('Flow far above setpoint: '+msg); break
            if (msg:=c.check_no_flow()): self.fail_safe_stop(msg); break
            if (msg:=c.check_tracking()): self.status('Flow warning: '+msg,error=True); self.record_event('WARNING: '+msg)
        self._finish_row(row)
        self.chart_data.append(row)
        if len(self.chart_data)>50000:self.chart_data=self.chart_data[-50000:]
        if self.active_recording is not None:self.capture_recording(row)
        [card.update_all() for card in self.cards]; self.update_summary()
    def _finish_row(self,row):
        sources=[(c.source,c.corrected_flow) for c in self.channels if c.connected]
        row['composition']=outlet_composition(sources); row['total']=sum(c.corrected_flow for c in self.channels if c.connected); row['target']=self.target_editor.composition() if self.mixture_applied else self.current_recipe_target()
        gas=self.chart_gas.currentText() if hasattr(self,'chart_gas') else 'H2'; flows=[c.configured_setpoint if c.working and c.configured_setpoint else 0.0 for c in self.channels]
        exp,err=expected_concentration(self.channels,flows,gas) if any(flows) else (None,None)
        row['expected']={gas:(exp,err or 0.0)} if exp is not None else {}
        return row
    def _state_row(self):
        row={'t':datetime.now().timestamp()}
        for c in self.channels:
            if c.connected: row[id(c)]={'raw':c.reading.raw_flow,'corrected':c.corrected_flow,'temp':c.reading.temperature,'accum':c.reading.accumulated,'valve':c.reading.valve}
        return self._finish_row(row)
    def record_event(self,text):
        """Write a timestamped event row (setpoint change, step start, fail-safe) to the autosaved recording."""
        if self._record_stream is None:return
        try:self._write_record_row(self._state_row(),text)
        except Exception as e:self.logbox.append(f'[{now_text()}] Recording event could not be written: {e}')
    def update_summary(self):
        if not hasattr(self,'summary') or not hasattr(self,'chart_gas'):return
        if hasattr(self,'_recipe_edit_widgets'): self.set_recipe_locked(self.recipe_running)
        if hasattr(self,'tools_info') and self.tabs.currentWidget() is self.tabs.widget(self.tabs.count()-2): self.update_tools_info()
        T=self.summary.tiles; gas=self.chart_gas.currentText(); last=self.chart_data[-1] if self.chart_data else None
        try:target=self.target_editor.composition() if self.mixture_applied else self.current_recipe_target()
        except ValueError:target=None
        outlet=(last or {}).get('composition') or {}; unit=next((c.reading.flow_unit for c in self.channels if c.connected),'SCCM')
        conn=[c for c in self.channels if c.connected]; sims=[c for c in conn if c.port=='Simulator']
        if not conn: T['mode'].set('No device','connect a channel','')
        elif len(sims)==len(conn): T['mode'].set('SIMULATOR','no real gas flows','sim')
        elif sims: T['mode'].set('MIXED','some simulated','warn')
        else: T['mode'].set('HARDWARE',f'{len(conn)} connected','ok')
        flows=[c.configured_setpoint if c.working and c.configured_setpoint else 0.0 for c in self.channels]
        exp,err=expected_concentration(self.channels,flows,gas) if any(flows) else (None,None)
        src='mixture' if self.mixture_applied else 'recipe' if self.recipe_running else ''
        T['target'].set(concentration_text(target.get(gas,0.0)) if target is not None else '—',f'{gas} · set by {src}' if src else f'{gas} · none active','')
        rel=(err/exp if exp and err else 0)
        T['expected'].set(concentration_text(exp) if exp is not None else '—',(f'± {concentration_text(err)}'+(f' ({rel*100:.2g}%)' if exp else '')) if exp is not None else 'from setpoints','warn' if rel>MAX_REL_UNCERTAINTY else '')
        T['measured'].set(concentration_text(outlet.get(gas,0.0)) if outlet else '—','from measured flows','')
        T['total'].set(f'{fmt_sig((last or {}).get("total",0),self.sig_digits)} {unit}',f'{sum(1 for c in self.channels if c.working)} flowing','')
        st=self.recipe_state
        if self.recipe_running and st and 'step_end' in st:
            now=time.monotonic(); T['recipe'].set(f"Step {st['step']+1}/{len(st['steps'])} · {fmt_duration(st['step_end']-now)} left",f"cycle {st['cycle']+1}/{st['cycles']} · {fmt_duration(st['t0']+st['total']-now)} left in total",'flow')
        else: T['recipe'].set('Not running','','')
        if self.active_recording is not None: T['rec'].set(f"● REC {len(self.active_recording['samples'])}",'autosaving','error')
        else: T['rec'].set('Off','Data tab','')
    def fail_safe_stop(self,reason,failed_channel=None):
        self.cancel_sequence()
        if self._failsafe_running:return
        self._failsafe_running=True
        try:
            self.fail_safe_latched=True; self.recipe_status.setText('Aborted — fail-safe stop'); self.apply_mix.setEnabled(False); self.recipe_running=False; self.recipe_state=None; self.invalidate_mixture()
            if hasattr(self,'recipe_timer'): self.recipe_timer.stop()
            results=[]
            # Try the failed channel first while the transport may still be partially usable, then every other channel.
            ordered=[]
            if failed_channel in self.channels: ordered.append(failed_channel)
            ordered += [c for c in self.channels if c is not failed_channel]
            for c in ordered:
                if c.connected or c.device:
                    ok=c.emergency_stop(); results.append((c.name,ok))
            if failed_channel:
                try: failed_channel.disconnect()
                except: failed_channel.connected=False
            self.failsafe_label.set('SAFETY STOP ACTIVE','error'); self.ack_btn.setVisible(True)
            unconfirmed=[n for n,ok in results if not ok]
            detail=f'SAFETY STOP: {reason}. All reachable channels were commanded to 0.'
            if unconfirmed: detail += ' Stop could not be confirmed for: '+', '.join(unconfirmed)+'.'
            self.status(detail,error=True); self.record_event(detail.strip()); [card.update_all() for card in self.cards]; self.update_summary()
        finally:self._failsafe_running=False
    def emergency_stop_all(self,reason='Stop all',latch=False):
        self.cancel_sequence()
        if latch:return self.fail_safe_stop(reason)
        results=[]
        for c in self.channels:
            if c.connected or c.device: results.append((c.name,c.emergency_stop()))
        self.recipe_running=False; self.recipe_state=None; self.invalidate_mixture();
        if hasattr(self,'recipe_timer'):self.recipe_timer.stop()
        bad=[n for n,ok in results if not ok]
        if bad: self.fail_safe_stop(reason + '; stop unconfirmed: ' + ', '.join(bad)); return
        self.status(reason + ('' if not bad else '; stop unconfirmed: '+', '.join(bad)), error=bool(bad)); self.record_event(reason); [card.update_all() for card in self.cards]; self.update_summary()
    def ask_ack_failsafe(self):
        if QMessageBox.question(self,'Acknowledge safety stop','Have you found and fixed the cause shown in the message bar and the Log tab?\n\nAcknowledging does NOT restart any flow; it only allows you to start flows again.')==QMessageBox.Yes: self.ack_failsafe()
    def ack_failsafe(self):
        # Require no currently connected channel to have a pending communication error.
        self.fail_safe_latched=False; self.failsafe_label.set('SAFETY OK','ok'); self.ack_btn.setVisible(False); self.status('Safety stop acknowledged. Outputs stay at 0; reconnect any disconnected device before restarting.'); self.update_summary(); [card.update_all() for card in self.cards]; self.recalculate_mixture()
    def chart_rows(self):
        """Rows inside the visible time span (plus one span on each side for smooth panning)."""
        data=self.chart_data
        if not data: self.chart_group.set_data_range(None,None); return []
        self.chart_group.set_data_range(data[0]['t'],data[-1]['t']); view=self.chart_group.view()
        if not view or self.chart_group.span is None: return data
        from bisect import bisect_left
        ts=[r['t'] for r in data]; width=view[1]-view[0]
        return data[bisect_left(ts,view[0]-width):bisect_left(ts,view[1]+width)+1]
    def refresh_charts(self):
        if not hasattr(self,'chart_cards'): return
        rows=self.chart_rows(); unit=next((c.reading.flow_unit for c in self.channels if c.connected),'SCCM')
        flow=[]
        for i,c in enumerate(self.channels):
            flow.append({'name':c.name,'color':SERIES_COLORS[i%len(SERIES_COLORS)],'points':[(r['t'],r[id(c)]['corrected']) for r in rows if id(c) in r]})
        flow.append({'name':'Total','desc':'Sum of all channel flows','color':'#475569','dashed':True,'points':[(r['t'],r.get('total',0.0)) for r in rows]})
        cards=self.chart_cards; cards['flow'].chart.unit=f'Flow ({unit})'; cards['flow'].set_series(flow)
        gas=self.chart_gas.currentText(); cu=self.chart_unit.currentText(); f=percent_to_ppm(1) if cu=='ppm' else 1.0; nan=float('nan')
        def exp_of(r): return (r.get('expected') or {}).get(gas)
        measured=[(r['t'],(r.get('composition') or {}).get(gas,0.0)*f if r.get('composition') else nan) for r in rows]
        target=[(r['t'],(r['target'].get(gas,0.0)*f) if r.get('target') is not None else nan) for r in rows]
        expected=[(r['t'],exp_of(r)[0]*f if exp_of(r) else nan) for r in rows]
        band=[(r['t'],(exp_of(r)[0]-exp_of(r)[1])*f if exp_of(r) else nan,(exp_of(r)[0]+exp_of(r)[1])*f if exp_of(r) else nan) for r in rows]
        cards['conc'].chart.unit=f'{gas} ({cu})'; cards['conc'].title.setText(f'<b>{gas} concentration</b>'); cards['conc'].title.setToolTip(f'{gas} concentration at the outlet (gas reaching the sensor)')
        cards['conc'].set_series([{'name':'Expected ±','desc':'Expected from the running setpoints; shaded band = ± controller accuracy','color':'#9333ea','kind':'step','points':expected,'band':band},
                                  {'name':'Measured','desc':'Calculated from the measured flows of all channels','color':'#2563eb','points':measured},
                                  {'name':'Target','desc':'Concentration requested by the mixture or recipe','color':'#16a34a','kind':'step','dashed':True,'points':target}])
        cards['temp'].set_series([{'name':c.name,'color':SERIES_COLORS[i%len(SERIES_COLORS)],'points':[(r['t'],r[id(c)]['temp']) for r in rows if id(c) in r]} for i,c in enumerate(self.channels)])
    def reset_charts(self):
        self.chart_group.go_live()
        for card in self.chart_cards.values(): card.chart.set_auto(True)
        self.status('Charts returned to live view with automatic scale')
    def clear_chart_data(self):
        if self.chart_data and QMessageBox.question(self,'Clear chart history','Delete the chart history shown on screen?\n\nRecordings (Data tab) are not affected.')!=QMessageBox.Yes: return
        self.chart_data.clear(); self.refresh_charts(); self.status('Chart history cleared')
    def export_chart_csv(self):
        rows=self.chart_rows()
        view=self.chart_group.view()
        if view and self.chart_group.span is not None: rows=[r for r in rows if view[0]<=r['t']<=view[1]]
        if not rows: self.status('No chart data to export yet.',error=True); return
        path,_=QFileDialog.getSaveFileName(self,'Export chart data','chart_data.csv','CSV (*.csv)')
        if not path:return
        gas=self.chart_gas.currentText()
        with open(path,'w',newline='',encoding='utf-8-sig') as f:
            wr=csv.writer(f); wr.writerow(['timestamp','unix_time_s']+[f'{c.name} flow ({c.reading.flow_unit})' for c in self.channels]+['total flow',f'measured {gas} (ppm)',f'target {gas} (ppm)',f'expected {gas} (ppm)',f'expected {gas} uncertainty (ppm)'])
            for r in rows:
                e=(r.get('expected') or {}).get(gas)
                wr.writerow([datetime.fromtimestamp(r['t']).isoformat(timespec='milliseconds'),f"{r['t']:.3f}"]+[r.get(id(c),{}).get('corrected','') for c in self.channels]+[r.get('total',''),
                    percent_to_ppm(r['composition'].get(gas,0.0)) if r.get('composition') else '', percent_to_ppm(r['target'].get(gas,0.0)) if r.get('target') is not None else '',
                    percent_to_ppm(e[0]) if e else '', percent_to_ppm(e[1]) if e else ''])
        self.status(f'Chart data exported: {path}')
    def rebuild_recipe_table(self,preserve=False):
        if not hasattr(self,'recipe_table'):return
        old=[]
        if preserve and self.recipe_table.columnCount():
            for r in range(self.recipe_table.rowCount()):old.append([self.recipe_table.item(r,c).text() if self.recipe_table.item(r,c) else '' for c in range(self.recipe_table.columnCount())])
        if self.recipe_type.currentIndex()==0:
            headers=['Step','Duration (s)']+[f'{c.name} ({c.reading.flow_unit})' for c in self.channels]+['Note']
        else:
            unit=next((c.reading.flow_unit for c in self.channels if c.connected),'SCCM')
            headers=['Step','Duration (s)','Target gas',f'Target ({self.conc_unit.currentText()})','Balance gas (* = any)',f'Total flow ({unit})','Note']
        self.recipe_table.blockSignals(True); self.recipe_table.setColumnCount(len(headers)); self.recipe_table.setHorizontalHeaderLabels(headers); self.recipe_table.blockSignals(False); hh=self.recipe_table.horizontalHeader(); hh.setSectionResizeMode(QHeaderView.ResizeToContents); hh.setSectionResizeMode(len(headers)-1,QHeaderView.Stretch)
        if not preserve:self.recipe_table.setRowCount(0)
        elif old:
            self.recipe_table.setRowCount(len(old))
            for r,row in enumerate(old):
                for c in range(min(len(row),len(headers))):self.recipe_table.setItem(r,c,QTableWidgetItem(row[c]))
            self.renumber_steps()
    def add_recipe_step(self):
        r=self.recipe_table.rowCount(); self.recipe_table.insertRow(r); vals=['', '60']
        if self.recipe_type.currentIndex()==0: vals += ['0']*len(self.channels)+['']
        else: vals += ['H2','10000' if self.conc_unit.currentText()=='ppm' else '1','N2','100','']
        for c,v in enumerate(vals):self.recipe_table.setItem(r,c,QTableWidgetItem(v))
        self.renumber_steps()
    def remove_recipe_step(self):
        r=self.recipe_table.currentRow();
        if r>=0:self.recipe_table.removeRow(r); self.renumber_steps()
    def renumber_steps(self):
        for r in range(self.recipe_table.rowCount()):
            it=QTableWidgetItem(str(r+1)); it.setFlags(it.flags() & ~Qt.ItemIsEditable); self.recipe_table.setItem(r,0,it)
    def apply_multiplier(self):
        m=self.mult.value()
        for r in range(self.recipe_table.rowCount()):
            try:v=float(self.recipe_table.item(r,1).text()); self.recipe_table.item(r,1).setText(self.fmt(v*m))
            except:pass
        self.status(f'Recipe durations multiplied by {self.fmt(m)}×')
    def save_recipe(self):
        path,_=QFileDialog.getSaveFileName(self,'Save recipe','recipe.json','Recipe JSON (*.json)')
        if not path:return
        data={'recipe_type':self.recipe_type.currentText(),'conc_unit':self.conc_unit.currentText(),'rows':self.recipe_rows_to_json(),'cycles':self.cycles.value(),'stop_end':self.stop_end.isChecked()}
        with open(path,'w',encoding='utf-8') as f:json.dump(data,f,indent=2)
        self.status(f'Recipe saved: {path}')
    def load_recipe(self):
        path,_=QFileDialog.getOpenFileName(self,'Load recipe','','Recipe JSON (*.json)')
        if not path:return
        try:
            with open(path,encoding='utf-8') as f:d=json.load(f)
            typ=d.get('recipe_type','Channel flow setpoints'); self.set_conc_unit(d.get('conc_unit','%')); idx=self.recipe_type.findText(typ); self.recipe_type.setCurrentIndex(max(0,idx)); self.rebuild_recipe_table(); rows=d.get('rows')
            if rows is None and 'steps' in d:
                # Compact concentration format: a list of 'steps' with named fields (examples/recipe_concentration_h2.json).
                self.set_conc_unit('%'); self.recipe_type.setCurrentText('Gas concentration'); self.rebuild_recipe_table(); rows=[]
                for i,st in enumerate(d['steps'],1): rows.append([str(i),str(st.get('duration_s',60)),str(st.get('target_gas','H2')),str(st.get('target_percent',0)),str(st.get('balance_gas','N2')),str(st.get('total_corrected_flow',100)),str(st.get('note',''))])
            self.recipe_table.setRowCount(len(rows or []))
            for r,row in enumerate(rows or []):
                for c,val in enumerate(row[:self.recipe_table.columnCount()]):self.recipe_table.setItem(r,c,QTableWidgetItem(str(val)))
            self.renumber_steps(); self.cycles.setValue(int(d.get('cycles',1))); self.stop_end.setChecked(bool(d.get('stop_end',True))); self.status(f'Recipe loaded: {path}')
        except Exception as e:self.status(f'Recipe load failed: {e}',error=True)
    def set_conc_unit(self,unit):
        self.conc_unit.blockSignals(True); self.conc_unit.setCurrentText(unit if unit in ('%','ppm') else '%'); self._conc_unit_prev=self.conc_unit.currentText(); self.conc_unit.blockSignals(False)
    def change_conc_unit(self,unit):
        prev,self._conc_unit_prev=self._conc_unit_prev,unit
        if prev==unit:return
        if self.recipe_type.currentIndex()==1:
            factor=percent_to_ppm(1) if unit=='ppm' else ppm_to_percent(1)
            for r in range(self.recipe_table.rowCount()):
                it=self.recipe_table.item(r,3)
                try:it.setText(fmt_sig(float(it.text())*factor,9))
                except Exception:pass
        self.rebuild_recipe_table(preserve=True); self.status(f'Recipe concentrations shown in {unit}')
    def load_recipe_rows(self,rows):
        self.recipe_table.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for c,val in enumerate(row[:self.recipe_table.columnCount()]):self.recipe_table.setItem(r,c,QTableWidgetItem(str(val)))
        self.renumber_steps()
    def open_pulse_generator(self):
        d=QDialog(self); d.setWindowTitle('Pulse sequence generator'); d.setMinimumWidth(520); v=QVBoxLayout(d); f=QFormLayout(); unit=self.conc_unit.currentText()
        hint=QLabel('Creates a baseline step, then exposure/purge pulses for every concentration, as in a sensor calibration or limit-of-detection run. Balance "*" means any remainder (for example a premix diluted with synthetic air).'); hint.setWordWrap(True); v.addWidget(hint)
        gas=QComboBox(); gas.setEditable(True); gas.addItems(sorted(self.gas_library)); gas.setCurrentText('H2')
        bal=QComboBox(); bal.setEditable(True); bal.addItems(['*']+sorted(self.gas_library)); bal.setCurrentText('N2')
        concs=QLineEdit('10000, 5000, 1000, 500, 100' if unit=='ppm' else '1, 0.5, 0.1, 0.05, 0.01'); concs.setToolTip('Comma-separated list, applied in this order')
        def spin(val,maximum=86400,dec=1):
            w=QDoubleSpinBox(); w.setRange(0,maximum); w.setDecimals(dec); w.setValue(val); return w
        repeats=QSpinBox(); repeats.setRange(1,999); repeats.setValue(3)
        baseline=spin(300); exposure=spin(60); purge=spin(60); final=spin(300); total=spin(self.total_flow.value() or 100,1e9,3)
        replace=QCheckBox('Replace existing steps'); replace.setChecked(True)
        for label,w in [('Target gas',gas),('Balance gas',bal),(f'Concentrations ({unit})',concs),('Pulses per concentration',repeats),('Initial baseline (s)',baseline),('Exposure (s)',exposure),('Purge after each pulse (s)',purge),('Extra final purge (s)',final),('Total corrected flow',total),('',replace)]: f.addRow(label,w)
        v.addLayout(f); info=QLabel(); v.addWidget(info); lim=wrap(muted=True); v.addWidget(lim)
        def values(): return [float(x) for x in concs.text().replace(';',',').split(',') if x.strip()]
        flow_unit=next((c.reading.flow_unit for c in self.channels if c.connected),'SCCM'); total.setSuffix(' '+flow_unit)
        def update():
            g=gas.currentText().strip(); b=bal.currentText().strip()
            lim.setText(limits_text(concentration_limits(self.channels,g,total.value(),None if b.lower() in ANY_BALANCE else b),g,total.value(),flow_unit) if g in self.gas_library else '')
            try: vals=values(); n=len(vals)*repeats.value(); dur=baseline.value()+n*(exposure.value()+purge.value())+final.value(); info.setText(f'{n} pulses, total duration {fmt_duration(dur)}'); return True
            except ValueError: info.setText('Enter numbers separated by commas'); return False
        for w in (concs,): w.textChanged.connect(update)
        for w in (repeats,baseline,exposure,purge,final,total): w.valueChanged.connect(update)
        gas.currentTextChanged.connect(update); bal.currentTextChanged.connect(update)
        update(); bb=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel); bb.accepted.connect(d.accept); bb.rejected.connect(d.reject); v.addWidget(bb)
        if d.exec()!=QDialog.Accepted or not update(): return
        if self.recipe_type.currentIndex()!=1: self.recipe_type.setCurrentIndex(1)
        rows=pulse_sequence_rows(gas.currentText().strip(),bal.currentText().strip(),values(),repeats.value(),baseline.value(),exposure.value(),purge.value(),final.value(),total.value(),unit)
        if not replace.isChecked(): rows=self.recipe_rows_to_json()+rows
        self.load_recipe_rows(rows); self.status(f'Pulse sequence generated: {len(rows)} steps')
    def preview_recipe(self):
        try: steps=self.parse_recipe()
        except Exception as e: self.status(f'Recipe check failed: {e}',error=True); return
        gas=self.chart_gas.currentText(); cycles=self.cycles.value(); unit=self.channels[0].reading.flow_unit if self.channels else ''
        d=QDialog(self); d.setWindowTitle('Recipe preview'); d.resize(1000,520); v=QVBoxLayout(d)
        headers=['Step','Duration','Starts at',f'Expected {gas} (± accuracy)']+[f'{c.name} ({unit})' for c in self.channels]+['Note','Warnings']
        t=QTableWidget(len(steps),len(headers)); t.setHorizontalHeaderLabels(headers); t.setEditTriggers(QAbstractItemView.NoEditTriggers); t.verticalHeader().setVisible(False); start=0.0
        for r,st in enumerate(steps):
            exp,err=expected_concentration(self.channels,st['flows'],gas)
            cells=[str(r+1),fmt_duration(st['duration']),fmt_duration(start),uncertainty_text(exp,err)]
            cells+=[self.fmt(f)+(f'  ({fmt_sig(100*f/c.cmix/c.reading.full_scale,3)}% FS)' if f and c.reading.full_scale else '') for c,f in zip(self.channels,st['flows'])]
            cells+=[st.get('note',''),'; '.join(st['warnings'])]
            for col,text in enumerate(cells): it=QTableWidgetItem(text); it.setToolTip(text); t.setItem(r,col,it)
            if st['warnings']: t.item(r,len(cells)-1).setForeground(QColor('#d9534f'))
            start+=st['duration']
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); t.horizontalHeader().setSectionResizeMode(len(headers)-1,QHeaderView.Stretch); v.addWidget(t)
        n_warn=sum(1 for st in steps if st['warnings'])
        v.addWidget(QLabel(f'One cycle: {fmt_duration(start)} · {cycles} cycle(s): {fmt_duration(start*cycles)} · '+(f'⚠ {n_warn} step(s) have low-range setpoints' if n_warn else 'All setpoints are within the reliable control range')))
        bb=QDialogButtonBox(QDialogButtonBox.Close); bb.rejected.connect(d.reject); v.addWidget(bb); d.exec()
    def parse_recipe_row(self,r):
        """Parse and check one recipe row; raises ValueError('...') without the step prefix."""
        cell=lambda c:(self.recipe_table.item(r,c).text().strip() if self.recipe_table.item(r,c) else '')
        def num(c,what):
            try: v=float(cell(c).replace(',',''))
            except ValueError: raise ValueError(f'{what} must be a number') from None
            if not math.isfinite(v): raise ValueError(f'{what} must be a finite number')
            return v
        dur=num(1,'duration')
        if dur<0 or dur>2147483: raise ValueError('duration cannot be negative')
        if self.recipe_type.currentIndex()==0:
            flows=[num(2+i,f'{c.name} flow') for i,c in enumerate(self.channels)]; note=cell(2+len(self.channels)); step={'duration':dur,'flows':flows,'note':note}
        else:
            gas=cell(2); pct=num(3,'concentration'); bal=cell(4); total=num(5,'total flow'); note=cell(6)
            if gas not in self.gas_library: raise ValueError(f'unknown target gas "{gas}"')
            if self.conc_unit.currentText()=='ppm': pct=ppm_to_percent(pct)
            if not 0<=pct<=100: raise ValueError('concentration must be between 0 and 100% (1,000,000 ppm)')
            if total<0: raise ValueError('total flow cannot be negative')
            if bal.lower() in ANY_BALANCE:
                target={gas:pct}; flows=solve_source_flows([c.source for c in self.channels],target,total,constrained_gases=[gas])
            else:
                if bal not in self.gas_library: raise ValueError(f'unknown balance gas "{bal}" (use * for any remainder)')
                if gas==bal:raise ValueError('target and balance gases must differ')
                target=normalize_composition({gas:pct,bal:100-pct}); flows=solve_source_flows([c.source for c in self.channels],target,total)
            step={'duration':dur,'flows':flows,'target':target,'note':note}
        for channel, flow in zip(self.channels, step['flows']): channel.validate_setpoint(flow)
        if (err:=flammability_error(outlet_composition([(c.source,f) for c,f in zip(self.channels,step['flows'])]))): raise ValueError(err)
        step['warnings']=low_range_warnings(self.channels,step['flows'])
        gas=self.chart_gas.currentText(); exp,err=expected_concentration(self.channels,step['flows'],gas)
        if exp and err and err/exp>MAX_REL_UNCERTAINTY: step['warnings'].append(f'expected {gas} {uncertainty_text(exp,err)} exceeds ±{MAX_REL_UNCERTAINTY*100:g}% (run the H2 controller higher in its range)')
        return step
    def parse_recipe(self):
        steps=[]
        for r in range(self.recipe_table.rowCount()):
            try: steps.append(self.parse_recipe_row(r))
            except ValueError as e: raise ValueError(f'Step {r+1}: {e}') from e
        return steps
    def schedule_recipe_check(self,*_):
        if not hasattr(self,'_recipe_check_timer'):
            self._recipe_check_timer=QTimer(self); self._recipe_check_timer.setSingleShot(True); self._recipe_check_timer.timeout.connect(self.validate_recipe_table)
        self._recipe_check_timer.start(350)
    def validate_recipe_table(self):
        """Colour each row: red = cannot run (reason in tooltip), amber = runs with a warning."""
        if not hasattr(self,'recipe_check'): return
        t=self.recipe_table; errors=[]; warns=0; total=0.0
        bad=QColor('#fecaca') if not self.dark else QColor('#7f1d1d'); amber=QColor('#fde68a') if not self.dark else QColor('#78350f')
        t.blockSignals(True)
        for r in range(t.rowCount()):
            try: st=self.parse_recipe_row(r); msg='; '.join(st['warnings']); color=amber if st['warnings'] else None; total+=st['duration']; warns+=bool(st['warnings'])
            except ValueError as e: msg=str(e); color=bad; errors.append(f'Step {r+1}: {e}')
            for c in range(t.columnCount()):
                it=t.item(r,c)
                if it is None: it=QTableWidgetItem(''); t.setItem(r,c,it)
                it.setBackground(color if color else QColor(0,0,0,0)); it.setToolTip(msg)
        t.blockSignals(False)
        if errors: self.recipe_check.setText('✗ '+errors[0]+(f'  (+{len(errors)-1} more red rows)' if len(errors)>1 else '')); self.recipe_check.setObjectName('errorText')
        elif t.rowCount()==0: self.recipe_check.setText('Add steps or use Pulse sequence…'); self.recipe_check.setObjectName('muted')
        else: self.recipe_check.setText(f'✓ {t.rowCount()} steps valid · one cycle {fmt_duration(total)} · {self.cycles.value()} cycle(s) {fmt_duration(total*self.cycles.value())}'+(f' · ⚠ {warns} step(s) with warnings (amber, hover for details)' if warns else '')); self.recipe_check.setObjectName('warnText' if warns else 'okText')
        self.recipe_check.style().unpolish(self.recipe_check); self.recipe_check.style().polish(self.recipe_check)
        self.update_recipe_limits()
    def update_recipe_limits(self):
        if not hasattr(self,'recipe_limits'): return
        if self.recipe_type.currentIndex()!=1: self.recipe_limits.setText('Flow values are per channel in the channel\'s flow unit; each column cannot exceed that controller\'s maximum (see the Channels tab).'); return
        t=self.recipe_table; cell=lambda r,c:(t.item(r,c).text().strip() if t.item(r,c) else '')
        seen=[]
        for r in range(t.rowCount()):
            try: key=(cell(r,2),cell(r,4),float(cell(r,5)))
            except ValueError: continue
            if key not in seen and key[0] in self.gas_library: seen.append(key)
        unit=next((c.reading.flow_unit for c in self.channels if c.connected),'SCCM')
        lines=[limits_text(concentration_limits(self.channels,g,tot,None if b.lower() in ANY_BALANCE else b),g,tot,unit) for g,b,tot in seen[:3]]
        self.recipe_limits.setText('\n'.join(lines) if lines else '')
    def set_recipe_locked(self,locked):
        if getattr(self,'_recipe_locked',None)==locked: return
        self._recipe_locked=locked
        self.recipe_table.setEditTriggers(QAbstractItemView.NoEditTriggers if locked else QAbstractItemView.DoubleClicked|QAbstractItemView.EditKeyPressed|QAbstractItemView.AnyKeyPressed)
        for w in self._recipe_edit_widgets: w.setEnabled(not locked)
        self.run_recipe.setEnabled(not locked); self.stop_recipe.setEnabled(locked)
        self.recipe_lock_note.setVisible(locked)
    def start_recipe(self):
        if self.recipe_running: return
        if self.fail_safe_latched:self.status('Fail-safe stop is latched. Acknowledge before running a recipe.',error=True);return
        try:
            steps=self.parse_recipe();
            if not steps:raise ValueError('Recipe has no steps')
            if any(not c.connected for c in self.channels):raise RuntimeError('All recipe channels must be connected')
            warnings=[f'Step {i}: {w}' for i,st in enumerate(steps,1) for w in st['warnings']]
            if warnings and QMessageBox.question(self,'Check before running','Some steps have warnings (low controller range or large concentration uncertainty):\n\n'+'\n'.join(warnings[:12])+('\n…' if len(warnings)>12 else '')+'\n\nThe delivered concentration may differ from the target. Run anyway?')!=QMessageBox.Yes: self.status('Recipe not started: low-range setpoints',error=True); return
            cycles=self.cycles.value(); total=sum(st['duration'] for st in steps)*cycles
            self.recipe_running=True; self.recipe_state={'steps':steps,'step':0,'cycle':0,'cycles':cycles,'t0':time.monotonic(),'planned':0.0,'total':total}; self.record_event(f'Recipe started ({len(steps)} steps x {cycles} cycles, {fmt_duration(total)})'); self.recipe_timer=QTimer(self); self.recipe_timer.setTimerType(Qt.PreciseTimer); self.recipe_timer.setSingleShot(True); self.recipe_timer.timeout.connect(self.advance_recipe); self.run_recipe_step()
        except Exception as e:self.status(f'Recipe cannot start: {e}',error=True)
    def run_recipe_step(self):
        if not self.recipe_running:return
        st=self.recipe_state; step=st['steps'][st['step']]
        self.set_recipe_locked(True); self.recipe_table.selectRow(st['step'])
        # Deadlines are measured from the recipe start so command and polling delays do not accumulate.
        st['step_end']=st['t0']+st['planned']+step['duration']
        try:
            self.apply_flows(list(zip(self.channels,step['flows'])),'recipe')
            self.invalidate_mixture(); self.recipe_status.setText(f"Running Step {st['step']+1}/{len(st['steps'])}, Cycle {st['cycle']+1}/{st['cycles']}: {step.get('note','')}"); self.status(self.recipe_status.text()); self.record_event(self.recipe_status.text()); self.recipe_timer.start(max(1,int((st['step_end']-time.monotonic())*1000))); [card.update_all() for card in self.cards]; self.update_summary()
        except Exception as e:self.fail_safe_stop(f'Recipe command failed: {e}')
    def advance_recipe(self):
        if not self.recipe_running or self.recipe_state is None: return
        st=self.recipe_state; st['planned']+=st['steps'][st['step']]['duration']; st['step']+=1
        if st['step']>=len(st['steps']):
            st['step']=0; st['cycle']+=1
            if st['cycle']>=st['cycles']:
                self.recipe_running=False; self.recipe_status.setText('Recipe complete'); self.record_event('Recipe complete'); self.update_summary();
                if self.stop_end.isChecked():self.emergency_stop_all('Recipe complete - all channels stopped',latch=False)
                return
        self.run_recipe_step()
    def stop_recipe_now(self,reason): self.cancel_sequence(); self.recipe_running=False; self.recipe_state=None; getattr(self,'recipe_timer',QTimer()).stop(); self.emergency_stop_all(reason,latch=False); self.recipe_status.setText('Not running')
    def current_recipe_target(self):
        if self.recipe_running and self.recipe_state:
            step=self.recipe_state['steps'][self.recipe_state['step']]; return step.get('target')
        return None
    def start_recording(self):
        if self.active_recording is not None:return
        ids={w.property('channel_id') for w in self._data_check_widgets if w.isChecked()}; self.active_recording={'name':self.exp_name.text().strip() or 'Experiment','note':self.exp_note.toPlainText(),'started':datetime.now().isoformat(timespec='seconds'),'ids':ids,'channels':{id(c):c.name for c in self.channels if id(c) in ids},'samples':[]}; self.start_rec.setEnabled(False); self.stop_rec.setEnabled(True)
        try:self._open_record_stream(); self.status(f"Data recording started: {self._record_stream['path']}"); self.record_event('Recording started')
        except Exception as e:self._record_stream=None; self.rec_file_label.setText('Autosave unavailable'); self.status(f'Recording kept in memory only; autosave failed: {e}',error=True)
        self.update_summary()
    def choose_record_dir(self):
        path=QFileDialog.getExistingDirectory(self,'Autosave folder',self.rec_dir.text())
        if path:self.rec_dir.setText(path)
    def _open_record_stream(self):
        rec=self.active_recording; folder=Path(self.rec_dir.text().strip() or DEFAULT_RECORD_DIR); folder.mkdir(parents=True,exist_ok=True)
        safe=''.join(ch if ch.isalnum() or ch in '-_' else '_' for ch in rec['name'])[:60] or 'Experiment'
        path=folder/f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{safe}.csv"; gas=self.chart_gas.currentText()
        chans=[c for c in self.channels if id(c) in rec['ids']]
        meta={'app':APP_NAME,'version':VERSION,'name':rec['name'],'note':rec['note'],'started':rec['started'],'csv':path.name,'focus_gas':gas,'poll_interval_ms':self.POLL_MS,
              'columns':'timestamp = local ISO time; unix_time_s = seconds since 1970 (use to align with spectrometer data); event rows mark commands and recipe steps; concentrations in ppm; flows in the listed unit',
              'uncertainty':'expected_*_uncertainty_ppm: root-sum-square of the manufacturer flow accuracy of each running controller (MFC-E: larger of 0.8% FS and 1.0% SP; S300: 0.3% FS up to 30% FS, 1.0% SP above), after setpoint rounding. Excludes gas-coefficient and premix-certificate uncertainty.',
              'channels':[{'name':c.name,'port':c.port,'baud':c.baud,'model':c.profile_key,'address':c.address,'source_percent':normalize_composition(c.source),'cmix':c.cmix,
                           'calibration_gas':c.reading.calibration_text,'gas_code':c.reading.gas_code,'flow_unit':c.reading.flow_unit,'full_scale':c.reading.full_scale,
                           'accuracy':{'fs_fraction':c.profile().acc_fs,'sp_fraction':c.profile().acc_sp,'sp_from_fs_fraction':c.profile().sp_from},'min_control_fraction':c.profile().min_fraction} for c in chans],
              'gas_coefficients':{g:self.gas_library[g][1] for c in chans for g in c.source if g in self.gas_library}}
        path.with_suffix('.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
        f=open(path,'w',newline='',encoding='utf-8-sig'); w=csv.writer(f)
        header=['timestamp','unix_time_s','elapsed_s','event','recipe_step','recipe_cycle','step_note',f'target_{gas}_ppm',f'expected_{gas}_ppm',f'expected_{gas}_uncertainty_ppm',f'outlet_{gas}_ppm','total_corrected_flow']
        for c in chans:
            u=c.reading.flow_unit; header+=[f'{c.name} setpoint ({u})',f'{c.name} corrected flow ({u})',f'{c.name} raw flow ({u})',f'{c.name} valve (%)',f'{c.name} temperature (C)',f'{c.name} working']
        w.writerow(header); f.flush()
        self._record_stream={'file':f,'writer':w,'path':path,'channels':chans,'gas':gas,'t0':datetime.now().timestamp()}; self.rec_file_label.setText(str(path))
    def _write_record_row(self,row,event=''):
        st=self._record_stream
        if st is None:return
        gas=st['gas']; rs=self.recipe_state if self.recipe_running else None; target=row.get('target'); outlet=row.get('composition') or {}
        step=rs['steps'][rs['step']] if rs else {}
        out=[datetime.fromtimestamp(row['t']).isoformat(timespec='milliseconds'),f"{row['t']:.3f}",f"{row['t']-st['t0']:.3f}",event,
             rs['step']+1 if rs else '',rs['cycle']+1 if rs else '',step.get('note',''),
             '' if target is None else percent_to_ppm(target.get(gas,0.0))]
        flows=[c.configured_setpoint if c.working and c.configured_setpoint else 0.0 for c in st['channels']]
        exp,err=expected_concentration(st['channels'],flows,gas) if any(flows) else (None,None)
        out+=['' if exp is None else percent_to_ppm(exp),'' if err is None else percent_to_ppm(err),percent_to_ppm(outlet.get(gas,0.0)) if outlet else '',row.get('total','')]
        for c in st['channels']:
            d=row.get(id(c))
            out+=[(c.configured_setpoint or 0) if c.working else 0,d['corrected'],d['raw'],'' if d.get('valve') is None else d['valve'],d['temp'],int(c.working)] if d else ['']*6
        st['writer'].writerow(out); st['file'].flush()
    def _close_record_stream(self):
        st,self._record_stream=self._record_stream,None
        if st:
            try:st['file'].close()
            except Exception:pass
        if hasattr(self,'rec_file_label'):self.rec_file_label.setText('Not recording' if st is None else f'Saved: {st["path"]}')
        return st
    def capture_recording(self,row):
        sample=deepcopy(row)
        for channel in self.channels:
            data=sample.setdefault(id(channel),{})
            data.update(source=dict(channel.source),configured_setpoint=channel.configured_setpoint,connected=channel.connected,working=channel.working,stop_confirmed=channel.stop_confirmed,flow_unit=channel.reading.flow_unit,accumulated_unit=channel.reading.accumulated_unit)
        self.active_recording['samples'].append(sample)
        try:self._write_record_row(row)
        except Exception as e:self._close_record_stream(); self.status(f'Autosave stopped: {e}. Recording continues in memory; export it before closing.',error=True)
    def stop_recording(self):
        if self.active_recording is None:return
        self.record_event('Recording stopped'); st=self._close_record_stream()
        self.recordings.append(self.active_recording); self.active_recording=None; self.start_rec.setEnabled(True); self.stop_rec.setEnabled(False); self.refresh_recordings(); self.status('Data recording stopped'+(f'; saved to {st["path"]}' if st else '')); self.update_summary()
    def refresh_recordings(self):
        mode=self.sort_rec.currentText(); recs=list(self.recordings)
        if mode=='Newest first':recs.sort(key=lambda x:x['started'],reverse=True)
        elif mode=='Oldest first':recs.sort(key=lambda x:x['started'])
        elif mode=='Name A-Z':recs.sort(key=lambda x:x['name'].lower())
        elif mode=='Name Z-A':recs.sort(key=lambda x:x['name'].lower(),reverse=True)
        elif mode=='Most samples':recs.sort(key=lambda x:len(x['samples']),reverse=True)
        else:recs.sort(key=lambda x:len(x['samples']))
        self.rec_table.setRowCount(len(recs))
        for r,rec in enumerate(recs):
            self.rec_table.setItem(r,0,QTableWidgetItem(rec['name'])); self.rec_table.setItem(r,1,QTableWidgetItem(rec['started'])); self.rec_table.setItem(r,2,QTableWidgetItem(str(len(rec['samples'])))); self.rec_table.setItem(r,3,QTableWidgetItem(rec['note'])); b=QPushButton('Export CSV'); b.clicked.connect(lambda _,x=rec:self.export_recording(x)); self.rec_table.setCellWidget(r,4,b)
    def export_recording(self,rec):
        path,_=QFileDialog.getSaveFileName(self,'Export recording',rec['name']+'.csv','CSV (*.csv)');
        if not path:return
        channels=rec['channels']
        fields=['source','raw','corrected','configured_setpoint','temp','accum','flow_unit','accumulated_unit','connected','working','stop_confirmed']
        with open(path,'w',newline='',encoding='utf-8-sig') as f:
            wr=csv.writer(f); wr.writerow(['Experiment name',rec['name']]); wr.writerow(['Experiment note',rec['note']]); wr.writerow([])
            wr.writerow(['timestamp']+[f'{name} {field}' for name in channels.values() for field in fields]+['outlet composition %','target composition %'])
            for sample in rec['samples']:
                out=[datetime.fromtimestamp(sample['t']).isoformat(timespec='milliseconds')]
                for channel_id in channels:
                    data=sample.get(channel_id,{})
                    out.extend(json.dumps(data.get(field,{}),sort_keys=True) if field=='source' else data.get(field,'') for field in fields)
                out.extend(json.dumps(sample.get(field) or {},sort_keys=True) for field in ['composition','target'])
                wr.writerow(out)
        self.status(f'Recording exported: {path}')
    def tools_selected(self):
        cid=self.tools_channel.currentData(); return next((c for c in self.channels if id(c)==cid),None)
    def read_accum(self):
        c=self.tools_selected();
        if c and c.connected:
            try:c.poll(); self.tools_acc.setText(f'{c.name}: {self.fmt(c.reading.accumulated)} {c.reading.accumulated_unit}'); self.status(f'{c.name} accumulated flow refreshed')
            except Exception as e:self.fail_safe_stop(f'Communication lost during accumulated-flow read: {e}',c)
    def clear_accum(self):
        c=self.tools_selected();
        if c and c.connected:
            if QMessageBox.question(self,'Clear accumulated flow',f'Reset the accumulated-flow counter of {c.name} to zero?')!=QMessageBox.Yes: return
            try:c.device.clear_accumulated(); self.status(f'{c.name} accumulated flow cleared')
            except Exception as e:self.fail_safe_stop(f'Device command failed: {e}',c)
    def tools_zero(self):
        c=self.tools_selected();
        if c and c.connected:
            if c.working or self.recipe_running: self.status('Stop the channel (and any recipe) before zero calibration: zeroing with gas flowing stores a wrong zero.',error=True); return
            if QMessageBox.question(self,'Zero calibration',f'Zero {c.name}?\n\nClose the stop valves before and after the controller so that no gas flows, and wait for the reading to settle. Zeroing with gas flowing stores a wrong zero point.')!=QMessageBox.Yes: return
            try:c.device.zero_calibration(); self.status(f'{c.name} zero calibration command sent (device LED: red while zeroing, green when done)'); self.record_event(f'{c.name} zero calibration')
            except Exception as e:self.fail_safe_stop(f'Device command failed: {e}',c)
    def apply_valve(self):
        if self.fail_safe_latched or self.recipe_running:
            self.status('Acknowledge the fail-safe and stop any recipe before valve control.',error=True); return
        c=self.tools_selected();
        if c and c.connected:
            if QMessageBox.question(self,'Valve opening',f'Open the valve of {c.name} to {self.valve.value():g}%?\n\nThis bypasses flow control: the flow depends only on pressure and is NOT limited by a setpoint. Use STOP ALL to close it.')!=QMessageBox.Yes: return
            try:c.device.valve_opening(self.valve.value()); c.working=True; c.stop_confirmed=False; self.invalidate_mixture(); self.status(f'{c.name} valve opening command sent')
            except Exception as e:self.fail_safe_stop(f'Device command failed: {e}',c)
    def detect_isolated_address(self):
        c=self.tools_selected()
        if not c:return
        if c.port=='Simulator': self.assign_addr_spin.setValue(c.address); self.status(f'{c.name}: simulator address is {c.address}'); return
        if c.connected:self.status('Disconnect the selected channel before isolated-address detection.',error=True); return
        bus=None
        try:
            bus=BUS_POOL.acquire(c.port,c.baud); cli=ModbusClient(bus,0xFE); addr=int(cli.read_regs(0x0000,1)[0]); self.assign_addr_spin.setValue(addr); self.status(f'Isolated device address detected: {addr}')
        except Exception as e:self.status(f'Address detection failed: {e}',error=True)
        finally:
            if bus:BUS_POOL.release(bus)
    def assign_isolated_address(self):
        c=self.tools_selected()
        if not c:return
        new=self.assign_addr_spin.value()
        if c.port=='Simulator': c.address=new; self.status(f'{c.name}: simulator address set to {new}'); self.structure_changed(); return
        if c.connected:self.status('Disconnect the selected channel before isolated-address assignment.',error=True); return
        if c.profile_key!='MFC-E':self.status('S300 addresses are set with the rotary switches on the device; only MFC-E supports address writing.',error=True); return
        if QMessageBox.question(self,'Assign address',f'Is the MFC-E on {c.port} the only controller connected to the converter?\n\nThe command goes to every controller on the line and changes its address to {new}.')!=QMessageBox.Yes: return
        bus=None
        try:
            bus=BUS_POOL.acquire(c.port,c.baud); ModbusClient(bus,0xFE).write_single(0x0000,new); c.address=new
            for card in self.cards:
                if card.channel is c:card.addr.setValue(new)
            self.status(f'Isolated MFC-E address changed to {new}')
        except Exception as e:self.status(f'Address assignment failed: {e}',error=True)
        finally:
            if bus:BUS_POOL.release(bus)
    def factory_restore(self):
        c=self.tools_selected();
        if not c or not c.connected:return
        if QMessageBox.question(self,'Restore factory settings','Send the documented factory-restore command to this controller?')!=QMessageBox.Yes:return
        try:c.device.factory_restore(); c.working=False; self.status(f'{c.name} factory-restore command sent')
        except Exception as e:self.fail_safe_stop(f'Device command failed: {e}',c)
    def project_dict(self):
        return {'schema':PROJECT_SCHEMA,'app_version':VERSION,'dark':self.dark,'sig_digits':self.sig_digits,'channels':[c.to_dict() for c in self.channels],'mixture_target':self.target_editor.composition(),'mixture_total_flow':self.total_flow.value(),'chart_gas':self.chart_gas.currentText(),'recipe_type':self.recipe_type.currentIndex(),'conc_unit':self.conc_unit.currentText(),'recipe':self.recipe_rows_to_json(),'cycles':self.cycles.value(),'stop_end':self.stop_end.isChecked(),'sequence_switch':self.sequence_switch.isChecked(),'gas_library':self.gas_library}
    def recipe_rows_to_json(self): return [[self.recipe_table.item(r,c).text() if self.recipe_table.item(r,c) else '' for c in range(self.recipe_table.columnCount())] for r in range(self.recipe_table.rowCount())]
    def save_project(self):
        path,_=QFileDialog.getSaveFileName(self,'Save project','experiment.gfc.json','Gas Flow Controller Project (*.gfc.json);;JSON (*.json)');
        if not path:return
        try:
            data=self.project_dict()
            with open(path,'w',encoding='utf-8') as f: json.dump(data,f,indent=2)
            self.status(f'Project saved: {path}')
        except Exception as error: self.status(f'Project could not be saved: {error}',error=True)
    def load_project(self):
        path,_=QFileDialog.getOpenFileName(self,'Load project','','Gas Flow Controller Project (*.gfc.json *.json)');
        if not path:return
        try:
            with open(path,encoding='utf-8') as f:d=json.load(f)
            self.emergency_stop_all('Loading project - outputs stopped',latch=False)
            if self.fail_safe_latched: raise RuntimeError('Resolve and acknowledge the fail-safe before replacing the project')
            self.stop_recording()
            for card in list(self.cards):
                try:card.channel.disconnect()
                except:pass
                card.deleteLater()
            self.cards=[]; self.channels=[]; self.gas_library={k:tuple(v) for k,v in d.get('gas_library',BUILTIN_GASES).items()};
            self.refresh_gas_library_ui()
            for cd in d.get('channels',[]):self.add_channel(Channel.from_dict(cd))
            if not self.channels:self.add_channel()
            self.sig.setValue(int(d.get('sig_digits',5))); self.dark_action.setChecked(bool(d.get('dark',False))); self.target_editor.set_composition(d.get('mixture_target',{'H2':1,'N2':99})); self.total_flow.setValue(float(d.get('mixture_total_flow',100))); self.chart_gas.setCurrentText(d.get('chart_gas','H2')); self.set_conc_unit(d.get('conc_unit','%')); self.recipe_type.setCurrentIndex(int(d.get('recipe_type',0))); self.rebuild_recipe_table(); rows=d.get('recipe',[]); self.recipe_table.setRowCount(len(rows));
            for r,row in enumerate(rows):
                for c,val in enumerate(row[:self.recipe_table.columnCount()]):self.recipe_table.setItem(r,c,QTableWidgetItem(str(val)))
            self.renumber_steps(); self.cycles.setValue(int(d.get('cycles',1))); self.stop_end.setChecked(bool(d.get('stop_end',True))); self.sequence_switch.setChecked(bool(d.get('sequence_switch',True))); self.status(f'Project loaded: {path}. Hardware remains stopped until Start/Apply mixture/Run recipe is used.')
        except Exception as e:self.status(f'Project load failed: {e}',error=True)
    def outputs_active(self): return any(c.working for c in self.channels) or self.recipe_running or self.active_recording is not None
    def confirm_interrupt(self,action):
        if not self.outputs_active(): return True
        what=[x for x,on in (('gas is flowing',any(c.working for c in self.channels)),('a recipe is running',self.recipe_running),('a recording is in progress',self.active_recording is not None)) if on]
        return QMessageBox.question(self,action,f'{action} now? Currently {", ".join(what)}.\n\nAll flows will be commanded to 0 and the recording will be stopped (its autosaved file is kept).')==QMessageBox.Yes
    def request_close(self):
        if self.confirm_interrupt('Exit'): self._close_confirmed=True; self.close()
    def show_guide(self):
        QMessageBox.information(self,'Quick guide',
            '1. Channels: one card per flow controller. Choose port, model, address and baud rate, then Connect. Purple SIMULATOR means no real gas flows.\n'
            '0. Open the gas cylinders and set the regulators BEFORE starting flows (a controller without gas opens its valve fully; opening the supply then gives a surge).\n'
            '2. Change gas…: enter the cylinder composition (for example 1% H2 in N2). Flows are shown for that gas (corrected); the device reading is N2-equivalent.\n'
            '3. The setpoint box cannot exceed the controller maximum. Below the reliable range a warning appears; the delivered flow may differ a lot there.\n'
            '4. Mixture: enter a target composition and total flow; the program computes every channel and shows the allowed total-flow range.\n'
            '5. Recipes: timed steps. Invalid cells turn red; Preview / check shows setpoints, expected concentration ± accuracy and duration. The table is locked while a recipe runs.\n'
            '6. Charts: choose a time span; drag to look back (Live pauses), double-click to return. Hover to read values.\n'
            '7. Data: Start recording before an experiment; the file is written continuously to the autosave folder.\n\n'
            'Safety: STOP ALL (or Esc) commands 0 on every channel. Any communication error triggers a SAFETY STOP that must be acknowledged. Mixtures with ≥ 4% H2 and oxygen/air are refused. '
            'A zero setpoint does not close the gas line: use the stop valves before and after the H2 controller.')
    def ui_new_project(self):
        if self.confirm_interrupt('Start a new project'): self.new_project()
    def ui_load_project(self):
        if self.confirm_interrupt('Load a project'): self.load_project()
    def new_project(self):
        self.emergency_stop_all('New project - outputs stopped',latch=False)
        if self.fail_safe_latched: return
        self.stop_recording()
        for card in list(self.cards):
            try:card.channel.disconnect()
            except:pass
            card.deleteLater()
        self.cards=[]; self.channels=[]; self.add_channel(); self.add_channel(); self.chart_data.clear(); self.recordings.clear(); self.status('New project created')
    def _shutdown_best_effort(self, reason):
        # Synchronous best-effort zero commands before the UI is allowed to close.
        self.cancel_sequence(); self.recipe_running=False; self.recipe_state=None; self.invalidate_mixture()
        self.poll_timer.stop(); self.chart_timer.stop();
        if hasattr(self,'recipe_timer'):self.recipe_timer.stop()
        results=[]
        for c in self.channels:
            if c.connected or c.device: results.append((c.name,c.emergency_stop()))
        for c in self.channels:
            try:c.disconnect()
            except:pass
        bad=[name for name, ok in results if not ok]
        if bad: self.status('Shutdown: stop unconfirmed for ' + ', '.join(bad), error=True)
        self.record_event(f'Shutdown ({reason})'); self._close_record_stream()
        return results
    def closeEvent(self,event):
        if self._closing:event.accept(); return
        if event.spontaneous() and not getattr(self,'_close_confirmed',False) and not self.confirm_interrupt('Close the program'): event.ignore(); return
        self._closing=True; self.status('Closing application - fail-safe stop in progress',working=True); self._shutdown_best_effort('window closed'); event.accept()

def install_signal_handlers(window):
    def handler(signum,frame):
        try:window._shutdown_best_effort(f'signal {signum}')
        finally:QApplication.quit()
    for s in (getattr(signal,'SIGINT',None),getattr(signal,'SIGTERM',None)):
        if s is not None:
            try:signal.signal(s,handler)
            except:pass

def main():
    app=QApplication(sys.argv); app.setApplicationName(APP_NAME); app.setApplicationVersion(VERSION); w=MainWindow(); install_signal_handlers(w)
    old_hook=sys.excepthook
    def hook(tp,val,tb):
        try:w._shutdown_best_effort('unhandled exception')
        except:pass
        old_hook(tp,val,tb)
    sys.excepthook=hook; app.aboutToQuit.connect(lambda: w._shutdown_best_effort('application quit') if not w._closing else None); w.show(); return app.exec()

if __name__=='__main__': raise SystemExit(main())
